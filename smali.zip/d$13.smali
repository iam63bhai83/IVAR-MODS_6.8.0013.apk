# classes88.dex

.class Ld$13;
.super Ljava/lang/Object;
.source "FoxSource"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ld;->b(Landroid/app/Activity;Landroid/app/Dialog;Ljava/lang/String;IIIILandroid/content/SharedPreferences;)Landroid/view/View;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private final synthetic A:Landroid/widget/TextView;

.field private final synthetic B:Landroid/widget/TextView;

.field private final synthetic C:Landroid/widget/TextView;

.field private final synthetic D:Landroid/widget/TextView;

.field private final synthetic E:Landroid/widget/TextView;

.field private final synthetic F:Landroid/widget/TextView;

.field private final synthetic G:Landroid/widget/TextView;

.field private final synthetic H:Landroid/widget/LinearLayout;

.field private final synthetic I:Landroid/widget/LinearLayout;

.field private final synthetic J:Landroid/widget/TextView;

.field private final synthetic K:Landroid/widget/TextView;

.field private final synthetic L:Landroid/widget/Button;

.field private final synthetic a:[Z

.field private final synthetic b:[Z

.field private final synthetic c:Ljava/lang/String;

.field private final synthetic d:Ljava/lang/String;

.field private final synthetic e:Ljava/lang/String;

.field private final synthetic f:Ljava/lang/String;

.field private final synthetic g:Landroid/content/SharedPreferences;

.field private final synthetic h:Landroid/app/Activity;

.field private final synthetic i:Landroid/widget/LinearLayout;

.field private final synthetic j:Landroid/widget/LinearLayout;

.field private final synthetic k:Landroid/widget/TextView;

.field private final synthetic l:Landroid/widget/TextView;

.field private final synthetic m:Landroid/widget/LinearLayout;

.field private final synthetic n:Landroid/widget/TextView;

.field private final synthetic o:Landroid/widget/TextView;

.field private final synthetic p:Landroid/widget/TextView;

.field private final synthetic q:[Landroid/widget/TextView;

.field private final synthetic r:[Landroid/widget/ImageView;

.field private final synthetic s:[Landroid/widget/LinearLayout;

.field private final synthetic t:Landroid/view/View;

.field private final synthetic u:Landroid/widget/FrameLayout;

.field private final synthetic v:Landroid/widget/ImageView;

.field private final synthetic w:Landroid/widget/ImageView;

.field private final synthetic x:Landroid/widget/TextView;

.field private final synthetic y:Landroid/widget/TextView;

.field private final synthetic z:Landroid/widget/TextView;


# direct methods
.method constructor <init>([Z[ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/content/SharedPreferences;Landroid/app/Activity;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/LinearLayout;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;[Landroid/widget/TextView;[Landroid/widget/ImageView;[Landroid/widget/LinearLayout;Landroid/view/View;Landroid/widget/FrameLayout;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/Button;)V
    .registers 39

    .line 3299
    iput-object p1, p0, Ld$13;->a:[Z

    iput-object p2, p0, Ld$13;->b:[Z

    iput-object p3, p0, Ld$13;->c:Ljava/lang/String;

    iput-object p4, p0, Ld$13;->d:Ljava/lang/String;

    iput-object p5, p0, Ld$13;->e:Ljava/lang/String;

    iput-object p6, p0, Ld$13;->f:Ljava/lang/String;

    iput-object p7, p0, Ld$13;->g:Landroid/content/SharedPreferences;

    iput-object p8, p0, Ld$13;->h:Landroid/app/Activity;

    iput-object p9, p0, Ld$13;->i:Landroid/widget/LinearLayout;

    iput-object p10, p0, Ld$13;->j:Landroid/widget/LinearLayout;

    iput-object p11, p0, Ld$13;->k:Landroid/widget/TextView;

    iput-object p12, p0, Ld$13;->l:Landroid/widget/TextView;

    iput-object p13, p0, Ld$13;->m:Landroid/widget/LinearLayout;

    iput-object p14, p0, Ld$13;->n:Landroid/widget/TextView;

    iput-object p15, p0, Ld$13;->o:Landroid/widget/TextView;

    move-object/from16 p1, p16

    iput-object p1, p0, Ld$13;->p:Landroid/widget/TextView;

    move-object/from16 p1, p17

    iput-object p1, p0, Ld$13;->q:[Landroid/widget/TextView;

    move-object/from16 p1, p18

    iput-object p1, p0, Ld$13;->r:[Landroid/widget/ImageView;

    move-object/from16 p1, p19

    iput-object p1, p0, Ld$13;->s:[Landroid/widget/LinearLayout;

    move-object/from16 p1, p20

    iput-object p1, p0, Ld$13;->t:Landroid/view/View;

    move-object/from16 p1, p21

    iput-object p1, p0, Ld$13;->u:Landroid/widget/FrameLayout;

    move-object/from16 p1, p22

    iput-object p1, p0, Ld$13;->v:Landroid/widget/ImageView;

    move-object/from16 p1, p23

    iput-object p1, p0, Ld$13;->w:Landroid/widget/ImageView;

    move-object/from16 p1, p24

    iput-object p1, p0, Ld$13;->x:Landroid/widget/TextView;

    move-object/from16 p1, p25

    iput-object p1, p0, Ld$13;->y:Landroid/widget/TextView;

    move-object/from16 p1, p26

    iput-object p1, p0, Ld$13;->z:Landroid/widget/TextView;

    move-object/from16 p1, p27

    iput-object p1, p0, Ld$13;->A:Landroid/widget/TextView;

    move-object/from16 p1, p28

    iput-object p1, p0, Ld$13;->B:Landroid/widget/TextView;

    move-object/from16 p1, p29

    iput-object p1, p0, Ld$13;->C:Landroid/widget/TextView;

    move-object/from16 p1, p30

    iput-object p1, p0, Ld$13;->D:Landroid/widget/TextView;

    move-object/from16 p1, p31

    iput-object p1, p0, Ld$13;->E:Landroid/widget/TextView;

    move-object/from16 p1, p32

    iput-object p1, p0, Ld$13;->F:Landroid/widget/TextView;

    move-object/from16 p1, p33

    iput-object p1, p0, Ld$13;->G:Landroid/widget/TextView;

    move-object/from16 p1, p34

    iput-object p1, p0, Ld$13;->H:Landroid/widget/LinearLayout;

    move-object/from16 p1, p35

    iput-object p1, p0, Ld$13;->I:Landroid/widget/LinearLayout;

    move-object/from16 p1, p36

    iput-object p1, p0, Ld$13;->J:Landroid/widget/TextView;

    move-object/from16 p1, p37

    iput-object p1, p0, Ld$13;->K:Landroid/widget/TextView;

    move-object/from16 p1, p38

    iput-object p1, p0, Ld$13;->L:Landroid/widget/Button;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 39

    move-object/from16 v0, p0

    .line 3302
    const-string v1, ""

    iget-object v2, v0, Ld$13;->a:[Z

    const/4 v3, 0x0

    aget-boolean v2, v2, v3

    .line 3303
    iget-object v4, v0, Ld$13;->b:[Z

    aget-boolean v4, v4, v3

    .line 3305
    const-string v5, "dmN+GwgQFQ=="

    const-string v6, "dmR+FAkXZg=="

    if-eqz v2, :cond_18

    invoke-static {v5}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    goto :goto_1c

    :cond_18
    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    :goto_1c
    invoke-static {v7}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v7

    if-eqz v2, :cond_25

    .line 3306
    const-string v8, "dmB1HgAWFQ=="

    goto :goto_27

    :cond_25
    const-string v8, "dmQDGgxsZA=="

    :goto_27
    invoke-static {v8}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v8

    if-eqz v2, :cond_34

    .line 3307
    const-string v9, "dm11HgsQFQ=="

    goto :goto_36

    :cond_34
    const-string v9, "dmRwbw4RYA=="

    :goto_36
    invoke-static {v9}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v9

    if-eqz v2, :cond_43

    .line 3308
    const-string v10, "dhIHaw0TEg=="

    goto :goto_45

    :cond_43
    const-string v10, "dhJ2a3wTFQ=="

    :goto_45
    invoke-static {v10}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 3309
    const-string v10, "dhcFa3oTZQ=="

    if-eqz v2, :cond_57

    const-string v11, "dhACaQ4TEQ=="

    invoke-static {v11}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    goto :goto_5b

    :cond_57
    invoke-static {v10}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    :goto_5b
    invoke-static {v11}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 3310
    const-string v11, "dhECaAETEQ=="

    if-eqz v2, :cond_67

    invoke-static {v11}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    goto :goto_6b

    :cond_67
    invoke-static {v10}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    :goto_6b
    invoke-static {v12}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v12

    if-eqz v2, :cond_74

    .line 3311
    const-string v13, "dhJ1awgTEg=="

    goto :goto_76

    :cond_74
    const-string v13, "dhF2awoTEQ=="

    :goto_76
    invoke-static {v13}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-static {v13}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v13

    if-eqz v2, :cond_83

    .line 3313
    iget-object v14, v0, Ld$13;->c:Ljava/lang/String;

    goto :goto_85

    :cond_83
    iget-object v14, v0, Ld$13;->d:Ljava/lang/String;

    :goto_85
    if-eqz v2, :cond_8a

    .line 3314
    iget-object v15, v0, Ld$13;->e:Ljava/lang/String;

    goto :goto_8c

    :cond_8a
    iget-object v15, v0, Ld$13;->f:Ljava/lang/String;

    .line 3315
    :goto_8c
    invoke-static {v14}, Ld;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v16

    .line 3316
    invoke-static {v15}, Ld;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v17

    if-eqz v2, :cond_9b

    const/16 v19, 0x2a

    const/16 v3, 0x2a

    goto :goto_9d

    :cond_9b
    const/16 v3, 0xe

    :goto_9d
    move/from16 v20, v2

    const/4 v2, 0x7

    .line 3317
    invoke-static {v14, v2, v3}, Ld;->a(Ljava/lang/String;II)I

    move-result v2

    if-eqz v20, :cond_a9

    const/16 v3, 0x1a

    goto :goto_ab

    :cond_a9
    const/16 v3, 0x9

    :goto_ab
    move/from16 v21, v4

    const/16 v4, 0x1e

    .line 3318
    invoke-static {v15, v4, v3}, Ld;->a(Ljava/lang/String;II)I

    move-result v3

    if-eqz v20, :cond_dc

    .line 3321
    iget-object v4, v0, Ld$13;->g:Landroid/content/SharedPreferences;

    const-string v22, "JSYpclU6OjJFVCwLNl9RNjEZQko8Mw=="

    move-object/from16 v23, v5

    invoke-static/range {v22 .. v22}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    move-object/from16 v22, v6

    iget-object v6, v0, Ld$13;->g:Landroid/content/SharedPreferences;

    const-string v24, "JSYpckgnPSVIZzomL0o="

    move-object/from16 v25, v10

    invoke-static/range {v24 .. v24}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    const-string v24, "t9b/HAxsbQ=="

    move-object/from16 v26, v11

    invoke-static/range {v24 .. v24}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-interface {v6, v10, v11}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-interface {v4, v5, v6}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    goto :goto_102

    :cond_dc
    move-object/from16 v23, v5

    move-object/from16 v22, v6

    move-object/from16 v25, v10

    move-object/from16 v26, v11

    .line 3322
    iget-object v4, v0, Ld$13;->g:Landroid/content/SharedPreferences;

    const-string v5, "NzU1RFsKOSlDTD04P3JIJz0lSGc6Ji9K"

    invoke-static {v5}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    iget-object v6, v0, Ld$13;->g:Landroid/content/SharedPreferences;

    const-string v10, "NzU1RFsKJDREWzALKV9RMg=="

    invoke-static {v10}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    const-string v11, "t9b/GQFs"

    invoke-static {v11}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-interface {v6, v10, v11}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-interface {v4, v5, v6}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    :goto_102
    if-eqz v20, :cond_125

    .line 3324
    iget-object v5, v0, Ld$13;->g:Landroid/content/SharedPreferences;

    const-string v6, "JSYpclU6OjJFVCwLIkRLNjszQ0wKICdK"

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    iget-object v10, v0, Ld$13;->g:Landroid/content/SharedPreferences;

    const-string v11, "JSYpclw8JyVCTTsgGVlZMg=="

    invoke-static {v11}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const-string v24, "YGRjDXcTEg=="

    move/from16 v27, v8

    invoke-static/range {v24 .. v24}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-interface {v10, v11, v8}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-interface {v5, v6, v8}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    goto :goto_145

    :cond_125
    move/from16 v27, v8

    .line 3325
    iget-object v5, v0, Ld$13;->g:Landroid/content/SharedPreferences;

    const-string v6, "NzU1RFsKOSlDTD04P3JcPCclQk07IBlZWTI="

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    iget-object v8, v0, Ld$13;->g:Landroid/content/SharedPreferences;

    const-string v10, "NzU1RFsKMC9eWzohKFlnITUh"

    invoke-static {v10}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    const-string v11, "YWRjDXcTEg=="

    invoke-static {v11}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-interface {v8, v10, v11}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-interface {v5, v6, v8}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    :goto_145
    if-eqz v20, :cond_14a

    .line 3327
    const-string v6, "BjUwSBhgZGM="

    goto :goto_14c

    :cond_14a
    const-string v6, "BjUwSBhhZGM="

    :goto_14c
    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v4, v15, v5, v6}, Ld;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 3329
    iget-object v5, v0, Ld$13;->h:Landroid/app/Activity;

    const/16 v6, 0x8

    invoke-static {v5, v6}, Ld;->a(Landroid/content/Context;I)I

    move-result v5

    iget-object v8, v0, Ld$13;->h:Landroid/app/Activity;

    const/high16 v10, 0x3fc00000  # 1.5f

    invoke-static {v8, v10}, Ld;->a(Landroid/content/Context;F)I

    move-result v8

    const/4 v10, -0x1

    invoke-static {v10, v5, v8, v7}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v5

    const/16 v11, 0x16

    .line 3330
    const-string v28, "dhF0aAATZA=="

    const-string v29, "dmQAHA9nFQ=="

    const/16 v31, 0x2

    const/16 v32, 0x4

    const-string v33, "dmJyGgxtFg=="

    const/16 v34, 0x3

    const/4 v8, 0x0

    const/4 v6, 0x1

    if-eqz v20, :cond_2a5

    .line 3331
    iget-object v10, v0, Ld$13;->i:Landroid/widget/LinearLayout;

    invoke-virtual {v10, v5}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 3332
    iget-object v5, v0, Ld$13;->j:Landroid/widget/LinearLayout;

    const/4 v10, 0x0

    invoke-virtual {v5, v10}, Landroid/widget/LinearLayout;->setBackgroundColor(I)V

    .line 3333
    iget-object v5, v0, Ld$13;->k:Landroid/widget/TextView;

    invoke-virtual {v5, v7}, Landroid/widget/TextView;->setTextColor(I)V

    .line 3334
    iget-object v5, v0, Ld$13;->k:Landroid/widget/TextView;

    invoke-virtual {v5, v8, v6}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 3335
    iget-object v5, v0, Ld$13;->l:Landroid/widget/TextView;

    invoke-static/range {v33 .. v33}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v18

    invoke-static/range {v18 .. v18}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setTextColor(I)V

    .line 3336
    iget-object v5, v0, Ld$13;->l:Landroid/widget/TextView;

    invoke-virtual {v5, v8, v10}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 3338
    iget-object v5, v0, Ld$13;->m:Landroid/widget/LinearLayout;

    iget-object v6, v0, Ld$13;->h:Landroid/app/Activity;

    invoke-static {v6, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    iget-object v10, v0, Ld$13;->h:Landroid/app/Activity;

    const/4 v11, 0x1

    invoke-static {v10, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v10

    invoke-static/range {v28 .. v28}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-static {v11}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v11

    const/4 v8, -0x1

    invoke-static {v8, v6, v10, v11}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 3339
    iget-object v5, v0, Ld$13;->n:Landroid/widget/TextView;

    const-string v6, "BSYpDW4cBA=="

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3340
    iget-object v5, v0, Ld$13;->o:Landroid/widget/TextView;

    const-string v6, "FDgqDV07My9DXSZ4ZkVRMjxmWlE7JidZXXVyZktUOjUyRFYydA54fA=="

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3341
    iget-object v5, v0, Ld$13;->p:Landroid/widget/TextView;

    const-string v6, "ABoKYnseEQI="

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3342
    iget-object v5, v0, Ld$13;->p:Landroid/widget/TextView;

    invoke-virtual {v5, v7}, Landroid/widget/TextView;->setTextColor(I)V

    .line 3343
    iget-object v5, v0, Ld$13;->p:Landroid/widget/TextView;

    iget-object v6, v0, Ld$13;->h:Landroid/app/Activity;

    const/16 v8, 0x8

    invoke-static {v6, v8}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    const/4 v10, 0x0

    invoke-static {v12, v6, v10, v10}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 3345
    iget-object v5, v0, Ld$13;->q:[Landroid/widget/TextView;

    aget-object v5, v5, v10

    const-string v6, "BQYJDXs6OjVIViYhNQ0QbWFjBhgCPShfWSExbw=="

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3346
    iget-object v5, v0, Ld$13;->q:[Landroid/widget/TextView;

    const/16 v37, 0x1

    aget-object v5, v5, v37

    const-string v6, "EzgpTEw8OiENcTt5AUxVMHQOeHw="

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3347
    iget-object v5, v0, Ld$13;->q:[Landroid/widget/TextView;

    aget-object v5, v5, v31

    const-string v6, "ADoqRFU8ICNJGBE1L0FBdQQ0SFw8NzJEVzsn"

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3348
    iget-object v5, v0, Ld$13;->q:[Landroid/widget/TextView;

    aget-object v5, v5, v34

    const-string v6, "Z2BpGhgUHWZ+TCc1MkhfLHQFRVkh"

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3349
    iget-object v5, v0, Ld$13;->q:[Landroid/widget/TextView;

    aget-object v5, v5, v32

    const-string v6, "DzE0QhURMSpMQXUCD30YBjE0W10nJw=="

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3351
    iget-object v5, v0, Ld$13;->h:Landroid/app/Activity;

    const/16 v6, 0xa

    invoke-static {v5, v6}, Ld;->a(Landroid/content/Context;I)I

    move-result v5

    iget-object v6, v0, Ld$13;->h:Landroid/app/Activity;

    const/4 v11, 0x1

    invoke-static {v6, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    invoke-static/range {v26 .. v26}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v8

    const/4 v10, -0x1

    invoke-static {v10, v5, v6, v8}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v6

    .line 3352
    iget-object v5, v0, Ld$13;->h:Landroid/app/Activity;

    invoke-static/range {v26 .. v26}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v8

    invoke-static/range {v23 .. v23}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v10

    const/16 v11, 0x14

    invoke-static {v5, v11, v8, v10}, Ld;->c(Landroid/content/Context;III)Landroid/graphics/drawable/Drawable;

    move-result-object v8

    const/4 v5, 0x0

    :goto_271
    const/4 v10, 0x5

    if-lt v5, v10, :cond_276

    goto/16 :goto_3e3

    .line 3354
    :cond_276
    iget-object v10, v0, Ld$13;->r:[Landroid/widget/ImageView;

    aget-object v10, v10, v5

    if-eqz v10, :cond_27f

    invoke-virtual {v10, v8}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 3355
    :cond_27f
    iget-object v10, v0, Ld$13;->s:[Landroid/widget/LinearLayout;

    aget-object v10, v10, v5

    if-eqz v10, :cond_288

    invoke-virtual {v10, v6}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 3356
    :cond_288
    iget-object v10, v0, Ld$13;->q:[Landroid/widget/TextView;

    aget-object v10, v10, v5

    if-eqz v10, :cond_2a2

    invoke-static/range {v29 .. v29}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-static {v11}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v11

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v10, v0, Ld$13;->q:[Landroid/widget/TextView;

    aget-object v10, v10, v5

    const/4 v11, 0x0

    const/4 v12, 0x1

    invoke-virtual {v10, v11, v12}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    :cond_2a2
    add-int/lit8 v5, v5, 0x1

    goto :goto_271

    .line 3359
    :cond_2a5
    iget-object v6, v0, Ld$13;->j:Landroid/widget/LinearLayout;

    invoke-virtual {v6, v5}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 3360
    iget-object v5, v0, Ld$13;->i:Landroid/widget/LinearLayout;

    const/4 v10, 0x0

    invoke-virtual {v5, v10}, Landroid/widget/LinearLayout;->setBackgroundColor(I)V

    .line 3361
    iget-object v5, v0, Ld$13;->l:Landroid/widget/TextView;

    invoke-virtual {v5, v7}, Landroid/widget/TextView;->setTextColor(I)V

    .line 3362
    iget-object v5, v0, Ld$13;->l:Landroid/widget/TextView;

    const/4 v6, 0x1

    const/4 v11, 0x0

    invoke-virtual {v5, v11, v6}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 3363
    iget-object v5, v0, Ld$13;->k:Landroid/widget/TextView;

    invoke-static/range {v33 .. v33}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v8

    invoke-virtual {v5, v8}, Landroid/widget/TextView;->setTextColor(I)V

    .line 3364
    iget-object v5, v0, Ld$13;->k:Landroid/widget/TextView;

    invoke-virtual {v5, v11, v10}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 3366
    iget-object v5, v0, Ld$13;->m:Landroid/widget/LinearLayout;

    iget-object v8, v0, Ld$13;->h:Landroid/app/Activity;

    const/16 v10, 0x16

    invoke-static {v8, v10}, Ld;->a(Landroid/content/Context;I)I

    move-result v8

    iget-object v10, v0, Ld$13;->h:Landroid/app/Activity;

    invoke-static {v10, v6}, Ld;->a(Landroid/content/Context;I)I

    move-result v10

    invoke-static/range {v28 .. v28}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    const/4 v11, -0x1

    invoke-static {v11, v8, v10, v6}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 3367
    iget-object v5, v0, Ld$13;->n:Landroid/widget/TextView;

    const-string v6, "FzU1RFt1Ag99"

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3368
    iget-object v5, v0, Ld$13;->o:Landroid/widget/TextView;

    const-string v6, "ADoqRFU8ICNJGCUmI0lRNiAvQlYmdGANeRx0NVlKNCAjSkF1Ny5MTA=="

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3369
    iget-object v5, v0, Ld$13;->p:Landroid/widget/TextView;

    const-string v6, "ABoKZHUcAANp"

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3370
    iget-object v5, v0, Ld$13;->p:Landroid/widget/TextView;

    invoke-virtual {v5, v7}, Landroid/widget/TextView;->setTextColor(I)V

    .line 3371
    iget-object v5, v0, Ld$13;->p:Landroid/widget/TextView;

    iget-object v6, v0, Ld$13;->h:Landroid/app/Activity;

    const/16 v8, 0x8

    invoke-static {v6, v8}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    const/4 v10, 0x0

    invoke-static {v12, v6, v10, v10}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 3373
    iget-object v5, v0, Ld$13;->q:[Landroid/widget/TextView;

    aget-object v5, v5, v10

    const-string v6, "ADoqRFU8ICNJGBE1L0FBdQQ0SFw8NzJEVzsn"

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3374
    iget-object v5, v0, Ld$13;->q:[Landroid/widget/TextView;

    const/16 v37, 0x1

    aget-object v5, v5, v37

    const-string v6, "Z2BpGhgUHWZ+TCc1MkhfLHQFRVkh"

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3375
    iget-object v5, v0, Ld$13;->q:[Landroid/widget/TextView;

    aget-object v5, v5, v31

    const-string v6, "BiAnQ1w0JiINazAmMEhKdQc2SF0x"

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3376
    iget-object v5, v0, Ld$13;->q:[Landroid/widget/TextView;

    aget-object v5, v5, v34

    const-string v6, "BQYJDXs6OjVIViYhNQ0QBSYpDW4cBGZiVjktbw=="

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3377
    iget-object v5, v0, Ld$13;->q:[Landroid/widget/TextView;

    aget-object v5, v5, v32

    const-string v6, "EzgpTEw8OiENcAAQZgVoJztme3EFdAlDVCx9"

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3379
    iget-object v5, v0, Ld$13;->h:Landroid/app/Activity;

    const/16 v6, 0xa

    invoke-static {v5, v6}, Ld;->a(Landroid/content/Context;I)I

    move-result v5

    iget-object v8, v0, Ld$13;->h:Landroid/app/Activity;

    const/4 v11, 0x1

    invoke-static {v8, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v8

    invoke-static/range {v25 .. v25}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v10

    const/4 v12, -0x1

    invoke-static {v12, v5, v8, v10}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v5

    .line 3380
    const-string v8, "dhJ+a3kTFw=="

    invoke-static {v8}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v8

    iget-object v10, v0, Ld$13;->h:Landroid/app/Activity;

    invoke-static {v10, v6}, Ld;->a(Landroid/content/Context;I)I

    move-result v10

    iget-object v6, v0, Ld$13;->h:Landroid/app/Activity;

    invoke-static {v6, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    invoke-static/range {v28 .. v28}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-static {v11}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v11

    invoke-static {v8, v10, v6, v11}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v6

    .line 3381
    iget-object v8, v0, Ld$13;->h:Landroid/app/Activity;

    invoke-static/range {v25 .. v25}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v10

    invoke-static/range {v22 .. v22}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-static {v11}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v11

    const/16 v12, 0x14

    invoke-static {v8, v12, v10, v11}, Ld;->c(Landroid/content/Context;III)Landroid/graphics/drawable/Drawable;

    move-result-object v8

    .line 3382
    iget-object v10, v0, Ld$13;->h:Landroid/app/Activity;

    const-string v11, "dhJ3aw0TbQ=="

    invoke-static {v11}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-static {v11}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v11

    const-string v24, "dm1ybAsXbA=="

    invoke-static/range {v24 .. v24}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v24

    move-object/from16 v25, v5

    invoke-static/range {v24 .. v24}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    invoke-static {v10, v12, v11, v5}, Ld;->d(Landroid/content/Context;III)Landroid/graphics/drawable/Drawable;

    move-result-object v5

    const/4 v10, 0x0

    :goto_3dc
    const/4 v11, 0x3

    if-lt v10, v11, :cond_7f3

    const/4 v11, 0x3

    :goto_3e0
    const/4 v8, 0x5

    if-lt v11, v8, :cond_7b5

    .line 3395
    :goto_3e3
    new-instance v5, Landroid/graphics/drawable/GradientDrawable;

    .line 3396
    sget-object v6, Landroid/graphics/drawable/GradientDrawable$Orientation;->TL_BR:Landroid/graphics/drawable/GradientDrawable$Orientation;

    if-eqz v20, :cond_421

    const/4 v8, 0x4

    .line 3398
    new-array v10, v8, [I

    invoke-static/range {v29 .. v29}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v8

    const/16 v18, 0x0

    aput v8, v10, v18

    const-string v8, "dmd3H31tZQ=="

    invoke-static {v8}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v8

    const/16 v37, 0x1

    aput v8, v10, v37

    const-string v8, "dmJ1Gw4TZQ=="

    invoke-static {v8}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v8

    aput v8, v10, v31

    invoke-static/range {v23 .. v23}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v8

    const/16 v34, 0x3

    aput v8, v10, v34

    const/16 v34, 0x3

    goto :goto_458

    :cond_421
    const/4 v8, 0x4

    .line 3399
    new-array v10, v8, [I

    invoke-static/range {v22 .. v22}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v8

    const/16 v18, 0x0

    aput v8, v10, v18

    const-string v8, "dmRwbw4RYA=="

    invoke-static {v8}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v8

    const/16 v37, 0x1

    aput v8, v10, v37

    const-string v8, "dmd+b3wTbA=="

    invoke-static {v8}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v8

    aput v8, v10, v31

    const-string v8, "dhYHaA4TEA=="

    invoke-static {v8}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v8

    const/16 v34, 0x3

    aput v8, v10, v34

    .line 3395
    :goto_458
    invoke-direct {v5, v6, v10}, Landroid/graphics/drawable/GradientDrawable;-><init>(Landroid/graphics/drawable/GradientDrawable$Orientation;[I)V

    .line 3401
    iget-object v6, v0, Ld$13;->h:Landroid/app/Activity;

    const/16 v12, 0x16

    invoke-static {v6, v12}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    int-to-float v6, v6

    const/16 v8, 0x8

    .line 3402
    new-array v10, v8, [F

    const/16 v18, 0x0

    aput v6, v10, v18

    const/16 v37, 0x1

    aput v6, v10, v37

    aput v6, v10, v31

    aput v6, v10, v34

    const/4 v6, 0x0

    const/16 v32, 0x4

    aput v6, v10, v32

    const/4 v8, 0x5

    aput v6, v10, v8

    const/4 v8, 0x6

    aput v6, v10, v8

    const/4 v11, 0x7

    aput v6, v10, v11

    invoke-virtual {v5, v10}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadii([F)V

    .line 3403
    iget-object v6, v0, Ld$13;->t:Landroid/view/View;

    invoke-virtual {v6, v5}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 3405
    iget-object v5, v0, Ld$13;->u:Landroid/widget/FrameLayout;

    iget-object v6, v0, Ld$13;->h:Landroid/app/Activity;

    const/16 v10, 0x18

    invoke-static {v6, v10}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    iget-object v10, v0, Ld$13;->h:Landroid/app/Activity;

    const/high16 v11, 0x40200000  # 2.5f

    invoke-static {v10, v11}, Ld;->a(Landroid/content/Context;F)I

    move-result v10

    const/4 v11, -0x1

    invoke-static {v11, v6, v10, v7}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/FrameLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 3408
    :try_start_4a4
    iget-object v5, v0, Ld$13;->h:Landroid/app/Activity;

    const-string v6, "MiQ="

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const/4 v10, 0x0

    invoke-virtual {v5, v6, v10}, Landroid/app/Activity;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v5

    if-eqz v5, :cond_4be

    .line 3409
    const-string v6, "JSYpS1E5MQ=="

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-interface {v5, v6, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    goto :goto_4bf

    :cond_4be
    move-object v5, v1

    :goto_4bf
    if-eqz v5, :cond_4cd

    .line 3410
    invoke-virtual {v5}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v5
    :try_end_4c9
    .catchall {:try_start_4a4 .. :try_end_4c9} :catchall_4cc

    if-nez v5, :cond_4cd

    goto :goto_527

    :catchall_4cc
    nop

    .line 3416
    :cond_4cd
    iget-object v5, v0, Ld$13;->v:Landroid/widget/ImageView;

    sget-object v6, Landroid/widget/ImageView$ScaleType;->CENTER_INSIDE:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v5, v6}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    .line 3417
    iget-object v5, v0, Ld$13;->v:Landroid/widget/ImageView;

    iget-object v6, v0, Ld$13;->h:Landroid/app/Activity;

    const/16 v10, 0x8

    invoke-static {v6, v10}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    iget-object v11, v0, Ld$13;->h:Landroid/app/Activity;

    invoke-static {v11, v10}, Ld;->a(Landroid/content/Context;I)I

    move-result v11

    iget-object v12, v0, Ld$13;->h:Landroid/app/Activity;

    invoke-static {v12, v10}, Ld;->a(Landroid/content/Context;I)I

    move-result v12

    iget-object v8, v0, Ld$13;->h:Landroid/app/Activity;

    invoke-static {v8, v10}, Ld;->a(Landroid/content/Context;I)I

    move-result v8

    invoke-virtual {v5, v6, v11, v12, v8}, Landroid/widget/ImageView;->setPadding(IIII)V

    .line 3418
    iget-object v5, v0, Ld$13;->v:Landroid/widget/ImageView;

    if-eqz v20, :cond_514

    .line 3419
    iget-object v6, v0, Ld$13;->h:Landroid/app/Activity;

    const-string v8, "dhJzFH1lFg=="

    invoke-static {v8}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v8

    const-string v10, "dhIDawhtFQ=="

    invoke-static {v10}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v10

    const/16 v11, 0x1c

    invoke-static {v6, v11, v8, v10}, Ld;->a(Landroid/content/Context;III)Landroid/graphics/drawable/Drawable;

    move-result-object v6

    goto :goto_524

    .line 3420
    :cond_514
    iget-object v6, v0, Ld$13;->h:Landroid/app/Activity;

    invoke-static/range {v22 .. v22}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v8

    const/16 v10, 0x1a

    invoke-static {v6, v10, v8}, Ld;->a(Landroid/content/Context;II)Landroid/graphics/drawable/Drawable;

    move-result-object v6

    .line 3418
    :goto_524
    invoke-virtual {v5, v6}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 3422
    :goto_527
    iget-object v5, v0, Ld$13;->w:Landroid/widget/ImageView;

    iget-object v6, v0, Ld$13;->h:Landroid/app/Activity;

    const/16 v8, 0x10

    const/4 v11, -0x1

    invoke-static {v6, v8, v7, v11}, Ld;->b(Landroid/content/Context;III)Landroid/graphics/drawable/Drawable;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 3423
    iget-object v5, v0, Ld$13;->x:Landroid/widget/TextView;

    if-eqz v20, :cond_53c

    const-string v6, "bWFjBhgZPTBI"

    goto :goto_53e

    :cond_53c
    const-string v6, "FDcyRE4w"

    :goto_53e
    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3425
    iget-object v5, v0, Ld$13;->y:Landroid/widget/TextView;

    if-eqz v20, :cond_54c

    const-string v6, "bWFjBg=="

    goto :goto_54e

    :cond_54c
    const-string v6, "YmRjBg=="

    :goto_54e
    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3426
    iget-object v5, v0, Ld$13;->y:Landroid/widget/TextView;

    if-eqz v20, :cond_55e

    invoke-static/range {v23 .. v23}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    goto :goto_562

    :cond_55e
    invoke-static/range {v22 .. v22}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    :goto_562
    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setTextColor(I)V

    .line 3427
    iget-object v5, v0, Ld$13;->z:Landroid/widget/TextView;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-static/range {v16 .. v16}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    invoke-direct {v6, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    if-eqz v21, :cond_578

    move v8, v2

    goto :goto_579

    :cond_578
    move v8, v3

    :goto_579
    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v8, "ejA="

    invoke-static {v8}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3428
    iget-object v5, v0, Ld$13;->A:Landroid/widget/TextView;

    if-eqz v21, :cond_597

    const-string v6, "BgAC"

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    goto :goto_5a5

    :cond_597
    const-string v6, "BjUwSBg="

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v6

    :goto_5a5
    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3429
    iget-object v5, v0, Ld$13;->A:Landroid/widget/TextView;

    if-eqz v21, :cond_5b1

    invoke-static/range {v33 .. v33}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    goto :goto_5b7

    :cond_5b1
    const-string v6, "dmV2bwFtZQ=="

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    :goto_5b7
    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setTextColor(I)V

    .line 3431
    iget-object v5, v0, Ld$13;->B:Landroid/widget/TextView;

    invoke-virtual {v5, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3432
    iget-object v5, v0, Ld$13;->C:Landroid/widget/TextView;

    invoke-virtual {v5, v15}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    if-eqz v21, :cond_616

    .line 3435
    iget-object v5, v0, Ld$13;->D:Landroid/widget/TextView;

    iget-object v6, v0, Ld$13;->h:Landroid/app/Activity;

    const/4 v8, 0x6

    invoke-static {v6, v8}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    const/4 v10, 0x0

    invoke-static {v13, v6, v10, v10}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 3436
    iget-object v5, v0, Ld$13;->D:Landroid/widget/TextView;

    invoke-virtual {v5, v7}, Landroid/widget/TextView;->setTextColor(I)V

    .line 3437
    iget-object v5, v0, Ld$13;->D:Landroid/widget/TextView;

    const/4 v6, 0x1

    const/4 v11, 0x0

    invoke-virtual {v5, v11, v6}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 3439
    iget-object v5, v0, Ld$13;->E:Landroid/widget/TextView;

    const-string v6, "dhJ3aw0TbQ=="

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    iget-object v8, v0, Ld$13;->h:Landroid/app/Activity;

    const/4 v10, 0x6

    invoke-static {v8, v10}, Ld;->a(Landroid/content/Context;I)I

    move-result v8

    const/4 v10, 0x0

    invoke-static {v6, v8, v10, v10}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 3440
    iget-object v5, v0, Ld$13;->E:Landroid/widget/TextView;

    invoke-static/range {v33 .. v33}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setTextColor(I)V

    .line 3441
    iget-object v5, v0, Ld$13;->E:Landroid/widget/TextView;

    const/4 v11, 0x0

    invoke-virtual {v5, v11, v10}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    goto :goto_661

    :cond_616
    const/4 v10, 0x0

    const/4 v11, 0x0

    .line 3443
    iget-object v5, v0, Ld$13;->E:Landroid/widget/TextView;

    iget-object v6, v0, Ld$13;->h:Landroid/app/Activity;

    const/4 v8, 0x6

    invoke-static {v6, v8}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    invoke-static {v13, v6, v10, v10}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 3444
    iget-object v5, v0, Ld$13;->E:Landroid/widget/TextView;

    invoke-virtual {v5, v7}, Landroid/widget/TextView;->setTextColor(I)V

    .line 3445
    iget-object v5, v0, Ld$13;->E:Landroid/widget/TextView;

    const/4 v6, 0x1

    invoke-virtual {v5, v11, v6}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 3447
    iget-object v5, v0, Ld$13;->D:Landroid/widget/TextView;

    const-string v6, "dhJ3aw0TbQ=="

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    iget-object v8, v0, Ld$13;->h:Landroid/app/Activity;

    const/4 v10, 0x6

    invoke-static {v8, v10}, Ld;->a(Landroid/content/Context;I)I

    move-result v8

    const/4 v10, 0x0

    invoke-static {v6, v8, v10, v10}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 3448
    iget-object v5, v0, Ld$13;->D:Landroid/widget/TextView;

    invoke-static/range {v33 .. v33}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setTextColor(I)V

    .line 3449
    iget-object v5, v0, Ld$13;->D:Landroid/widget/TextView;

    const/4 v11, 0x0

    invoke-virtual {v5, v11, v10}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 3451
    :goto_661
    iget-object v5, v0, Ld$13;->D:Landroid/widget/TextView;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-static/range {v16 .. v16}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    invoke-direct {v6, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, "dXtmSVks"

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v5, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3452
    iget-object v2, v0, Ld$13;->E:Landroid/widget/TextView;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-static/range {v17 .. v17}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v3, "dXtmSVks"

    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3454
    iget-object v2, v0, Ld$13;->F:Landroid/widget/TextView;

    invoke-virtual {v4}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3455
    iget-object v2, v0, Ld$13;->F:Landroid/widget/TextView;

    iget-object v3, v0, Ld$13;->h:Landroid/app/Activity;

    const/16 v8, 0xa

    invoke-static {v3, v8}, Ld;->a(Landroid/content/Context;I)I

    move-result v3

    const/4 v10, 0x0

    invoke-static {v7, v9, v3, v10, v10}, Ld;->a(IIIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 3456
    iget-object v2, v0, Ld$13;->G:Landroid/widget/TextView;

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v5, "BjUwSBg="

    invoke-static {v5}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-direct {v3, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v5, "BjUwSBg="

    invoke-static {v5}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "dSMvWVB1GSlDTD04Pw=="

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3457
    iget-object v1, v0, Ld$13;->G:Landroid/widget/TextView;

    invoke-virtual {v1, v7}, Landroid/widget/TextView;->setTextColor(I)V

    .line 3459
    iget-object v1, v0, Ld$13;->h:Landroid/app/Activity;

    const/16 v2, 0xe

    invoke-static {v1, v2}, Ld;->a(Landroid/content/Context;I)I

    move-result v1

    iget-object v3, v0, Ld$13;->h:Landroid/app/Activity;

    const/high16 v4, 0x40200000  # 2.5f

    invoke-static {v3, v4}, Ld;->a(Landroid/content/Context;F)I

    move-result v3

    const/4 v4, -0x1

    invoke-static {v4, v1, v3, v7}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v1

    .line 3460
    const-string v3, "dhJ+a3kTFw=="

    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    iget-object v4, v0, Ld$13;->h:Landroid/app/Activity;

    invoke-static {v4, v2}, Ld;->a(Landroid/content/Context;I)I

    move-result v2

    iget-object v4, v0, Ld$13;->h:Landroid/app/Activity;

    const/4 v6, 0x1

    invoke-static {v4, v6}, Ld;->a(Landroid/content/Context;I)I

    move-result v4

    invoke-static/range {v28 .. v28}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    invoke-static {v3, v2, v4, v5}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    .line 3462
    iget-object v3, v0, Ld$13;->H:Landroid/widget/LinearLayout;

    if-eqz v21, :cond_725

    move-object v4, v1

    goto :goto_726

    :cond_725
    move-object v4, v2

    :goto_726
    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 3463
    iget-object v3, v0, Ld$13;->I:Landroid/widget/LinearLayout;

    if-nez v21, :cond_72e

    goto :goto_72f

    :cond_72e
    move-object v1, v2

    :goto_72f
    invoke-virtual {v3, v1}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 3465
    iget-object v1, v0, Ld$13;->J:Landroid/widget/TextView;

    if-eqz v21, :cond_73b

    invoke-static/range {v29 .. v29}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    goto :goto_73f

    :cond_73b
    invoke-static/range {v33 .. v33}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    :goto_73f
    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 3466
    iget-object v1, v0, Ld$13;->K:Landroid/widget/TextView;

    if-nez v21, :cond_74f

    invoke-static/range {v29 .. v29}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    goto :goto_753

    :cond_74f
    invoke-static/range {v33 .. v33}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    :goto_753
    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextColor(I)V

    if-eqz v21, :cond_75d

    goto :goto_75e

    :cond_75d
    move-object v14, v15

    .line 3469
    :goto_75e
    iget-object v1, v0, Ld$13;->L:Landroid/widget/Button;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "ACQhX1kxMWZZV3U="

    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    if-eqz v20, :cond_770

    const-string v3, "BSYpDW4cBA=="

    goto :goto_772

    :cond_770
    const-string v3, "FzU1RFt1Ag99"

    :goto_772
    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "dXw="

    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "fA=="

    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 3470
    iget-object v1, v0, Ld$13;->L:Landroid/widget/Button;

    iget-object v2, v0, Ld$13;->h:Landroid/app/Activity;

    const/16 v3, 0x10

    invoke-static {v2, v3}, Ld;->a(Landroid/content/Context;I)I

    move-result v2

    move/from16 v3, v27

    const/4 v10, 0x0

    invoke-static {v7, v3, v2, v10, v10}, Ld;->a(IIIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 3471
    iget-object v1, v0, Ld$13;->L:Landroid/widget/Button;

    const/4 v11, 0x0

    invoke-virtual {v1, v11, v11, v11, v11}, Landroid/widget/Button;->setCompoundDrawablesWithIntrinsicBounds(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 3472
    iget-object v1, v0, Ld$13;->L:Landroid/widget/Button;

    invoke-virtual {v1, v10}, Landroid/widget/Button;->setCompoundDrawablePadding(I)V

    return-void

    :cond_7b5
    const/16 v10, 0x8

    const/16 v12, 0x16

    const/16 v19, 0xe

    const/16 v34, 0x3

    const/16 v36, -0x1

    .line 3389
    iget-object v8, v0, Ld$13;->r:[Landroid/widget/ImageView;

    aget-object v8, v8, v11

    if-eqz v8, :cond_7c8

    invoke-virtual {v8, v5}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 3390
    :cond_7c8
    iget-object v8, v0, Ld$13;->s:[Landroid/widget/LinearLayout;

    aget-object v8, v8, v11

    if-eqz v8, :cond_7d1

    invoke-virtual {v8, v6}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 3391
    :cond_7d1
    iget-object v8, v0, Ld$13;->q:[Landroid/widget/TextView;

    aget-object v8, v8, v11

    if-eqz v8, :cond_7ee

    const-string v24, "dm1ybAsXbA=="

    invoke-static/range {v24 .. v24}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v24

    invoke-static/range {v24 .. v24}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v10

    invoke-virtual {v8, v10}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v8, v0, Ld$13;->q:[Landroid/widget/TextView;

    aget-object v8, v8, v11

    const/4 v10, 0x0

    const/4 v12, 0x0

    invoke-virtual {v8, v10, v12}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    goto :goto_7ef

    :cond_7ee
    const/4 v12, 0x0

    :goto_7ef
    add-int/lit8 v11, v11, 0x1

    goto/16 :goto_3e0

    :cond_7f3
    const/4 v12, 0x0

    const/16 v19, 0xe

    const/16 v30, 0xa

    const/16 v34, 0x3

    const/16 v35, 0x8

    const/16 v36, -0x1

    .line 3384
    iget-object v11, v0, Ld$13;->r:[Landroid/widget/ImageView;

    aget-object v11, v11, v10

    if-eqz v11, :cond_807

    invoke-virtual {v11, v8}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 3385
    :cond_807
    iget-object v11, v0, Ld$13;->s:[Landroid/widget/LinearLayout;

    aget-object v11, v11, v10

    move-object/from16 v12, v25

    if-eqz v11, :cond_812

    invoke-virtual {v11, v12}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 3386
    :cond_812
    iget-object v11, v0, Ld$13;->q:[Landroid/widget/TextView;

    aget-object v11, v11, v10

    if-eqz v11, :cond_82f

    invoke-static/range {v29 .. v29}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v24

    move-object/from16 v25, v1

    invoke-static/range {v24 .. v24}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v11, v1}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v1, v0, Ld$13;->q:[Landroid/widget/TextView;

    aget-object v1, v1, v10

    const/4 v0, 0x1

    const/4 v11, 0x0

    invoke-virtual {v1, v11, v0}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    goto :goto_833

    :cond_82f
    move-object/from16 v25, v1

    const/4 v0, 0x1

    const/4 v11, 0x0

    :goto_833
    add-int/lit8 v10, v10, 0x1

    move-object/from16 v0, p0

    move-object/from16 v1, v25

    move-object/from16 v25, v12

    goto/16 :goto_3dc
.end method
