# classes88.dex

.class Le$3$2;
.super Ljava/lang/Object;
.source "FoxSource"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Le$3;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Le$3;

.field private final synthetic b:Landroid/app/Activity;


# direct methods
.method constructor <init>(Le$3;Landroid/app/Activity;)V
    .registers 3

    .line 371
    iput-object p1, p0, Le$3$2;->a:Le$3;

    iput-object p2, p0, Le$3$2;->b:Landroid/app/Activity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 2

    .line 374
    iget-object v0, p0, Le$3$2;->b:Landroid/app/Activity;

    invoke-static {v0}, Le;->f(Landroid/app/Activity;)V

    return-void
.end method
