# classes88.dex

.class Ld$16$1;
.super Ljava/lang/Object;
.source "FoxSource"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ld$16;->onClick(Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ld$16;

.field private final synthetic b:Landroid/app/Activity;

.field private final synthetic c:Landroid/widget/TextView;

.field private final synthetic d:Landroid/view/View;

.field private final synthetic e:Landroid/widget/TextView;

.field private final synthetic f:Landroid/widget/Button;

.field private final synthetic g:[Landroid/widget/TextView;


# direct methods
.method constructor <init>(Ld$16;Landroid/app/Activity;Landroid/widget/TextView;Landroid/view/View;Landroid/widget/TextView;Landroid/widget/Button;[Landroid/widget/TextView;)V
    .registers 8

    .line 3494
    iput-object p1, p0, Ld$16$1;->a:Ld$16;

    iput-object p2, p0, Ld$16$1;->b:Landroid/app/Activity;

    iput-object p3, p0, Ld$16$1;->c:Landroid/widget/TextView;

    iput-object p4, p0, Ld$16$1;->d:Landroid/view/View;

    iput-object p5, p0, Ld$16$1;->e:Landroid/widget/TextView;

    iput-object p6, p0, Ld$16$1;->f:Landroid/widget/Button;

    iput-object p7, p0, Ld$16$1;->g:[Landroid/widget/TextView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 10

    .line 3497
    iget-object v0, p0, Ld$16$1;->b:Landroid/app/Activity;

    invoke-static {v0}, Ld;->c(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    .line 3498
    iget-object v1, p0, Ld$16$1;->b:Landroid/app/Activity;

    invoke-static {}, Ld;->r()Ljava/lang/String;

    move-result-object v2

    const/4 v3, 0x0

    invoke-virtual {v1, v2, v3}, Landroid/app/Activity;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v1

    .line 3499
    invoke-static {}, Le;->aP()Ljava/lang/String;

    move-result-object v2

    const-string v4, "MTUvQUEKJDRIXAo5J1U="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/16 v5, 0x32

    invoke-interface {v1, v4, v5}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v4

    invoke-interface {v1, v2, v4}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v2

    .line 3500
    invoke-static {}, Le;->aQ()Ljava/lang/String;

    move-result-object v4

    const-string v5, "MTUvQUEKNy5MTAo5J1U="

    invoke-static {v5}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/16 v6, 0xa

    invoke-interface {v1, v5, v6}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v5

    invoke-interface {v1, v4, v5}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v1

    .line 3501
    iget-object v4, p0, Ld$16$1;->b:Landroid/app/Activity;

    invoke-static {v4}, Ld;->g(Landroid/content/Context;)I

    move-result v4

    .line 3502
    iget-object v5, p0, Ld$16$1;->b:Landroid/app/Activity;

    invoke-static {v5}, Ld;->h(Landroid/content/Context;)I

    move-result v5

    .line 3503
    iget-object v6, p0, Ld$16$1;->c:Landroid/widget/TextView;

    new-instance v7, Ljava/lang/StringBuilder;

    const-string v8, "FBcSZG4QbmY="

    invoke-static {v8}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-direct {v7, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3504
    new-instance v6, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v6}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const/4 v7, 0x1

    .line 3505
    invoke-virtual {v6, v7}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    .line 3506
    sget-object v7, Ld;->c:Ljava/lang/String;

    invoke-virtual {v7, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    const-string v8, "dmV2bwFtZQ=="

    if-eqz v7, :cond_81

    .line 3507
    const-string v7, "dmN+GwgQFQ=="

    invoke-static {v7}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v7

    invoke-virtual {v6, v7}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    goto :goto_a2

    .line 3508
    :cond_81
    sget-object v7, Ld;->b:Ljava/lang/String;

    invoke-virtual {v7, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_97

    .line 3509
    const-string v7, "dmR+FAkXZg=="

    invoke-static {v7}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v7

    invoke-virtual {v6, v7}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    goto :goto_a2

    .line 3511
    :cond_97
    invoke-static {v8}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v7

    invoke-virtual {v6, v7}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 3513
    :goto_a2
    iget-object v7, p0, Ld$16$1;->d:Landroid/view/View;

    invoke-virtual {v7, v6}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 3514
    sget-object v6, Ld;->c:Ljava/lang/String;

    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_111

    sget-object v6, Ld;->b:Ljava/lang/String;

    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_b8

    goto :goto_111

    .line 3519
    :cond_b8
    iget-object v6, p0, Ld$16$1;->e:Landroid/widget/TextView;

    new-instance v7, Ljava/lang/StringBuilder;

    const-string v8, "BSYjSUtvdA=="

    invoke-static {v8}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-direct {v7, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v4, "eg=="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, "dbbGjxgWPCdZS290"

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v6, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3520
    iget-object v1, p0, Ld$16$1;->e:Landroid/widget/TextView;

    const-string v2, "dmJyGgxtFg=="

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 3521
    iget-object v1, p0, Ld$16$1;->f:Landroid/widget/Button;

    invoke-virtual {v1, v3}, Landroid/widget/Button;->setVisibility(I)V

    .line 3522
    iget-object v1, p0, Ld$16$1;->f:Landroid/widget/Button;

    const-string v2, "FjsoWVE7ISMNficxIw=="

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    goto :goto_130

    .line 3515
    :cond_111
    :goto_111
    iget-object v1, p0, Ld$16$1;->e:Landroid/widget/TextView;

    const-string v2, "ATstSFYmbmZ4Vjk9K0RMMDA="

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3516
    iget-object v1, p0, Ld$16$1;->e:Landroid/widget/TextView;

    invoke-static {v8}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 3517
    iget-object v1, p0, Ld$16$1;->f:Landroid/widget/Button;

    const/16 v2, 0x8

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setVisibility(I)V

    .line 3524
    :goto_130
    iget-object v1, p0, Ld$16$1;->g:[Landroid/widget/TextView;

    aget-object v1, v1, v3

    if-eqz v1, :cond_143

    .line 3525
    iget-object v2, p0, Ld$16$1;->b:Landroid/app/Activity;

    invoke-static {v2}, Ld;->q(Landroid/content/Context;)I

    move-result v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3527
    :cond_143
    iget-object v1, p0, Ld$16$1;->g:[Landroid/widget/TextView;

    const/4 v2, 0x3

    aget-object v1, v1, v2

    if-eqz v1, :cond_157

    .line 3528
    iget-object v2, p0, Ld$16$1;->b:Landroid/app/Activity;

    invoke-static {v2}, Ld;->r(Landroid/content/Context;)I

    move-result v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3530
    :cond_157
    iget-object v1, p0, Ld$16$1;->b:Landroid/app/Activity;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v4, "Bi0oTl0xdWZuTScmI0NMdQQqTFZvdA=="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void
.end method
