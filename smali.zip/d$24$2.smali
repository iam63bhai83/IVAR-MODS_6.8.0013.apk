# classes88.dex

.class Ld$24$2;
.super Ljava/lang/Object;
.source "FoxSource"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ld$24;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ld$24;

.field private final synthetic b:[Z

.field private final synthetic c:Landroid/app/Activity;

.field private final synthetic d:[I

.field private final synthetic e:Ljava/lang/Runnable;

.field private final synthetic f:Landroid/os/Handler;


# direct methods
.method constructor <init>(Ld$24;[ZLandroid/app/Activity;[ILjava/lang/Runnable;Landroid/os/Handler;)V
    .registers 7

    .line 3906
    iput-object p1, p0, Ld$24$2;->a:Ld$24;

    iput-object p2, p0, Ld$24$2;->b:[Z

    iput-object p3, p0, Ld$24$2;->c:Landroid/app/Activity;

    iput-object p4, p0, Ld$24$2;->d:[I

    iput-object p5, p0, Ld$24$2;->e:Ljava/lang/Runnable;

    iput-object p6, p0, Ld$24$2;->f:Landroid/os/Handler;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 4

    .line 3909
    iget-object v0, p0, Ld$24$2;->b:[Z

    const/4 v1, 0x0

    aget-boolean v0, v0, v1

    if-nez v0, :cond_2c

    iget-object v0, p0, Ld$24$2;->c:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->isFinishing()Z

    move-result v0

    if-eqz v0, :cond_10

    goto :goto_2c

    .line 3910
    :cond_10
    iget-object v0, p0, Ld$24$2;->d:[I

    aget v2, v0, v1

    add-int/lit8 v2, v2, 0x1

    aput v2, v0, v1

    .line 3911
    iget-object v0, p0, Ld$24$2;->e:Ljava/lang/Runnable;

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    .line 3912
    iget-object v0, p0, Ld$24$2;->d:[I

    aget v0, v0, v1

    const/16 v1, 0x28

    if-ge v0, v1, :cond_2c

    .line 3913
    iget-object v0, p0, Ld$24$2;->f:Landroid/os/Handler;

    const-wide/16 v1, 0x9c4

    invoke-virtual {v0, p0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_2c
    :goto_2c
    return-void
.end method
