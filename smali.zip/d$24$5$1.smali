# classes88.dex

.class Ld$24$5$1;
.super Ljava/lang/Object;
.source "FoxSource"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ld$24$5;->onClick(Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ld$24$5;

.field private final synthetic b:Ljava/lang/String;

.field private final synthetic c:Ljava/lang/String;

.field private final synthetic d:Ljava/lang/String;

.field private final synthetic e:Ljava/lang/String;

.field private final synthetic f:Landroid/app/Activity;

.field private final synthetic g:Landroid/widget/Button;

.field private final synthetic h:[Z

.field private final synthetic i:Landroid/content/SharedPreferences;

.field private final synthetic j:Landroid/app/Dialog;

.field private final synthetic k:Ljava/lang/Runnable;

.field private final synthetic l:Landroid/widget/TextView;


# direct methods
.method constructor <init>(Ld$24$5;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/app/Activity;Landroid/widget/Button;[ZLandroid/content/SharedPreferences;Landroid/app/Dialog;Ljava/lang/Runnable;Landroid/widget/TextView;)V
    .registers 13

    .line 3949
    iput-object p1, p0, Ld$24$5$1;->a:Ld$24$5;

    iput-object p2, p0, Ld$24$5$1;->b:Ljava/lang/String;

    iput-object p3, p0, Ld$24$5$1;->c:Ljava/lang/String;

    iput-object p4, p0, Ld$24$5$1;->d:Ljava/lang/String;

    iput-object p5, p0, Ld$24$5$1;->e:Ljava/lang/String;

    iput-object p6, p0, Ld$24$5$1;->f:Landroid/app/Activity;

    iput-object p7, p0, Ld$24$5$1;->g:Landroid/widget/Button;

    iput-object p8, p0, Ld$24$5$1;->h:[Z

    iput-object p9, p0, Ld$24$5$1;->i:Landroid/content/SharedPreferences;

    iput-object p10, p0, Ld$24$5$1;->j:Landroid/app/Dialog;

    iput-object p11, p0, Ld$24$5$1;->k:Ljava/lang/Runnable;

    iput-object p12, p0, Ld$24$5$1;->l:Landroid/widget/TextView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 14

    .line 3953
    const-string v0, "aA=="

    const-string v1, "cw=="

    :try_start_4
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-static {}, Ld;->c()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v3, "ajUlWVE6OntOUDA3LXJMMDgjSko0ORleTDQgM14="

    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 3954
    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Le;->z()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, p0, Ld$24$5$1;->b:Ljava/lang/String;

    invoke-static {v3}, Landroid/net/Uri;->encode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 3955
    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Le;->D()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, p0, Ld$24$5$1;->c:Ljava/lang/String;

    invoke-static {v3}, Landroid/net/Uri;->encode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 3956
    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Le;->E()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v3, p0, Ld$24$5$1;->d:Ljava/lang/String;

    invoke-static {v3}, Landroid/net/Uri;->encode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 3957
    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Le;->F()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, Ld$24$5$1;->e:Ljava/lang/String;

    invoke-static {v0}, Landroid/net/Uri;->encode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 3953
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 3958
    iget-object v1, p0, Ld$24$5$1;->f:Landroid/app/Activity;

    invoke-static {v0, v1}, Le;->a(Ljava/lang/String;Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    .line 3960
    new-instance v1, Ljava/net/URL;

    invoke-direct {v1, v0}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v0

    check-cast v0, Ljava/net/HttpURLConnection;

    .line 3961
    const-string v1, "EhES"

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    const/16 v1, 0x1770

    .line 3962
    invoke-virtual {v0, v1}, Ljava/net/HttpURLConnection;->setConnectTimeout(I)V

    .line 3963
    invoke-virtual {v0, v1}, Ljava/net/HttpURLConnection;->setReadTimeout(I)V

    .line 3964
    iget-object v1, p0, Ld$24$5$1;->f:Landroid/app/Activity;

    invoke-static {v0, v1}, Le;->a(Ljava/net/URLConnection;Landroid/content/Context;)V

    .line 3966
    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v1

    .line 3967
    new-instance v2, Ljava/io/InputStreamReader;

    const/16 v3, 0xc8

    if-lt v1, v3, :cond_d0

    const/16 v3, 0x190

    if-ge v1, v3, :cond_d0

    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v1

    goto :goto_d4

    :cond_d0
    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getErrorStream()Ljava/io/InputStream;

    move-result-object v1

    :goto_d4
    const-string v3, "AAAAAAA="

    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v1, v3}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/lang/String;)V

    .line 3968
    new-instance v1, Ljava/io/BufferedReader;

    invoke-direct {v1, v2}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    .line 3969
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 3971
    :goto_e7
    invoke-virtual {v1}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v3

    if-nez v3, :cond_17e

    .line 3974
    invoke-virtual {v1}, Ljava/io/BufferedReader;->close()V

    .line 3975
    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 3977
    new-instance v0, Lorg/json/JSONObject;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 3978
    invoke-static {}, Le;->S()Ljava/lang/String;

    move-result-object v1

    const-string v2, "JiAnWU0m"

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_124

    invoke-static {}, Le;->T()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_147

    invoke-static {}, Le;->U()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_147

    .line 3979
    :cond_124
    invoke-static {}, Le;->T()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {}, Le;->U()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    iget-object v3, p0, Ld$24$5$1;->f:Landroid/app/Activity;

    invoke-static {v1, v2, v3}, Le;->a(Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_147

    .line 3980
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_147

    .line 3981
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0, v1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    .line 3985
    :cond_147
    const-string v1, "IzE0RF48MSI="

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v1

    if-nez v1, :cond_162

    const-string v1, "ITEqSF8nNStyUjo9KEhc"

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->optBoolean(Ljava/lang/String;Z)Z

    move-result v0

    if-nez v0, :cond_162

    const/4 v6, 0x0

    goto :goto_164

    :cond_162
    const/4 v2, 0x1

    const/4 v6, 0x1

    .line 3987
    :goto_164
    iget-object v0, p0, Ld$24$5$1;->f:Landroid/app/Activity;

    new-instance v3, Ld$24$5$1$1;

    iget-object v5, p0, Ld$24$5$1;->g:Landroid/widget/Button;

    iget-object v7, p0, Ld$24$5$1;->h:[Z

    iget-object v8, p0, Ld$24$5$1;->i:Landroid/content/SharedPreferences;

    iget-object v9, p0, Ld$24$5$1;->f:Landroid/app/Activity;

    iget-object v10, p0, Ld$24$5$1;->j:Landroid/app/Dialog;

    iget-object v11, p0, Ld$24$5$1;->k:Ljava/lang/Runnable;

    iget-object v12, p0, Ld$24$5$1;->l:Landroid/widget/TextView;
    :try_end_176
    .catchall {:try_start_4 .. :try_end_176} :catchall_186

    move-object v4, p0

    :try_start_177
    invoke-direct/range {v3 .. v12}, Ld$24$5$1$1;-><init>(Ld$24$5$1;Landroid/widget/Button;Z[ZLandroid/content/SharedPreferences;Landroid/app/Activity;Landroid/app/Dialog;Ljava/lang/Runnable;Landroid/widget/TextView;)V

    invoke-virtual {v0, v3}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void

    :cond_17e
    move-object v4, p0

    .line 3972
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    :try_end_182
    .catchall {:try_start_177 .. :try_end_182} :catchall_184

    goto/16 :goto_e7

    :catchall_184
    move-exception v0

    goto :goto_188

    :catchall_186
    move-exception v0

    move-object v4, p0

    .line 4009
    :goto_188
    iget-object v1, v4, Ld$24$5$1;->f:Landroid/app/Activity;

    new-instance v2, Ld$24$5$1$2;

    iget-object v3, v4, Ld$24$5$1;->g:Landroid/widget/Button;

    iget-object v5, v4, Ld$24$5$1;->f:Landroid/app/Activity;

    invoke-direct {v2, p0, v3, v5, v0}, Ld$24$5$1$2;-><init>(Ld$24$5$1;Landroid/widget/Button;Landroid/app/Activity;Ljava/lang/Throwable;)V

    invoke-virtual {v1, v2}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void
.end method
