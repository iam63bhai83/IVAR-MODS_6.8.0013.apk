# classes88.dex

.class Ld$24$5$1$2;
.super Ljava/lang/Object;
.source "FoxSource"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ld$24$5$1;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ld$24$5$1;

.field private final synthetic b:Landroid/widget/Button;

.field private final synthetic c:Landroid/app/Activity;

.field private final synthetic d:Ljava/lang/Throwable;


# direct methods
.method constructor <init>(Ld$24$5$1;Landroid/widget/Button;Landroid/app/Activity;Ljava/lang/Throwable;)V
    .registers 5

    .line 4009
    iput-object p1, p0, Ld$24$5$1$2;->a:Ld$24$5$1;

    iput-object p2, p0, Ld$24$5$1$2;->b:Landroid/widget/Button;

    iput-object p3, p0, Ld$24$5$1$2;->c:Landroid/app/Activity;

    iput-object p4, p0, Ld$24$5$1$2;->d:Ljava/lang/Throwable;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 4

    .line 4012
    iget-object v0, p0, Ld$24$5$1$2;->b:Landroid/widget/Button;

    const-string v1, "FjwjTlN1AiNfUTM9JUxMPDsoDWshNTJYSw=="

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 4013
    iget-object v0, p0, Ld$24$5$1$2;->b:Landroid/widget/Button;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setEnabled(Z)V

    .line 4014
    iget-object v0, p0, Ld$24$5$1$2;->c:Landroid/app/Activity;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "FjsoQ102IC9CVnU3LkhbPm5m"

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, Ld$24$5$1$2;->d:Ljava/lang/Throwable;

    invoke-virtual {v2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x0

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void
.end method
