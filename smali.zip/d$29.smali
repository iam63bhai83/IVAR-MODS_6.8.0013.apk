# classes88.dex

.class Ld$29;
.super Ljava/lang/Object;
.source "FoxSource"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ld;->d(Landroid/app/Activity;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private final synthetic a:Landroid/app/Activity;

.field private final synthetic b:Ljava/lang/String;

.field private final synthetic c:I

.field private final synthetic d:I

.field private final synthetic e:I

.field private final synthetic f:I

.field private final synthetic g:Landroid/content/SharedPreferences;


# direct methods
.method constructor <init>(Landroid/app/Activity;Ljava/lang/String;IIIILandroid/content/SharedPreferences;)V
    .registers 8

    .line 783
    iput-object p1, p0, Ld$29;->a:Landroid/app/Activity;

    iput-object p2, p0, Ld$29;->b:Ljava/lang/String;

    iput p3, p0, Ld$29;->c:I

    iput p4, p0, Ld$29;->d:I

    iput p5, p0, Ld$29;->e:I

    iput p6, p0, Ld$29;->f:I

    iput-object p7, p0, Ld$29;->g:Landroid/content/SharedPreferences;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 14

    .line 787
    const-string v1, "Ezs+fVQ0OgtMVjQzI18="

    const-string v0, "MT0nQVcyCzVYWiY3NERIIT0pQ2clOCdDSw=="

    const/4 v2, 0x0

    :try_start_5
    new-instance v4, Landroid/app/Dialog;

    iget-object v3, p0, Ld$29;->a:Landroid/app/Activity;

    invoke-direct {v4, v3}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    const/4 v12, 0x1

    .line 788
    invoke-virtual {v4, v12}, Landroid/app/Dialog;->requestWindowFeature(I)Z
    :try_end_10
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_10} :catch_164

    const/4 v3, 0x0

    .line 792
    :try_start_11
    new-instance v5, Ljava/lang/StringBuilder;

    iget-object v6, p0, Ld$29;->a:Landroid/app/Activity;

    invoke-virtual {v6}, Landroid/app/Activity;->getPackageName()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v6, "ewZiQVksOzNZ"

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v5

    .line 793
    invoke-static {v0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/Class;->getField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/lang/reflect/Field;->getInt(Ljava/lang/Object;)I

    move-result v5
    :try_end_3d
    .catchall {:try_start_11 .. :try_end_3d} :catchall_3e

    goto :goto_40

    :catchall_3e
    nop

    const/4 v5, 0x0

    :goto_40
    if-nez v5, :cond_5a

    .line 798
    :try_start_42
    const-string v6, "NjsrA1EjNTQDVTowNQNZPHoUCVQ0LSlYTA=="

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v6

    .line 799
    invoke-static {v0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/Class;->getField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v6

    invoke-virtual {v6, v3}, Ljava/lang/reflect/Field;->getInt(Ljava/lang/Object;)I

    move-result v5
    :try_end_58
    .catchall {:try_start_42 .. :try_end_58} :catchall_59

    goto :goto_5a

    :catchall_59
    nop

    .line 803
    :cond_5a
    :goto_5a
    const-string v6, "OTU/Qk0h"

    if-nez v5, :cond_78

    .line 805
    :try_start_5e
    iget-object v7, p0, Ld$29;->a:Landroid/app/Activity;

    invoke-virtual {v7}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v7

    invoke-static {v0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    iget-object v10, p0, Ld$29;->a:Landroid/app/Activity;

    invoke-virtual {v10}, Landroid/app/Activity;->getPackageName()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v7, v8, v9, v10}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v5
    :try_end_76
    .catchall {:try_start_5e .. :try_end_76} :catchall_77

    goto :goto_78

    :catchall_77
    nop

    :cond_78
    :goto_78
    if-nez v5, :cond_94

    .line 811
    :try_start_7a
    iget-object v7, p0, Ld$29;->a:Landroid/app/Activity;

    invoke-virtual {v7}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v7

    invoke-static {v0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const-string v8, "NjsrA1EjNTQDVTowNQNZPA=="

    invoke-static {v8}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v0, v6, v8}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v5
    :try_end_92
    .catchall {:try_start_7a .. :try_end_92} :catchall_93

    goto :goto_94

    :catchall_93
    nop

    :cond_94
    :goto_94
    if-eqz v5, :cond_b2

    .line 820
    :try_start_96
    iget-object v0, p0, Ld$29;->a:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->getLayoutInflater()Landroid/view/LayoutInflater;

    move-result-object v0

    invoke-virtual {v0, v5, v3}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v3
    :try_end_a0
    .catchall {:try_start_96 .. :try_end_a0} :catchall_a4

    if-eqz v3, :cond_b2

    const/4 v0, 0x1

    goto :goto_b3

    :catchall_a4
    move-exception v0

    .line 825
    :try_start_a5
    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v6, "ECY0Qkp1PShLVDQgL0NfdTAvTFQ6MxleTTcnJV9RJSAvQlYKJCpMViY="

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v5, v6, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_b2
    const/4 v0, 0x0

    :goto_b3
    if-nez v3, :cond_c7

    .line 832
    iget-object v3, p0, Ld$29;->a:Landroid/app/Activity;

    iget-object v5, p0, Ld$29;->b:Ljava/lang/String;

    iget v6, p0, Ld$29;->c:I

    iget v7, p0, Ld$29;->d:I

    iget v8, p0, Ld$29;->e:I

    iget v9, p0, Ld$29;->f:I

    iget-object v10, p0, Ld$29;->g:Landroid/content/SharedPreferences;

    invoke-static/range {v3 .. v10}, Ld;->a(Landroid/app/Activity;Landroid/app/Dialog;Ljava/lang/String;IIIILandroid/content/SharedPreferences;)Landroid/view/View;

    move-result-object v3

    :cond_c7
    move-object v5, v3

    .line 835
    iget-object v3, p0, Ld$29;->a:Landroid/app/Activity;

    invoke-static {v3}, Ld;->s(Landroid/content/Context;)Landroid/graphics/drawable/Drawable;

    move-result-object v3

    .line 836
    invoke-virtual {v5, v3}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 v3, 0x0

    .line 838
    invoke-virtual {v5, v3}, Landroid/view/View;->setElevation(F)V

    .line 839
    invoke-virtual {v5, v3}, Landroid/view/View;->setTranslationZ(F)V

    .line 840
    invoke-virtual {v5, v12}, Landroid/view/View;->setClipToOutline(Z)V

    .line 843
    invoke-virtual {v4, v5}, Landroid/app/Dialog;->setContentView(Landroid/view/View;)V

    if-eqz v0, :cond_f3

    if-eqz v5, :cond_f3

    .line 846
    iget-object v3, p0, Ld$29;->a:Landroid/app/Activity;

    iget-object v6, p0, Ld$29;->b:Ljava/lang/String;

    iget v7, p0, Ld$29;->c:I

    iget v8, p0, Ld$29;->d:I

    iget v9, p0, Ld$29;->e:I

    iget v10, p0, Ld$29;->f:I

    iget-object v11, p0, Ld$29;->g:Landroid/content/SharedPreferences;

    invoke-static/range {v3 .. v11}, Ld;->a(Landroid/app/Activity;Landroid/app/Dialog;Landroid/view/View;Ljava/lang/String;IIIILandroid/content/SharedPreferences;)V

    .line 849
    :cond_f3
    invoke-virtual {v4, v12}, Landroid/app/Dialog;->setCancelable(Z)V

    .line 850
    invoke-virtual {v4}, Landroid/app/Dialog;->show()V

    .line 852
    invoke-virtual {v4}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    if-eqz v0, :cond_15e

    .line 854
    new-instance v3, Landroid/graphics/drawable/ColorDrawable;

    invoke-direct {v3, v2}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    invoke-virtual {v0, v3}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    const/16 v3, 0x51

    .line 856
    invoke-virtual {v0, v3}, Landroid/view/Window;->setGravity(I)V

    const/4 v3, 0x2

    .line 858
    invoke-virtual {v0, v3}, Landroid/view/Window;->addFlags(I)V

    .line 859
    invoke-virtual {v0}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    move-result-object v3

    const v4, 0x3ee66666  # 0.45f

    .line 860
    iput v4, v3, Landroid/view/WindowManager$LayoutParams;->dimAmount:F

    .line 862
    iget-object v4, p0, Ld$29;->a:Landroid/app/Activity;

    invoke-virtual {v4}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    invoke-virtual {v4}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v4

    .line 863
    iget v6, v4, Landroid/util/DisplayMetrics;->widthPixels:I

    .line 864
    iget v4, v4, Landroid/util/DisplayMetrics;->heightPixels:I

    int-to-float v6, v6

    const v7, 0x3f70a3d7  # 0.94f

    mul-float v6, v6, v7

    float-to-int v6, v6

    .line 866
    iget-object v7, p0, Ld$29;->a:Landroid/app/Activity;

    const/16 v8, 0x1ae

    invoke-static {v7, v8}, Ld;->a(Landroid/content/Context;I)I

    move-result v7

    invoke-static {v6, v7}, Ljava/lang/Math;->min(II)I

    move-result v6

    int-to-float v4, v4

    const v7, 0x3f47ae14  # 0.78f

    mul-float v4, v4, v7

    float-to-int v4, v4

    .line 867
    iget-object v7, p0, Ld$29;->a:Landroid/app/Activity;

    const/16 v8, 0x26c

    invoke-static {v7, v8}, Ld;->a(Landroid/content/Context;I)I

    move-result v7

    invoke-static {v4, v7}, Ljava/lang/Math;->min(II)I

    move-result v4

    .line 869
    iput v6, v3, Landroid/view/WindowManager$LayoutParams;->width:I

    .line 870
    iput v4, v3, Landroid/view/WindowManager$LayoutParams;->height:I

    .line 872
    iget-object v4, p0, Ld$29;->a:Landroid/app/Activity;

    const/16 v6, 0x10

    invoke-static {v4, v6}, Ld;->a(Landroid/content/Context;I)I

    move-result v4

    iput v4, v3, Landroid/view/WindowManager$LayoutParams;->y:I

    .line 874
    invoke-virtual {v0, v3}, Landroid/view/Window;->setAttributes(Landroid/view/WindowManager$LayoutParams;)V

    .line 877
    :cond_15e
    iget-object v0, p0, Ld$29;->a:Landroid/app/Activity;

    invoke-static {v5, v0}, Ld;->a(Landroid/view/View;Landroid/content/Context;)V
    :try_end_163
    .catch Ljava/lang/Exception; {:try_start_a5 .. :try_end_163} :catch_164

    goto :goto_1a8

    :catch_164
    move-exception v0

    .line 880
    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "JjwpWmg5NShefDw1KkJfdTE0X1cnbmY="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v1, v3, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 881
    iget-object v0, p0, Ld$29;->a:Landroid/app/Activity;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v3, "Ezs+DXkcdBZBWTsnfA0="

    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v3, p0, Ld$29;->b:Ljava/lang/String;

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "dQQqTFZ1FSVZUSMx"

    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    :goto_1a8
    return-void
.end method
