# classes88.dex

.class Ld$24$4;
.super Ljava/lang/Object;
.source "FoxSource"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ld$24;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ld$24;

.field private final synthetic b:Landroid/widget/TextView;

.field private final synthetic c:Landroid/widget/Button;

.field private final synthetic d:Landroid/app/Activity;

.field private final synthetic e:Ljava/lang/String;

.field private final synthetic f:[I

.field private final synthetic g:Landroid/os/Handler;

.field private final synthetic h:Ljava/lang/Runnable;


# direct methods
.method constructor <init>(Ld$24;Landroid/widget/TextView;Landroid/widget/Button;Landroid/app/Activity;Ljava/lang/String;[ILandroid/os/Handler;Ljava/lang/Runnable;)V
    .registers 9

    .line 3926
    iput-object p1, p0, Ld$24$4;->a:Ld$24;

    iput-object p2, p0, Ld$24$4;->b:Landroid/widget/TextView;

    iput-object p3, p0, Ld$24$4;->c:Landroid/widget/Button;

    iput-object p4, p0, Ld$24$4;->d:Landroid/app/Activity;

    iput-object p5, p0, Ld$24$4;->e:Ljava/lang/String;

    iput-object p6, p0, Ld$24$4;->f:[I

    iput-object p7, p0, Ld$24$4;->g:Landroid/os/Handler;

    iput-object p8, p0, Ld$24$4;->h:Ljava/lang/Runnable;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 5

    .line 3929
    iget-object p1, p0, Ld$24$4;->b:Landroid/widget/TextView;

    const-string v0, "GiQjQ1E7M2ZZUDB0NUhUMDcySFx1NylAVSA6L1lBdTcuTFY7MSoDFns="

    invoke-static {v0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3930
    iget-object p1, p0, Ld$24$4;->c:Landroid/widget/Button;

    const-string v0, "BiAjXRhnbmZuUDQ6KEhUdRs2SFYwMA=="

    invoke-static {v0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 3931
    iget-object p1, p0, Ld$24$4;->d:Landroid/app/Activity;

    iget-object v0, p0, Ld$24$4;->e:Ljava/lang/String;

    invoke-static {p1, v0}, Ld;->a(Landroid/content/Context;Ljava/lang/String;)V

    .line 3933
    iget-object p1, p0, Ld$24$4;->f:[I

    const/4 v0, 0x0

    aput v0, p1, v0

    .line 3934
    iget-object p1, p0, Ld$24$4;->g:Landroid/os/Handler;

    iget-object v0, p0, Ld$24$4;->h:Ljava/lang/Runnable;

    invoke-virtual {p1, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 3935
    iget-object p1, p0, Ld$24$4;->g:Landroid/os/Handler;

    iget-object v0, p0, Ld$24$4;->h:Ljava/lang/Runnable;

    const-wide/16 v1, 0x3e8

    invoke-virtual {p1, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method
