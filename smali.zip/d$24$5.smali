# classes88.dex

.class Ld$24$5;
.super Ljava/lang/Object;
.source "FoxSource"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ld$24;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ld$24;

.field private final synthetic b:Landroid/widget/Button;

.field private final synthetic c:Landroid/content/SharedPreferences;

.field private final synthetic d:Landroid/app/Activity;

.field private final synthetic e:Ljava/lang/String;

.field private final synthetic f:[Z

.field private final synthetic g:Landroid/app/Dialog;

.field private final synthetic h:Ljava/lang/Runnable;

.field private final synthetic i:Landroid/widget/TextView;


# direct methods
.method constructor <init>(Ld$24;Landroid/widget/Button;Landroid/content/SharedPreferences;Landroid/app/Activity;Ljava/lang/String;[ZLandroid/app/Dialog;Ljava/lang/Runnable;Landroid/widget/TextView;)V
    .registers 10

    .line 3939
    iput-object p1, p0, Ld$24$5;->a:Ld$24;

    iput-object p2, p0, Ld$24$5;->b:Landroid/widget/Button;

    iput-object p3, p0, Ld$24$5;->c:Landroid/content/SharedPreferences;

    iput-object p4, p0, Ld$24$5;->d:Landroid/app/Activity;

    iput-object p5, p0, Ld$24$5;->e:Ljava/lang/String;

    iput-object p6, p0, Ld$24$5;->f:[Z

    iput-object p7, p0, Ld$24$5;->g:Landroid/app/Dialog;

    iput-object p8, p0, Ld$24$5;->h:Ljava/lang/Runnable;

    iput-object p9, p0, Ld$24$5;->i:Landroid/widget/TextView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 16

    .line 3942
    iget-object v0, p0, Ld$24$5;->b:Landroid/widget/Button;

    const-string v2, "FjwjTlM8OiENayE1MlhLe3po"

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 3943
    iget-object v0, p0, Ld$24$5;->b:Landroid/widget/Button;

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setEnabled(Z)V

    .line 3945
    iget-object v0, p0, Ld$24$5;->c:Landroid/content/SharedPreferences;

    invoke-static {}, Le;->D()Ljava/lang/String;

    move-result-object v2

    iget-object v3, p0, Ld$24$5;->c:Landroid/content/SharedPreferences;

    const-string v4, "ICcjX2cwOSdEVA=="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const-string v5, ""

    invoke-interface {v3, v4, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v0, v2, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 3946
    iget-object v0, p0, Ld$24$5;->c:Landroid/content/SharedPreferences;

    invoke-static {}, Le;->E()Ljava/lang/String;

    move-result-object v2

    iget-object v4, p0, Ld$24$5;->c:Landroid/content/SharedPreferences;

    const-string v6, "ICcjX2cgPSI="

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-interface {v4, v6, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-interface {v0, v2, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 3947
    iget-object v0, p0, Ld$24$5;->d:Landroid/app/Activity;

    invoke-static {v0}, Le;->c(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v5

    .line 3949
    new-instance v13, Ljava/lang/Thread;

    new-instance v0, Ld$24$5$1;

    iget-object v2, p0, Ld$24$5;->e:Ljava/lang/String;

    iget-object v6, p0, Ld$24$5;->d:Landroid/app/Activity;

    iget-object v7, p0, Ld$24$5;->b:Landroid/widget/Button;

    iget-object v8, p0, Ld$24$5;->f:[Z

    iget-object v9, p0, Ld$24$5;->c:Landroid/content/SharedPreferences;

    iget-object v10, p0, Ld$24$5;->g:Landroid/app/Dialog;

    iget-object v11, p0, Ld$24$5;->h:Ljava/lang/Runnable;

    iget-object v12, p0, Ld$24$5;->i:Landroid/widget/TextView;

    move-object v1, p0

    invoke-direct/range {v0 .. v12}, Ld$24$5$1;-><init>(Ld$24$5;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/app/Activity;Landroid/widget/Button;[ZLandroid/content/SharedPreferences;Landroid/app/Dialog;Ljava/lang/Runnable;Landroid/widget/TextView;)V

    invoke-direct {v13, v0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 4019
    invoke-virtual {v13}, Ljava/lang/Thread;->start()V

    return-void
.end method
