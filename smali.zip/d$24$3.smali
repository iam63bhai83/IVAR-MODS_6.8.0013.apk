# classes88.dex

.class Ld$24$3;
.super Ljava/lang/Object;
.source "FoxSource"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ld$24;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ld$24;

.field private final synthetic b:Landroid/widget/Button;

.field private final synthetic c:Landroid/app/Activity;

.field private final synthetic d:Ljava/lang/String;


# direct methods
.method constructor <init>(Ld$24;Landroid/widget/Button;Landroid/app/Activity;Ljava/lang/String;)V
    .registers 5

    .line 3918
    iput-object p1, p0, Ld$24$3;->a:Ld$24;

    iput-object p2, p0, Ld$24$3;->b:Landroid/widget/Button;

    iput-object p3, p0, Ld$24$3;->c:Landroid/app/Activity;

    iput-object p4, p0, Ld$24$3;->d:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 3

    .line 3921
    iget-object p1, p0, Ld$24$3;->b:Landroid/widget/Button;

    const-string v0, "BiAjXRhkbmZuUDQ6KEhUdRs2SFYwMA=="

    invoke-static {v0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 3922
    iget-object p1, p0, Ld$24$3;->c:Landroid/app/Activity;

    iget-object v0, p0, Ld$24$3;->d:Ljava/lang/String;

    invoke-static {p1, v0}, Ld;->a(Landroid/content/Context;Ljava/lang/String;)V

    return-void
.end method
