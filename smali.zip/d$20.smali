# classes88.dex

.class Ld$20;
.super Ljava/lang/Object;
.source "FoxSource"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ld;->b(Landroid/app/Activity;Landroid/app/Dialog;Ljava/lang/String;IIIILandroid/content/SharedPreferences;)Landroid/view/View;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private final synthetic a:[Z

.field private final synthetic b:Ljava/lang/Runnable;


# direct methods
.method constructor <init>([ZLjava/lang/Runnable;)V
    .registers 3

    .line 3570
    iput-object p1, p0, Ld$20;->a:[Z

    iput-object p2, p0, Ld$20;->b:Ljava/lang/Runnable;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 4

    .line 3573
    iget-object p1, p0, Ld$20;->a:[Z

    const/4 v0, 0x0

    const/4 v1, 0x1

    aput-boolean v1, p1, v0

    .line 3574
    iget-object p1, p0, Ld$20;->b:Ljava/lang/Runnable;

    invoke-interface {p1}, Ljava/lang/Runnable;->run()V

    return-void
.end method
