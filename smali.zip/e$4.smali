# classes88.dex

.class Le$4;
.super Ljava/lang/Object;
.source "FoxSource"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Le;->a(Landroid/content/Context;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private final synthetic a:Landroid/app/Activity;


# direct methods
.method constructor <init>(Landroid/app/Activity;)V
    .registers 2

    .line 1089
    iput-object p1, p0, Le$4;->a:Landroid/app/Activity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 5

    .line 1093
    :try_start_0
    new-instance v0, Landroid/app/AlertDialog$Builder;

    iget-object v1, p0, Le$4;->a:Landroid/app/Activity;

    invoke-direct {v0, v1}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 1094
    const-string v1, "EREQZHsQdBZoahgVCGh2ARgfDXoUGghofA=="

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 1095
    const-string v1, "BjElWEo8ID8Nbjw7KkxMPDsoFxgAOidYTD07NERCMDBmQFcxMCNJGBQEDQEYJj0hQ1khITRIGCYkKUJePDohARg6JmZZWTgkI19ROzNmSV0hMSVZXTF0KUMYITwvXhgxMTBEWzB6ZnRXICZmSV0jPSVIGD01NQ1aMDEoDUgwJitMVjA6MkFBdTYqTFs+OC9eTDAwZktKOjlma1ctdAdkFg=="

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    const/4 v1, 0x0

    .line 1096
    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setCancelable(Z)Landroid/app/AlertDialog$Builder;

    .line 1097
    const-string v1, "EAwPeQ=="

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    new-instance v2, Le$4$1;

    iget-object v3, p0, Le$4;->a:Landroid/app/Activity;

    invoke-direct {v2, p0, v3}, Le$4$1;-><init>(Le$4;Landroid/app/Activity;)V

    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 1103
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;
    :try_end_30
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_30} :catch_31

    return-void

    .line 1105
    :catch_31
    iget-object v0, p0, Le$4;->a:Landroid/app/Activity;

    invoke-static {v0}, Le;->f(Landroid/app/Activity;)V

    return-void
.end method
