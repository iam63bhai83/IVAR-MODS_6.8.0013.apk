# classes88.dex

.class Lb$3$1$1;
.super Ljava/lang/Object;
.source "FoxSource"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lb$3$1;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lb$3$1;

.field private final synthetic b:Landroid/app/Activity;

.field private final synthetic c:Landroid/widget/LinearLayout;


# direct methods
.method constructor <init>(Lb$3$1;Landroid/app/Activity;Landroid/widget/LinearLayout;)V
    .registers 4

    .line 136
    iput-object p1, p0, Lb$3$1$1;->a:Lb$3$1;

    iput-object p2, p0, Lb$3$1$1;->b:Landroid/app/Activity;

    iput-object p3, p0, Lb$3$1$1;->c:Landroid/widget/LinearLayout;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 3

    .line 139
    iget-object v0, p0, Lb$3$1$1;->b:Landroid/app/Activity;

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lb;->a(Landroid/app/Activity;Z)V

    .line 140
    iget-object v0, p0, Lb$3$1$1;->c:Landroid/widget/LinearLayout;

    const/high16 v1, 0x3f800000  # 1.0f

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setAlpha(F)V

    return-void
.end method
