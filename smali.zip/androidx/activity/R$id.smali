# classes88.dex

.class public final Landroidx/activity/R$id;
.super Ljava/lang/Object;
.source "FoxSource"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/activity/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "id"
.end annotation


# static fields
.field public static final ALT:I = 0x7f090000

.field public static final AutoTyperTextView:I = 0x7f090001

.field public static final BOTTOM_END:I = 0x7f090002

.field public static final BOTTOM_START:I = 0x7f090003

.field public static final BharatClubimage:I = 0x7f090004

.field public static final CTRL:I = 0x7f090005

.field public static final FUNCTION:I = 0x7f090006

.field public static final Hoursss:I = 0x7f090007

.field public static final META:I = 0x7f090008

.field public static final Minutess:I = 0x7f090009

.field public static final NO_DEBUG:I = 0x7f09000a

.field public static final Result:I = 0x7f09000b

.field public static final SHIFT:I = 0x7f09000c

.field public static final SHOW_ALL:I = 0x7f09000d

.field public static final SHOW_PATH:I = 0x7f09000e

.field public static final SHOW_PROGRESS:I = 0x7f09000f

.field public static final SYM:I = 0x7f090010

.field public static final TOP_END:I = 0x7f090011

.field public static final TOP_START:I = 0x7f090012

.field public static final a1:I = 0x7f090013

.field public static final a10:I = 0x7f090014

.field public static final a11:I = 0x7f090015

.field public static final a12:I = 0x7f090016

.field public static final a13:I = 0x7f090017

.field public static final a2:I = 0x7f090018

.field public static final a3:I = 0x7f090019

.field public static final a4:I = 0x7f09001a

.field public static final a5:I = 0x7f09001b

.field public static final a6:I = 0x7f09001c

.field public static final a7:I = 0x7f09001d

.field public static final a8:I = 0x7f09001e

.field public static final a9:I = 0x7f09001f

.field public static final above:I = 0x7f090020

.field public static final ac1:I = 0x7f090021

.field public static final ac2:I = 0x7f090022

.field public static final accelerate:I = 0x7f090023

.field public static final accessibility_action_clickable_span:I = 0x7f090024

.field public static final accessibility_custom_action_0:I = 0x7f090025

.field public static final accessibility_custom_action_1:I = 0x7f090026

.field public static final accessibility_custom_action_10:I = 0x7f090027

.field public static final accessibility_custom_action_11:I = 0x7f090028

.field public static final accessibility_custom_action_12:I = 0x7f090029

.field public static final accessibility_custom_action_13:I = 0x7f09002a

.field public static final accessibility_custom_action_14:I = 0x7f09002b

.field public static final accessibility_custom_action_15:I = 0x7f09002c

.field public static final accessibility_custom_action_16:I = 0x7f09002d

.field public static final accessibility_custom_action_17:I = 0x7f09002e

.field public static final accessibility_custom_action_18:I = 0x7f09002f

.field public static final accessibility_custom_action_19:I = 0x7f090030

.field public static final accessibility_custom_action_2:I = 0x7f090031

.field public static final accessibility_custom_action_20:I = 0x7f090032

.field public static final accessibility_custom_action_21:I = 0x7f090033

.field public static final accessibility_custom_action_22:I = 0x7f090034

.field public static final accessibility_custom_action_23:I = 0x7f090035

.field public static final accessibility_custom_action_24:I = 0x7f090036

.field public static final accessibility_custom_action_25:I = 0x7f090037

.field public static final accessibility_custom_action_26:I = 0x7f090038

.field public static final accessibility_custom_action_27:I = 0x7f090039

.field public static final accessibility_custom_action_28:I = 0x7f09003a

.field public static final accessibility_custom_action_29:I = 0x7f09003b

.field public static final accessibility_custom_action_3:I = 0x7f09003c

.field public static final accessibility_custom_action_30:I = 0x7f09003d

.field public static final accessibility_custom_action_31:I = 0x7f09003e

.field public static final accessibility_custom_action_4:I = 0x7f09003f

.field public static final accessibility_custom_action_5:I = 0x7f090040

.field public static final accessibility_custom_action_6:I = 0x7f090041

.field public static final accessibility_custom_action_7:I = 0x7f090042

.field public static final accessibility_custom_action_8:I = 0x7f090043

.field public static final accessibility_custom_action_9:I = 0x7f090044

.field public static final actionDown:I = 0x7f090045

.field public static final actionDownUp:I = 0x7f090046

.field public static final actionUp:I = 0x7f090047

.field public static final action_bar:I = 0x7f090048

.field public static final action_bar_activity_content:I = 0x7f090049

.field public static final action_bar_container:I = 0x7f09004a

.field public static final action_bar_root:I = 0x7f09004b

.field public static final action_bar_spinner:I = 0x7f09004c

.field public static final action_bar_subtitle:I = 0x7f09004d

.field public static final action_bar_title:I = 0x7f09004e

.field public static final action_container:I = 0x7f09004f

.field public static final action_context_bar:I = 0x7f090050

.field public static final action_divider:I = 0x7f090051

.field public static final action_image:I = 0x7f090052

.field public static final action_menu_divider:I = 0x7f090053

.field public static final action_menu_presenter:I = 0x7f090054

.field public static final action_mode_bar:I = 0x7f090055

.field public static final action_mode_bar_stub:I = 0x7f090056

.field public static final action_mode_close_button:I = 0x7f090057

.field public static final action_text:I = 0x7f090058

.field public static final actions:I = 0x7f090059

.field public static final activity_chooser_view_content:I = 0x7f09005a

.field public static final activitykey:I = 0x7f09005b

.field public static final add:I = 0x7f09005c

.field public static final adjust_height:I = 0x7f09005d

.field public static final adjust_width:I = 0x7f09005e

.field public static final advance:I = 0x7f09005f

.field public static final alertTitle:I = 0x7f090060

.field public static final aligned:I = 0x7f090061

.field public static final all:I = 0x7f090062

.field public static final allStates:I = 0x7f090063

.field public static final always:I = 0x7f090064

.field public static final animateToEnd:I = 0x7f090065

.field public static final animateToStart:I = 0x7f090066

.field public static final antiClockwise:I = 0x7f090067

.field public static final anticipate:I = 0x7f090068

.field public static final arc:I = 0x7f090069

.field public static final asConfigured:I = 0x7f09006a

.field public static final async:I = 0x7f09006b

.field public static final auto:I = 0x7f09006c

.field public static final autoComplete:I = 0x7f09006d

.field public static final autoCompleteToEnd:I = 0x7f09006e

.field public static final autoCompleteToStart:I = 0x7f09006f

.field public static final autoHide:I = 0x7f090070

.field public static final autoLimit:I = 0x7f090071

.field public static final availableSpace:I = 0x7f090072

.field public static final axisRelative:I = 0x7f090073

.field public static final b1:I = 0x7f090074

.field public static final b2:I = 0x7f090075

.field public static final background:I = 0x7f090076

.field public static final badge_best_value:I = 0x7f090077

.field public static final badge_check_r1_basic:I = 0x7f090078

.field public static final badge_check_r1_pro:I = 0x7f090079

.field public static final badge_check_r2_pro:I = 0x7f09007a

.field public static final badge_check_r3_pro:I = 0x7f09007b

.field public static final badge_check_r4_basic:I = 0x7f09007c

.field public static final badge_check_r4_pro:I = 0x7f09007d

.field public static final badge_check_r5_pro:I = 0x7f09007e

.field public static final badge_check_r6_basic:I = 0x7f09007f

.field public static final badge_check_r6_free:I = 0x7f090080

.field public static final badge_check_r6_pro:I = 0x7f090081

.field public static final badge_cross_r2_basic:I = 0x7f090082

.field public static final badge_cross_r2_free:I = 0x7f090083

.field public static final badge_cross_r3_basic:I = 0x7f090084

.field public static final badge_cross_r3_free:I = 0x7f090085

.field public static final badge_cross_r5_basic:I = 0x7f090086

.field public static final badge_cross_r5_free:I = 0x7f090087

.field public static final badge_info_pill:I = 0x7f090088

.field public static final badge_profile_plan_status:I = 0x7f090089

.field public static final banner_header_visual:I = 0x7f09008a

.field public static final barrier:I = 0x7f09008b

.field public static final baseline:I = 0x7f09008c

.field public static final bdggameimage:I = 0x7f09008d

.field public static final bdgwiniamge:I = 0x7f09008e

.field public static final beginOnFirstDraw:I = 0x7f09008f

.field public static final beginning:I = 0x7f090090

.field public static final below:I = 0x7f090091

.field public static final bestChoice:I = 0x7f090092

.field public static final bg:I = 0x7f090093

.field public static final bgg:I = 0x7f090094

.field public static final bigMumbaiimage:I = 0x7f090095

.field public static final blocking:I = 0x7f090096

.field public static final bottom:I = 0x7f090097

.field public static final bottom_nav1:I = 0x7f090098

.field public static final bottom_to_top:I = 0x7f090099

.field public static final bounce:I = 0x7f09009a

.field public static final bounceBoth:I = 0x7f09009b

.field public static final bounceEnd:I = 0x7f09009c

.field public static final bounceStart:I = 0x7f09009d

.field public static final bounty_img:I = 0x7f09009e

.field public static final btn_clear_chat:I = 0x7f09009f

.field public static final btn_clear_history:I = 0x7f0900a0

.field public static final btn_close_plans:I = 0x7f0900a1

.field public static final btn_continue_free:I = 0x7f0900a2

.field public static final btn_cta_action:I = 0x7f0900a3

.field public static final btn_free_plan:I = 0x7f0900a4

.field public static final btn_history_back_circle:I = 0x7f0900a5

.field public static final btn_profile_upgrade_plan:I = 0x7f0900a6

.field public static final btn_restore_container:I = 0x7f0900a7

.field public static final btn_restore_plans:I = 0x7f0900a8

.field public static final btn_send_chat:I = 0x7f0900a9

.field public static final btn_toggle_comparison:I = 0x7f0900aa

.field public static final btn_upgrade_basic:I = 0x7f0900ab

.field public static final btn_upgrade_pro:I = 0x7f0900ac

.field public static final btn_voice_chat:I = 0x7f0900ad

.field public static final buttonPanel:I = 0x7f0900ae

.field public static final button_continue:I = 0x7f0900af

.field public static final button_text:I = 0x7f0900b0

.field public static final c_accuracy:I = 0x7f0900b1

.field public static final c_bet:I = 0x7f0900b2

.field public static final c_loss:I = 0x7f0900b3

.field public static final c_win:I = 0x7f0900b4

.field public static final cache_measures:I = 0x7f0900b5

.field public static final callMeasure:I = 0x7f0900b6

.field public static final cancel:I = 0x7f0900b7

.field public static final cancel_button:I = 0x7f0900b8

.field public static final card_current_status:I = 0x7f0900b9

.field public static final card_plan_basic:I = 0x7f0900ba

.field public static final card_plan_free:I = 0x7f0900bb

.field public static final card_plan_pro:I = 0x7f0900bc

.field public static final card_profile_chat_tokens:I = 0x7f0900bd

.field public static final card_profile_plan:I = 0x7f0900be

.field public static final card_profile_pred_tokens:I = 0x7f0900bf

.field public static final cardview1:I = 0x7f0900c0

.field public static final carryVelocity:I = 0x7f0900c1

.field public static final center:I = 0x7f0900c2

.field public static final centerCrop:I = 0x7f0900c3

.field public static final centerInside:I = 0x7f0900c4

.field public static final center_horizontal:I = 0x7f0900c5

.field public static final center_vertical:I = 0x7f0900c6

.field public static final chain:I = 0x7f0900c7

.field public static final chain2:I = 0x7f0900c8

.field public static final chains:I = 0x7f0900c9

.field public static final chat_history_container:I = 0x7f0900ca

.field public static final chatbot:I = 0x7f0900cb

.field public static final chatbot_btn:I = 0x7f0900cc

.field public static final chatbot_linear1:I = 0x7f0900cd

.field public static final checkbox:I = 0x7f0900ce

.field public static final checkbox_conditions:I = 0x7f0900cf

.field public static final checked:I = 0x7f0900d0

.field public static final chip_starter_mode:I = 0x7f0900d1

.field public static final chip_starter_server:I = 0x7f0900d2

.field public static final chip_starter_timings:I = 0x7f0900d3

.field public static final chip_starter_trade:I = 0x7f0900d4

.field public static final chronometer:I = 0x7f0900d5

.field public static final circle_center:I = 0x7f0900d6

.field public static final clear_text:I = 0x7f0900d7

.field public static final clip_horizontal:I = 0x7f0900d8

.field public static final clip_vertical:I = 0x7f0900d9

.field public static final clockwise:I = 0x7f0900da

.field public static final close:I = 0x7f0900db

.field public static final closest:I = 0x7f0900dc

.field public static final club55image:I = 0x7f0900dd

.field public static final club6image:I = 0x7f0900de

.field public static final club91image:I = 0x7f0900df

.field public static final collapseActionView:I = 0x7f0900e0

.field public static final compress:I = 0x7f0900e1

.field public static final confirm_button:I = 0x7f0900e2

.field public static final constraint:I = 0x7f0900e3

.field public static final container:I = 0x7f0900e4

.field public static final container_duration_tabs:I = 0x7f0900e5

.field public static final container_feature_table:I = 0x7f0900e6

.field public static final container_hero_branding:I = 0x7f0900e7

.field public static final container_metrics_bento:I = 0x7f0900e8

.field public static final container_plan_info:I = 0x7f0900e9

.field public static final container_segmented_control:I = 0x7f0900ea

.field public static final container_side_by_side_pricing:I = 0x7f0900eb

.field public static final content:I = 0x7f0900ec

.field public static final contentPanel:I = 0x7f0900ed

.field public static final contiguous:I = 0x7f0900ee

.field public static final continuousVelocity:I = 0x7f0900ef

.field public static final coordinator:I = 0x7f0900f0

.field public static final cos:I = 0x7f0900f1

.field public static final counterclockwise:I = 0x7f0900f2

.field public static final cradle:I = 0x7f0900f3

.field public static final currentState:I = 0x7f0900f4

.field public static final custom:I = 0x7f0900f5

.field public static final customPanel:I = 0x7f0900f6

.field public static final cut:I = 0x7f0900f7

.field public static final damanimage:I = 0x7f0900f8

.field public static final dark:I = 0x7f0900f9

.field public static final date_picker_actions:I = 0x7f0900fa

.field public static final decelerate:I = 0x7f0900fb

.field public static final decelerateAndComplete:I = 0x7f0900fc

.field public static final decor_content_parent:I = 0x7f0900fd

.field public static final default_activity_button:I = 0x7f0900fe

.field public static final deltaRelative:I = 0x7f0900ff

.field public static final dependency_ordering:I = 0x7f090100

.field public static final design_bottom_sheet:I = 0x7f090101

.field public static final design_menu_item_action_area:I = 0x7f090102

.field public static final design_menu_item_action_area_stub:I = 0x7f090103

.field public static final design_menu_item_text:I = 0x7f090104

.field public static final design_navigation_view:I = 0x7f090105

.field public static final dialog_button:I = 0x7f090106

.field public static final dialog_plans_main_container:I = 0x7f090107

.field public static final dialog_plans_root:I = 0x7f090108

.field public static final dialog_plans_scroll:I = 0x7f090109

.field public static final dimensions:I = 0x7f09010a

.field public static final direct:I = 0x7f09010b

.field public static final disableHome:I = 0x7f09010c

.field public static final disableIntraAutoTransition:I = 0x7f09010d

.field public static final disablePostScroll:I = 0x7f09010e

.field public static final disableScroll:I = 0x7f09010f

.field public static final disjoint:I = 0x7f090110

.field public static final diuwinimage:I = 0x7f090111

.field public static final divider_metric_1:I = 0x7f090112

.field public static final divider_metric_2:I = 0x7f090113

.field public static final dot_chatbot:I = 0x7f090114

.field public static final dot_home:I = 0x7f090115

.field public static final dot_online_indicator:I = 0x7f090116

.field public static final dot_profile:I = 0x7f090117

.field public static final dot_status_indicator:I = 0x7f090118

.field public static final dot_web:I = 0x7f090119

.field public static final dragAnticlockwise:I = 0x7f09011a

.field public static final dragClockwise:I = 0x7f09011b

.field public static final dragDown:I = 0x7f09011c

.field public static final dragEnd:I = 0x7f09011d

.field public static final dragLeft:I = 0x7f09011e

.field public static final dragRight:I = 0x7f09011f

.field public static final dragStart:I = 0x7f090120

.field public static final dragUp:I = 0x7f090121

.field public static final dream99image:I = 0x7f090122

.field public static final dropdown_menu:I = 0x7f090123

.field public static final easeIn:I = 0x7f090124

.field public static final easeInOut:I = 0x7f090125

.field public static final easeOut:I = 0x7f090126

.field public static final east:I = 0x7f090127

.field public static final edge:I = 0x7f090128

.field public static final edit_query:I = 0x7f090129

.field public static final edit_text_id:I = 0x7f09012a

.field public static final edittext_chat_input:I = 0x7f09012b

.field public static final elastic:I = 0x7f09012c

.field public static final embed:I = 0x7f09012d

.field public static final end:I = 0x7f09012e

.field public static final endToStart:I = 0x7f09012f

.field public static final enterAlways:I = 0x7f090130

.field public static final enterAlwaysCollapsed:I = 0x7f090131

.field public static final entireSpace:I = 0x7f090132

.field public static final escape:I = 0x7f090133

.field public static final exitUntilCollapsed:I = 0x7f090134

.field public static final expand_activities_button:I = 0x7f090135

.field public static final expanded_menu:I = 0x7f090136

.field public static final fade:I = 0x7f090137

.field public static final fill:I = 0x7f090138

.field public static final fill_horizontal:I = 0x7f090139

.field public static final fill_vertical:I = 0x7f09013a

.field public static final filled:I = 0x7f09013b

.field public static final fitCenter:I = 0x7f09013c

.field public static final fitEnd:I = 0x7f09013d

.field public static final fitStart:I = 0x7f09013e

.field public static final fitToContents:I = 0x7f09013f

.field public static final fitXY:I = 0x7f090140

.field public static final fixed:I = 0x7f090141

.field public static final flip:I = 0x7f090142

.field public static final floating:I = 0x7f090143

.field public static final forever:I = 0x7f090144

.field public static final fragment_container_view_tag:I = 0x7f090145

.field public static final frost:I = 0x7f090146

.field public static final fullscreen_header:I = 0x7f090147

.field public static final game51image:I = 0x7f090148

.field public static final ghost_view:I = 0x7f090149

.field public static final ghost_view_holder:I = 0x7f09014a

.field public static final glide_custom_view_target_tag:I = 0x7f09014b

.field public static final goagameimage:I = 0x7f09014c

.field public static final gone:I = 0x7f09014d

.field public static final graph:I = 0x7f09014e

.field public static final graph_wrap:I = 0x7f09014f

.field public static final group_divider:I = 0x7f090150

.field public static final grouping:I = 0x7f090151

.field public static final groups:I = 0x7f090152

.field public static final header_title:I = 0x7f090153

.field public static final hidden:I = 0x7f090154

.field public static final hide_ime_id:I = 0x7f090155

.field public static final hideable:I = 0x7f090156

.field public static final home:I = 0x7f090157

.field public static final homeAsUp:I = 0x7f090158

.field public static final home_btn:I = 0x7f090159

.field public static final home_linear:I = 0x7f09015a

.field public static final home_linear1:I = 0x7f09015b

.field public static final honorRequest:I = 0x7f09015c

.field public static final horizontal:I = 0x7f09015d

.field public static final horizontal_only:I = 0x7f09015e

.field public static final hscroll3:I = 0x7f09015f

.field public static final hscroll_history_filters:I = 0x7f090160

.field public static final icon:I = 0x7f090161

.field public static final icon_group:I = 0x7f090162

.field public static final icon_only:I = 0x7f090163

.field public static final ifRoom:I = 0x7f090164

.field public static final ignore:I = 0x7f090165

.field public static final ignoreRequest:I = 0x7f090166

.field public static final image:I = 0x7f090167

.field public static final imageic:I = 0x7f090168

.field public static final imageview1:I = 0x7f090169

.field public static final imageview118:I = 0x7f09016a

.field public static final imageview119:I = 0x7f09016b

.field public static final imageview132:I = 0x7f09016c

.field public static final imageview15:I = 0x7f09016d

.field public static final imageview152:I = 0x7f09016e

.field public static final imageview153:I = 0x7f09016f

.field public static final imageview157:I = 0x7f090170

.field public static final imageview158:I = 0x7f090171

.field public static final imageview159:I = 0x7f090172

.field public static final imageview160:I = 0x7f090173

.field public static final imageview161:I = 0x7f090174

.field public static final imageview2:I = 0x7f090175

.field public static final imageview21:I = 0x7f090176

.field public static final imageview35:I = 0x7f090177

.field public static final imageview36:I = 0x7f090178

.field public static final imageview37:I = 0x7f090179

.field public static final imageview38:I = 0x7f09017a

.field public static final imageview4:I = 0x7f09017b

.field public static final imageview5:I = 0x7f09017c

.field public static final imageview59:I = 0x7f09017d

.field public static final imageview61:I = 0x7f09017e

.field public static final imageview62:I = 0x7f09017f

.field public static final imageview64:I = 0x7f090180

.field public static final imageview65:I = 0x7f090181

.field public static final imageview66:I = 0x7f090182

.field public static final imageview67:I = 0x7f090183

.field public static final imageview68:I = 0x7f090184

.field public static final imageview69:I = 0x7f090185

.field public static final imageview72:I = 0x7f090186

.field public static final imageview74:I = 0x7f090187

.field public static final imageview75:I = 0x7f090188

.field public static final imageview_d1:I = 0x7f090189

.field public static final imageview_d2:I = 0x7f09018a

.field public static final imageview_d3:I = 0x7f09018b

.field public static final imageview_d4:I = 0x7f09018c

.field public static final imageview_d5:I = 0x7f09018d

.field public static final imageview_error:I = 0x7f09018e

.field public static final imageview_logo:I = 0x7f09018f

.field public static final imageview_num1:I = 0x7f090190

.field public static final imageview_num2:I = 0x7f090191

.field public static final imageview_num3:I = 0x7f090192

.field public static final imageview_num4:I = 0x7f090193

.field public static final imageview_num5:I = 0x7f090194

.field public static final imageview_suggestion_button:I = 0x7f090195

.field public static final imageview_telegram:I = 0x7f090196

.field public static final img_chat_avatar:I = 0x7f090197

.field public static final img_welcome_avatar:I = 0x7f090198

.field public static final immediateStop:I = 0x7f090199

.field public static final in999image:I = 0x7f09019a

.field public static final included:I = 0x7f09019b

.field public static final indeterminate:I = 0x7f09019c

.field public static final indicator_grab_bar:I = 0x7f09019d

.field public static final info:I = 0x7f09019e

.field public static final injector:I = 0x7f09019f

.field public static final injector2:I = 0x7f0901a0

.field public static final invisible:I = 0x7f0901a1

.field public static final inward:I = 0x7f0901a2

.field public static final is_pooling_container_tag:I = 0x7f0901a3

.field public static final italic:I = 0x7f0901a4

.field public static final item_touch_helper_previous_elevation:I = 0x7f0901a5

.field public static final iv_comp_icon_1:I = 0x7f0901a6

.field public static final iv_comp_icon_2:I = 0x7f0901a7

.field public static final iv_comp_icon_3:I = 0x7f0901a8

.field public static final iv_comp_icon_4:I = 0x7f0901a9

.field public static final iv_comp_icon_5:I = 0x7f0901aa

.field public static final iv_comp_icon_6:I = 0x7f0901ab

.field public static final iv_hero_image:I = 0x7f0901ac

.field public static final iv_perk_icon_1:I = 0x7f0901ad

.field public static final iv_perk_icon_2:I = 0x7f0901ae

.field public static final iv_perk_icon_3:I = 0x7f0901af

.field public static final iv_perk_icon_4:I = 0x7f0901b0

.field public static final iv_perk_icon_5:I = 0x7f0901b1

.field public static final iv_profile_badge_icon:I = 0x7f0901b2

.field public static final iv_profile_chat_icon:I = 0x7f0901b3

.field public static final iv_profile_details_icon:I = 0x7f0901b4

.field public static final iv_profile_expiry_icon:I = 0x7f0901b5

.field public static final iv_profile_pred_icon:I = 0x7f0901b6

.field public static final iv_profile_upgrade_icon:I = 0x7f0901b7

.field public static final iv_tier_avatar:I = 0x7f0901b8

.field public static final iv_toggle_comparison_arrow:I = 0x7f0901b9

.field public static final iv_verified_badge:I = 0x7f0901ba

.field public static final ivarmods:I = 0x7f0901bb

.field public static final jai_img:I = 0x7f0901bc

.field public static final jalwa_img:I = 0x7f0901bd

.field public static final jumpToEnd:I = 0x7f0901be

.field public static final jumpToStart:I = 0x7f0901bf

.field public static final key:I = 0x7f0901c0

.field public static final labeled:I = 0x7f0901c1

.field public static final layout:I = 0x7f0901c2

.field public static final layout_avatar_badge:I = 0x7f0901c3

.field public static final layout_avatar_container:I = 0x7f0901c4

.field public static final layout_chat_icon_box:I = 0x7f0901c5

.field public static final layout_details_icon_box:I = 0x7f0901c6

.field public static final layout_online_status:I = 0x7f0901c7

.field public static final layout_pred_icon_box:I = 0x7f0901c8

.field public static final layout_pricing_toggle:I = 0x7f0901c9

.field public static final layout_pro_tilted_card:I = 0x7f0901ca

.field public static final layout_profile_identity:I = 0x7f0901cb

.field public static final layout_profile_info:I = 0x7f0901cc

.field public static final layout_profile_plan_header:I = 0x7f0901cd

.field public static final layout_progress:I = 0x7f0901ce

.field public static final left:I = 0x7f0901cf

.field public static final leftToRight:I = 0x7f0901d0

.field public static final left_to_right:I = 0x7f0901d1

.field public static final legacy:I = 0x7f0901d2

.field public static final legacy_games_stub_container:I = 0x7f0901d3

.field public static final light:I = 0x7f0901d4

.field public static final line:I = 0x7f0901d5

.field public static final line1:I = 0x7f0901d6

.field public static final line3:I = 0x7f0901d7

.field public static final linear:I = 0x7f0901d8

.field public static final linear1:I = 0x7f0901d9

.field public static final linear11:I = 0x7f0901da

.field public static final linear12:I = 0x7f0901db

.field public static final linear13:I = 0x7f0901dc

.field public static final linear14:I = 0x7f0901dd

.field public static final linear15:I = 0x7f0901de

.field public static final linear154:I = 0x7f0901df

.field public static final linear157:I = 0x7f0901e0

.field public static final linear159:I = 0x7f0901e1

.field public static final linear16:I = 0x7f0901e2

.field public static final linear160:I = 0x7f0901e3

.field public static final linear161:I = 0x7f0901e4

.field public static final linear162:I = 0x7f0901e5

.field public static final linear167:I = 0x7f0901e6

.field public static final linear168:I = 0x7f0901e7

.field public static final linear169:I = 0x7f0901e8

.field public static final linear17:I = 0x7f0901e9

.field public static final linear171:I = 0x7f0901ea

.field public static final linear173:I = 0x7f0901eb

.field public static final linear174:I = 0x7f0901ec

.field public static final linear175:I = 0x7f0901ed

.field public static final linear176:I = 0x7f0901ee

.field public static final linear177:I = 0x7f0901ef

.field public static final linear178:I = 0x7f0901f0

.field public static final linear179:I = 0x7f0901f1

.field public static final linear180:I = 0x7f0901f2

.field public static final linear181:I = 0x7f0901f3

.field public static final linear185:I = 0x7f0901f4

.field public static final linear197:I = 0x7f0901f5

.field public static final linear198:I = 0x7f0901f6

.field public static final linear199:I = 0x7f0901f7

.field public static final linear2:I = 0x7f0901f8

.field public static final linear200:I = 0x7f0901f9

.field public static final linear201:I = 0x7f0901fa

.field public static final linear202:I = 0x7f0901fb

.field public static final linear203:I = 0x7f0901fc

.field public static final linear204:I = 0x7f0901fd

.field public static final linear205:I = 0x7f0901fe

.field public static final linear206:I = 0x7f0901ff

.field public static final linear207:I = 0x7f090200

.field public static final linear208:I = 0x7f090201

.field public static final linear209:I = 0x7f090202

.field public static final linear21:I = 0x7f090203

.field public static final linear210:I = 0x7f090204

.field public static final linear211:I = 0x7f090205

.field public static final linear212:I = 0x7f090206

.field public static final linear213:I = 0x7f090207

.field public static final linear214:I = 0x7f090208

.field public static final linear215:I = 0x7f090209

.field public static final linear216:I = 0x7f09020a

.field public static final linear22:I = 0x7f09020b

.field public static final linear228:I = 0x7f09020c

.field public static final linear229:I = 0x7f09020d

.field public static final linear23:I = 0x7f09020e

.field public static final linear230:I = 0x7f09020f

.field public static final linear236:I = 0x7f090210

.field public static final linear24:I = 0x7f090211

.field public static final linear244:I = 0x7f090212

.field public static final linear245:I = 0x7f090213

.field public static final linear246:I = 0x7f090214

.field public static final linear247:I = 0x7f090215

.field public static final linear25:I = 0x7f090216

.field public static final linear253:I = 0x7f090217

.field public static final linear254:I = 0x7f090218

.field public static final linear255:I = 0x7f090219

.field public static final linear256:I = 0x7f09021a

.field public static final linear257:I = 0x7f09021b

.field public static final linear258:I = 0x7f09021c

.field public static final linear259:I = 0x7f09021d

.field public static final linear288:I = 0x7f09021e

.field public static final linear289:I = 0x7f09021f

.field public static final linear290:I = 0x7f090220

.field public static final linear298:I = 0x7f090221

.field public static final linear299:I = 0x7f090222

.field public static final linear3:I = 0x7f090223

.field public static final linear301:I = 0x7f090224

.field public static final linear310:I = 0x7f090225

.field public static final linear313:I = 0x7f090226

.field public static final linear314:I = 0x7f090227

.field public static final linear315:I = 0x7f090228

.field public static final linear32:I = 0x7f090229

.field public static final linear334:I = 0x7f09022a

.field public static final linear340:I = 0x7f09022b

.field public static final linear341:I = 0x7f09022c

.field public static final linear342:I = 0x7f09022d

.field public static final linear343:I = 0x7f09022e

.field public static final linear344:I = 0x7f09022f

.field public static final linear345:I = 0x7f090230

.field public static final linear348:I = 0x7f090231

.field public static final linear349:I = 0x7f090232

.field public static final linear35:I = 0x7f090233

.field public static final linear352:I = 0x7f090234

.field public static final linear354:I = 0x7f090235

.field public static final linear355:I = 0x7f090236

.field public static final linear356:I = 0x7f090237

.field public static final linear357:I = 0x7f090238

.field public static final linear358:I = 0x7f090239

.field public static final linear359:I = 0x7f09023a

.field public static final linear360:I = 0x7f09023b

.field public static final linear361:I = 0x7f09023c

.field public static final linear362:I = 0x7f09023d

.field public static final linear363:I = 0x7f09023e

.field public static final linear364:I = 0x7f09023f

.field public static final linear385:I = 0x7f090240

.field public static final linear389:I = 0x7f090241

.field public static final linear390:I = 0x7f090242

.field public static final linear391:I = 0x7f090243

.field public static final linear392:I = 0x7f090244

.field public static final linear394:I = 0x7f090245

.field public static final linear397:I = 0x7f090246

.field public static final linear398:I = 0x7f090247

.field public static final linear399:I = 0x7f090248

.field public static final linear4:I = 0x7f090249

.field public static final linear40:I = 0x7f09024a

.field public static final linear400:I = 0x7f09024b

.field public static final linear401:I = 0x7f09024c

.field public static final linear402:I = 0x7f09024d

.field public static final linear403:I = 0x7f09024e

.field public static final linear404:I = 0x7f09024f

.field public static final linear43:I = 0x7f090250

.field public static final linear44:I = 0x7f090251

.field public static final linear46:I = 0x7f090252

.field public static final linear49:I = 0x7f090253

.field public static final linear5:I = 0x7f090254

.field public static final linear50:I = 0x7f090255

.field public static final linear51:I = 0x7f090256

.field public static final linear52:I = 0x7f090257

.field public static final linear53:I = 0x7f090258

.field public static final linear54:I = 0x7f090259

.field public static final linear55:I = 0x7f09025a

.field public static final linear56:I = 0x7f09025b

.field public static final linear6:I = 0x7f09025c

.field public static final linear61:I = 0x7f09025d

.field public static final linear62:I = 0x7f09025e

.field public static final linear63:I = 0x7f09025f

.field public static final linear64:I = 0x7f090260

.field public static final linear7:I = 0x7f090261

.field public static final linear77:I = 0x7f090262

.field public static final linear78:I = 0x7f090263

.field public static final linear79:I = 0x7f090264

.field public static final linear8:I = 0x7f090265

.field public static final linear80:I = 0x7f090266

.field public static final linear81:I = 0x7f090267

.field public static final linear83:I = 0x7f090268

.field public static final linear85:I = 0x7f090269

.field public static final linear87:I = 0x7f09026a

.field public static final linear89:I = 0x7f09026b

.field public static final linear9:I = 0x7f09026c

.field public static final linear91:I = 0x7f09026d

.field public static final linear94:I = 0x7f09026e

.field public static final linear_1min:I = 0x7f09026f

.field public static final linear_30fs1:I = 0x7f090270

.field public static final linear_30fs2:I = 0x7f090271

.field public static final linear_30fs3:I = 0x7f090272

.field public static final linear_30sec:I = 0x7f090273

.field public static final linear_accuracy:I = 0x7f090274

.field public static final linear_accuracy_con:I = 0x7f090275

.field public static final linear_best_s_info:I = 0x7f090276

.field public static final linear_bet:I = 0x7f090277

.field public static final linear_bets_con:I = 0x7f090278

.field public static final linear_channel:I = 0x7f090279

.field public static final linear_chat_avatar_box:I = 0x7f09027a

.field public static final linear_chat_btn_wrap:I = 0x7f09027b

.field public static final linear_chat_header:I = 0x7f09027c

.field public static final linear_chat_input_dock:I = 0x7f09027d

.field public static final linear_chat_scroll_content:I = 0x7f09027e

.field public static final linear_chat_typing_indicator:I = 0x7f09027f

.field public static final linear_chat_welcome:I = 0x7f090280

.field public static final linear_d:I = 0x7f090281

.field public static final linear_d1:I = 0x7f090282

.field public static final linear_d2:I = 0x7f090283

.field public static final linear_d3:I = 0x7f090284

.field public static final linear_d4:I = 0x7f090285

.field public static final linear_d5:I = 0x7f090286

.field public static final linear_dL1:I = 0x7f090287

.field public static final linear_dL2:I = 0x7f090288

.field public static final linear_details_text_col:I = 0x7f090289

.field public static final linear_device_id:I = 0x7f09028a

.field public static final linear_disclaimer:I = 0x7f09028b

.field public static final linear_duration_heading:I = 0x7f09028c

.field public static final linear_error_container:I = 0x7f09028d

.field public static final linear_fs1:I = 0x7f09028e

.field public static final linear_fs2:I = 0x7f09028f

.field public static final linear_fs3:I = 0x7f090290

.field public static final linear_handle_container:I = 0x7f090291

.field public static final linear_history_empty_state:I = 0x7f090292

.field public static final linear_history_items_container:I = 0x7f090293

.field public static final linear_history_pills_bar:I = 0x7f090294

.field public static final linear_history_top_bar:I = 0x7f090295

.field public static final linear_hours:I = 0x7f090296

.field public static final linear_id:I = 0x7f090297

.field public static final linear_info:I = 0x7f090298

.field public static final linear_input_capsule:I = 0x7f090299

.field public static final linear_locked:I = 0x7f09029a

.field public static final linear_loss:I = 0x7f09029b

.field public static final linear_loss_con:I = 0x7f09029c

.field public static final linear_main_locked:I = 0x7f09029d

.field public static final linear_main_profox_1min:I = 0x7f09029e

.field public static final linear_main_profox_30sec:I = 0x7f09029f

.field public static final linear_matrix_header:I = 0x7f0902a0

.field public static final linear_min:I = 0x7f0902a1

.field public static final linear_n:I = 0x7f0902a2

.field public static final linear_n2:I = 0x7f0902a3

.field public static final linear_nav_pill:I = 0x7f0902a4

.field public static final linear_p:I = 0x7f0902a5

.field public static final linear_p2:I = 0x7f0902a6

.field public static final linear_pill_special_offer:I = 0x7f0902a7

.field public static final linear_pp:I = 0x7f0902a8

.field public static final linear_prediction_history_card:I = 0x7f0902a9

.field public static final linear_profile_details:I = 0x7f0902aa

.field public static final linear_profile_plan_details_row:I = 0x7f0902ab

.field public static final linear_profox_1min:I = 0x7f0902ac

.field public static final linear_profox_30sec:I = 0x7f0902ad

.field public static final linear_result:I = 0x7f0902ae

.field public static final linear_sec:I = 0x7f0902af

.field public static final linear_start_checking:I = 0x7f0902b0

.field public static final linear_stats:I = 0x7f0902b1

.field public static final linear_statss:I = 0x7f0902b2

.field public static final linear_subs:I = 0x7f0902b3

.field public static final linear_suggestion:I = 0x7f0902b4

.field public static final linear_support:I = 0x7f0902b5

.field public static final linear_tc:I = 0x7f0902b6

.field public static final linear_terms_etc_container:I = 0x7f0902b7

.field public static final linear_trust_badges:I = 0x7f0902b8

.field public static final linear_try_again_btn:I = 0x7f0902b9

.field public static final linear_update:I = 0x7f0902ba

.field public static final linear_update_container:I = 0x7f0902bb

.field public static final linear_welcome_avatar_box:I = 0x7f0902bc

.field public static final linear_welcome_pills:I = 0x7f0902bd

.field public static final linear_win:I = 0x7f0902be

.field public static final linear_win_con:I = 0x7f0902bf

.field public static final linearbg:I = 0x7f0902c0

.field public static final linearclose:I = 0x7f0902c1

.field public static final linearhead:I = 0x7f0902c2

.field public static final linearok:I = 0x7f0902c3

.field public static final linearxyz:I = 0x7f0902c4

.field public static final listMode:I = 0x7f0902c5

.field public static final list_item:I = 0x7f0902c6

.field public static final lo1:I = 0x7f0902c7

.field public static final lo2:I = 0x7f0902c8

.field public static final lottery82image:I = 0x7f0902c9

.field public static final m3_side_sheet:I = 0x7f0902ca

.field public static final main_linear:I = 0x7f0902cb

.field public static final marquee:I = 0x7f0902cc

.field public static final masked:I = 0x7f0902cd

.field public static final match_constraint:I = 0x7f0902ce

.field public static final match_parent:I = 0x7f0902cf

.field public static final material_clock_display:I = 0x7f0902d0

.field public static final material_clock_display_and_toggle:I = 0x7f0902d1

.field public static final material_clock_face:I = 0x7f0902d2

.field public static final material_clock_hand:I = 0x7f0902d3

.field public static final material_clock_level:I = 0x7f0902d4

.field public static final material_clock_period_am_button:I = 0x7f0902d5

.field public static final material_clock_period_pm_button:I = 0x7f0902d6

.field public static final material_clock_period_toggle:I = 0x7f0902d7

.field public static final material_hour_text_input:I = 0x7f0902d8

.field public static final material_hour_tv:I = 0x7f0902d9

.field public static final material_label:I = 0x7f0902da

.field public static final material_minute_text_input:I = 0x7f0902db

.field public static final material_minute_tv:I = 0x7f0902dc

.field public static final material_textinput_timepicker:I = 0x7f0902dd

.field public static final material_timepicker_cancel_button:I = 0x7f0902de

.field public static final material_timepicker_container:I = 0x7f0902df

.field public static final material_timepicker_mode_button:I = 0x7f0902e0

.field public static final material_timepicker_ok_button:I = 0x7f0902e1

.field public static final material_timepicker_view:I = 0x7f0902e2

.field public static final material_value_index:I = 0x7f0902e3

.field public static final matrix:I = 0x7f0902e4

.field public static final matrix_row_1:I = 0x7f0902e5

.field public static final matrix_row_2:I = 0x7f0902e6

.field public static final matrix_row_3:I = 0x7f0902e7

.field public static final matrix_row_4:I = 0x7f0902e8

.field public static final matrix_row_5:I = 0x7f0902e9

.field public static final matrix_row_6:I = 0x7f0902ea

.field public static final menu:I = 0x7f0902eb

.field public static final message:I = 0x7f0902ec

.field public static final middle:I = 0x7f0902ed

.field public static final min1text:I = 0x7f0902ee

.field public static final mini:I = 0x7f0902ef

.field public static final minnn3text:I = 0x7f0902f0

.field public static final ml1:I = 0x7f0902f1

.field public static final mmsg:I = 0x7f0902f2

.field public static final month_grid:I = 0x7f0902f3

.field public static final month_navigation_bar:I = 0x7f0902f4

.field public static final month_navigation_fragment_toggle:I = 0x7f0902f5

.field public static final month_navigation_next:I = 0x7f0902f6

.field public static final month_navigation_previous:I = 0x7f0902f7

.field public static final month_title:I = 0x7f0902f8

.field public static final motion_base:I = 0x7f0902f9

.field public static final mtitle:I = 0x7f0902fa

.field public static final mtrl_anchor_parent:I = 0x7f0902fb

.field public static final mtrl_calendar_day_selector_frame:I = 0x7f0902fc

.field public static final mtrl_calendar_days_of_week:I = 0x7f0902fd

.field public static final mtrl_calendar_frame:I = 0x7f0902fe

.field public static final mtrl_calendar_main_pane:I = 0x7f0902ff

.field public static final mtrl_calendar_months:I = 0x7f090300

.field public static final mtrl_calendar_selection_frame:I = 0x7f090301

.field public static final mtrl_calendar_text_input_frame:I = 0x7f090302

.field public static final mtrl_calendar_year_selector_frame:I = 0x7f090303

.field public static final mtrl_card_checked_layer_id:I = 0x7f090304

.field public static final mtrl_child_content_container:I = 0x7f090305

.field public static final mtrl_internal_children_alpha_tag:I = 0x7f090306

.field public static final mtrl_motion_snapshot_view:I = 0x7f090307

.field public static final mtrl_picker_fullscreen:I = 0x7f090308

.field public static final mtrl_picker_header:I = 0x7f090309

.field public static final mtrl_picker_header_selection_text:I = 0x7f09030a

.field public static final mtrl_picker_header_title_and_selection:I = 0x7f09030b

.field public static final mtrl_picker_header_toggle:I = 0x7f09030c

.field public static final mtrl_picker_text_input_date:I = 0x7f09030d

.field public static final mtrl_picker_text_input_range_end:I = 0x7f09030e

.field public static final mtrl_picker_text_input_range_start:I = 0x7f09030f

.field public static final mtrl_picker_title_text:I = 0x7f090310

.field public static final mtrl_view_tag_bottom_padding:I = 0x7f090311

.field public static final multiply:I = 0x7f090312

.field public static final name_ivm:I = 0x7f090313

.field public static final namee:I = 0x7f090314

.field public static final navigation_bar_item_active_indicator_view:I = 0x7f090315

.field public static final navigation_bar_item_content_container:I = 0x7f090316

.field public static final navigation_bar_item_icon_container:I = 0x7f090317

.field public static final navigation_bar_item_icon_view:I = 0x7f090318

.field public static final navigation_bar_item_inner_content_container:I = 0x7f090319

.field public static final navigation_bar_item_labels_group:I = 0x7f09031a

.field public static final navigation_bar_item_large_label_view:I = 0x7f09031b

.field public static final navigation_bar_item_small_label_view:I = 0x7f09031c

.field public static final navigation_header_container:I = 0x7f09031d

.field public static final navigation_menu_subheader_label:I = 0x7f09031e

.field public static final never:I = 0x7f09031f

.field public static final neverCompleteToEnd:I = 0x7f090320

.field public static final neverCompleteToStart:I = 0x7f090321

.field public static final nngameimage:I = 0x7f090322

.field public static final noScroll:I = 0x7f090323

.field public static final noState:I = 0x7f090324

.field public static final none:I = 0x7f090325

.field public static final normal:I = 0x7f090326

.field public static final north:I = 0x7f090327

.field public static final notification_background:I = 0x7f090328

.field public static final notification_main_column:I = 0x7f090329

.field public static final notification_main_column_container:I = 0x7f09032a

.field public static final off:I = 0x7f09032b

.field public static final ok:I = 0x7f09032c

.field public static final okwinimage:I = 0x7f09032d

.field public static final on:I = 0x7f09032e

.field public static final onInterceptTouchReturnSwipe:I = 0x7f09032f

.field public static final open:I = 0x7f090330

.field public static final open2:I = 0x7f090331

.field public static final open_search_bar_placeholder_text_view:I = 0x7f090332

.field public static final open_search_bar_text_view:I = 0x7f090333

.field public static final open_search_bar_text_view_container:I = 0x7f090334

.field public static final open_search_view_background:I = 0x7f090335

.field public static final open_search_view_clear_button:I = 0x7f090336

.field public static final open_search_view_content_container:I = 0x7f090337

.field public static final open_search_view_divider:I = 0x7f090338

.field public static final open_search_view_dummy_toolbar:I = 0x7f090339

.field public static final open_search_view_edit_text:I = 0x7f09033a

.field public static final open_search_view_header_container:I = 0x7f09033b

.field public static final open_search_view_root:I = 0x7f09033c

.field public static final open_search_view_scrim:I = 0x7f09033d

.field public static final open_search_view_search_prefix:I = 0x7f09033e

.field public static final open_search_view_status_bar_spacer:I = 0x7f09033f

.field public static final open_search_view_text_container:I = 0x7f090340

.field public static final open_search_view_toolbar:I = 0x7f090341

.field public static final open_search_view_toolbar_container:I = 0x7f090342

.field public static final outline:I = 0x7f090343

.field public static final outward:I = 0x7f090344

.field public static final overshoot:I = 0x7f090345

.field public static final packed:I = 0x7f090346

.field public static final pageccontrol_1_1:I = 0x7f090347

.field public static final parallax:I = 0x7f090348

.field public static final parent:I = 0x7f090349

.field public static final parentPanel:I = 0x7f09034a

.field public static final parentRelative:I = 0x7f09034b

.field public static final parent_matrix:I = 0x7f09034c

.field public static final password_toggle:I = 0x7f09034d

.field public static final path:I = 0x7f09034e

.field public static final pathRelative:I = 0x7f09034f

.field public static final peekHeight:I = 0x7f090350

.field public static final percent:I = 0x7f090351

.field public static final period30s:I = 0x7f090352

.field public static final pill_history_1min:I = 0x7f090353

.field public static final pill_history_30sec:I = 0x7f090354

.field public static final pill_history_all:I = 0x7f090355

.field public static final pill_history_high_acc:I = 0x7f090356

.field public static final pill_tab_basic:I = 0x7f090357

.field public static final pill_tab_pro:I = 0x7f090358

.field public static final pin:I = 0x7f090359

.field public static final platform_linear1:I = 0x7f09035a

.field public static final pooling_container_listener_holder_tag:I = 0x7f09035b

.field public static final position:I = 0x7f09035c

.field public static final postLayout:I = 0x7f09035d

.field public static final pp:I = 0x7f09035e

.field public static final prediction_txt_1:I = 0x7f09035f

.field public static final pressed:I = 0x7f090360

.field public static final prime:I = 0x7f090361

.field public static final profile:I = 0x7f090362

.field public static final profile_btn:I = 0x7f090363

.field public static final profile_linear1:I = 0x7f090364

.field public static final progress_circular:I = 0x7f090365

.field public static final progress_horizontal:I = 0x7f090366

.field public static final progressbar1:I = 0x7f090367

.field public static final px3:I = 0x7f090368

.field public static final radial:I = 0x7f090369

.field public static final radio:I = 0x7f09036a

.field public static final radio_monthly:I = 0x7f09036b

.field public static final radio_weekly:I = 0x7f09036c

.field public static final rajagame_img:I = 0x7f09036d

.field public static final ratio:I = 0x7f09036e

.field public static final rectangles:I = 0x7f09036f

.field public static final relativelayout4:I = 0x7f090370

.field public static final relativelayout6:I = 0x7f090371

.field public static final relativelayout_monthly:I = 0x7f090372

.field public static final relativelayout_top_bar:I = 0x7f090373

.field public static final report_drawn:I = 0x7f090374

.field public static final restart:I = 0x7f090375

.field public static final retreat:I = 0x7f090376

.field public static final retry:I = 0x7f090377

.field public static final reverse:I = 0x7f090378

.field public static final reverseSawtooth:I = 0x7f090379

.field public static final right:I = 0x7f09037a

.field public static final rightToLeft:I = 0x7f09037b

.field public static final right_icon:I = 0x7f09037c

.field public static final right_side:I = 0x7f09037d

.field public static final right_to_left:I = 0x7f09037e

.field public static final rounded:I = 0x7f09037f

.field public static final row_index_key:I = 0x7f090380

.field public static final row_perk_1:I = 0x7f090381

.field public static final row_perk_2:I = 0x7f090382

.field public static final row_perk_3:I = 0x7f090383

.field public static final row_perk_4:I = 0x7f090384

.field public static final row_perk_5:I = 0x7f090385

.field public static final row_starter_pills_1:I = 0x7f090386

.field public static final row_starter_pills_2:I = 0x7f090387

.field public static final save_non_transition_alpha:I = 0x7f090388

.field public static final save_overlay_view:I = 0x7f090389

.field public static final sawtooth:I = 0x7f09038a

.field public static final scale:I = 0x7f09038b

.field public static final screen:I = 0x7f09038c

.field public static final scroll:I = 0x7f09038d

.field public static final scrollIndicatorDown:I = 0x7f09038e

.field public static final scrollIndicatorUp:I = 0x7f09038f

.field public static final scrollView:I = 0x7f090390

.field public static final scrollable:I = 0x7f090391

.field public static final search_badge:I = 0x7f090392

.field public static final search_bar:I = 0x7f090393

.field public static final search_button:I = 0x7f090394

.field public static final search_close_btn:I = 0x7f090395

.field public static final search_edit_frame:I = 0x7f090396

.field public static final search_go_btn:I = 0x7f090397

.field public static final search_mag_icon:I = 0x7f090398

.field public static final search_plate:I = 0x7f090399

.field public static final search_src_text:I = 0x7f09039a

.field public static final search_voice_btn:I = 0x7f09039b

.field public static final secondss:I = 0x7f09039c

.field public static final segment_basic:I = 0x7f09039d

.field public static final segment_pro:I = 0x7f09039e

.field public static final select_1min:I = 0x7f09039f

.field public static final select_30sec:I = 0x7f0903a0

.field public static final select_3_min:I = 0x7f0903a1

.field public static final select_5_min:I = 0x7f0903a2

.field public static final select_dialog_listview:I = 0x7f0903a3

.field public static final selected:I = 0x7f0903a4

.field public static final selection_type:I = 0x7f0903a5

.field public static final server_status:I = 0x7f0903a6

.field public static final servercont_1_txt:I = 0x7f0903a7

.field public static final sharedValueSet:I = 0x7f0903a8

.field public static final sharedValueUnset:I = 0x7f0903a9

.field public static final shortcut:I = 0x7f0903aa

.field public static final showCoin:I = 0x7f0903ab

.field public static final showCustom:I = 0x7f0903ac

.field public static final showHome:I = 0x7f0903ad

.field public static final showTitle:I = 0x7f0903ae

.field public static final showbalance:I = 0x7f0903af

.field public static final sikkimimage:I = 0x7f0903b0

.field public static final sin:I = 0x7f0903b1

.field public static final skipCollapsed:I = 0x7f0903b2

.field public static final skipped:I = 0x7f0903b3

.field public static final slide:I = 0x7f0903b4

.field public static final sline1:I = 0x7f0903b5

.field public static final sline10:I = 0x7f0903b6

.field public static final sline11:I = 0x7f0903b7

.field public static final sline12:I = 0x7f0903b8

.field public static final sline13:I = 0x7f0903b9

.field public static final sline14:I = 0x7f0903ba

.field public static final sline15:I = 0x7f0903bb

.field public static final sline16:I = 0x7f0903bc

.field public static final sline17:I = 0x7f0903bd

.field public static final sline18:I = 0x7f0903be

.field public static final sline19:I = 0x7f0903bf

.field public static final sline2:I = 0x7f0903c0

.field public static final sline20:I = 0x7f0903c1

.field public static final sline21:I = 0x7f0903c2

.field public static final sline22:I = 0x7f0903c3

.field public static final sline23:I = 0x7f0903c4

.field public static final sline24:I = 0x7f0903c5

.field public static final sline25:I = 0x7f0903c6

.field public static final sline26:I = 0x7f0903c7

.field public static final sline27:I = 0x7f0903c8

.field public static final sline28:I = 0x7f0903c9

.field public static final sline29:I = 0x7f0903ca

.field public static final sline3:I = 0x7f0903cb

.field public static final sline30:I = 0x7f0903cc

.field public static final sline31:I = 0x7f0903cd

.field public static final sline32:I = 0x7f0903ce

.field public static final sline33:I = 0x7f0903cf

.field public static final sline34:I = 0x7f0903d0

.field public static final sline35:I = 0x7f0903d1

.field public static final sline36:I = 0x7f0903d2

.field public static final sline37:I = 0x7f0903d3

.field public static final sline38:I = 0x7f0903d4

.field public static final sline39:I = 0x7f0903d5

.field public static final sline4:I = 0x7f0903d6

.field public static final sline40:I = 0x7f0903d7

.field public static final sline41:I = 0x7f0903d8

.field public static final sline42:I = 0x7f0903d9

.field public static final sline43:I = 0x7f0903da

.field public static final sline44:I = 0x7f0903db

.field public static final sline45:I = 0x7f0903dc

.field public static final sline46:I = 0x7f0903dd

.field public static final sline47:I = 0x7f0903de

.field public static final sline48:I = 0x7f0903df

.field public static final sline49:I = 0x7f0903e0

.field public static final sline5:I = 0x7f0903e1

.field public static final sline6:I = 0x7f0903e2

.field public static final sline7:I = 0x7f0903e3

.field public static final sline8:I = 0x7f0903e4

.field public static final sline9:I = 0x7f0903e5

.field public static final snackbar_action:I = 0x7f0903e6

.field public static final snackbar_text:I = 0x7f0903e7

.field public static final snap:I = 0x7f0903e8

.field public static final snapMargins:I = 0x7f0903e9

.field public static final south:I = 0x7f0903ea

.field public static final spacer:I = 0x7f0903eb

.field public static final special_effects_controller_view_tag:I = 0x7f0903ec

.field public static final spinner_type_selection:I = 0x7f0903ed

.field public static final spline:I = 0x7f0903ee

.field public static final split_action_bar:I = 0x7f0903ef

.field public static final spread:I = 0x7f0903f0

.field public static final spread_inside:I = 0x7f0903f1

.field public static final spring:I = 0x7f0903f2

.field public static final square:I = 0x7f0903f3

.field public static final src_atop:I = 0x7f0903f4

.field public static final src_in:I = 0x7f0903f5

.field public static final src_over:I = 0x7f0903f6

.field public static final standard:I = 0x7f0903f7

.field public static final start:I = 0x7f0903f8

.field public static final startHorizontal:I = 0x7f0903f9

.field public static final startToEnd:I = 0x7f0903fa

.field public static final startVertical:I = 0x7f0903fb

.field public static final start_center:I = 0x7f0903fc

.field public static final staticLayout:I = 0x7f0903fd

.field public static final staticPostLayout:I = 0x7f0903fe

.field public static final stop:I = 0x7f0903ff

.field public static final stretch:I = 0x7f090400

.field public static final submenuarrow:I = 0x7f090401

.field public static final submit_area:I = 0x7f090402

.field public static final supportScrollUp:I = 0x7f090403

.field public static final t1:I = 0x7f090404

.field public static final t3:I = 0x7f090405

.field public static final tabMode:I = 0x7f090406

.field public static final tab_duration_monthly:I = 0x7f090407

.field public static final tab_duration_weekly:I = 0x7f090408

.field public static final tag_accessibility_actions:I = 0x7f090409

.field public static final tag_accessibility_clickable_spans:I = 0x7f09040a

.field public static final tag_accessibility_heading:I = 0x7f09040b

.field public static final tag_accessibility_pane_title:I = 0x7f09040c

.field public static final tag_compat_insets_dispatch:I = 0x7f09040d

.field public static final tag_on_apply_window_listener:I = 0x7f09040e

.field public static final tag_on_receive_content_listener:I = 0x7f09040f

.field public static final tag_on_receive_content_mime_types:I = 0x7f090410

.field public static final tag_screen_reader_focusable:I = 0x7f090411

.field public static final tag_state_description:I = 0x7f090412

.field public static final tag_system_bar_state_monitor:I = 0x7f090413

.field public static final tag_transition_group:I = 0x7f090414

.field public static final tag_unhandled_key_event_manager:I = 0x7f090415

.field public static final tag_unhandled_key_listeners:I = 0x7f090416

.field public static final tag_window_insets_animation_callback:I = 0x7f090417

.field public static final tashan_img:I = 0x7f090418

.field public static final tclotteryimage:I = 0x7f090419

.field public static final text:I = 0x7f09041a

.field public static final text2:I = 0x7f09041b

.field public static final text5minn:I = 0x7f09041c

.field public static final textEnd:I = 0x7f09041d

.field public static final textSpacerNoButtons:I = 0x7f09041e

.field public static final textSpacerNoTitle:I = 0x7f09041f

.field public static final textStart:I = 0x7f090420

.field public static final textTop:I = 0x7f090421

.field public static final textViewResult:I = 0x7f090422

.field public static final text_history_back_chevron:I = 0x7f090423

.field public static final text_input_end_icon:I = 0x7f090424

.field public static final text_input_error_icon:I = 0x7f090425

.field public static final text_input_start_icon:I = 0x7f090426

.field public static final text_pill_1min:I = 0x7f090427

.field public static final text_pill_30sec:I = 0x7f090428

.field public static final text_pill_all:I = 0x7f090429

.field public static final text_pill_high_acc:I = 0x7f09042a

.field public static final textclose:I = 0x7f09042b

.field public static final textdec:I = 0x7f09042c

.field public static final textinput_counter:I = 0x7f09042d

.field public static final textinput_error:I = 0x7f09042e

.field public static final textinput_helper_text:I = 0x7f09042f

.field public static final textinput_placeholder:I = 0x7f090430

.field public static final textinput_prefix_text:I = 0x7f090431

.field public static final textinput_suffix_text:I = 0x7f090432

.field public static final textok:I = 0x7f090433

.field public static final texttitle:I = 0x7f090434

.field public static final textview1:I = 0x7f090435

.field public static final textview10:I = 0x7f090436

.field public static final textview11:I = 0x7f090437

.field public static final textview12:I = 0x7f090438

.field public static final textview122:I = 0x7f090439

.field public static final textview123:I = 0x7f09043a

.field public static final textview124:I = 0x7f09043b

.field public static final textview125:I = 0x7f09043c

.field public static final textview126:I = 0x7f09043d

.field public static final textview127:I = 0x7f09043e

.field public static final textview128:I = 0x7f09043f

.field public static final textview168:I = 0x7f090440

.field public static final textview173:I = 0x7f090441

.field public static final textview175:I = 0x7f090442

.field public static final textview176:I = 0x7f090443

.field public static final textview178:I = 0x7f090444

.field public static final textview179:I = 0x7f090445

.field public static final textview180:I = 0x7f090446

.field public static final textview196:I = 0x7f090447

.field public static final textview197:I = 0x7f090448

.field public static final textview198:I = 0x7f090449

.field public static final textview199:I = 0x7f09044a

.field public static final textview2:I = 0x7f09044b

.field public static final textview204:I = 0x7f09044c

.field public static final textview205:I = 0x7f09044d

.field public static final textview206:I = 0x7f09044e

.field public static final textview208:I = 0x7f09044f

.field public static final textview21:I = 0x7f090450

.field public static final textview22:I = 0x7f090451

.field public static final textview23:I = 0x7f090452

.field public static final textview231:I = 0x7f090453

.field public static final textview232:I = 0x7f090454

.field public static final textview233:I = 0x7f090455

.field public static final textview234:I = 0x7f090456

.field public static final textview235:I = 0x7f090457

.field public static final textview236:I = 0x7f090458

.field public static final textview237:I = 0x7f090459

.field public static final textview24:I = 0x7f09045a

.field public static final textview31:I = 0x7f09045b

.field public static final textview45:I = 0x7f09045c

.field public static final textview46:I = 0x7f09045d

.field public static final textview47:I = 0x7f09045e

.field public static final textview56:I = 0x7f09045f

.field public static final textview6:I = 0x7f090460

.field public static final textview62:I = 0x7f090461

.field public static final textview7:I = 0x7f090462

.field public static final textview8:I = 0x7f090463

.field public static final textview9:I = 0x7f090464

.field public static final textview_51game:I = 0x7f090465

.field public static final textview_55club:I = 0x7f090466

.field public static final textview_6club:I = 0x7f090467

.field public static final textview_82lottery:I = 0x7f090468

.field public static final textview_91club:I = 0x7f090469

.field public static final textview_accu:I = 0x7f09046a

.field public static final textview_bdggame:I = 0x7f09046b

.field public static final textview_bdgwin:I = 0x7f09046c

.field public static final textview_bet_accuracy:I = 0x7f09046d

.field public static final textview_bet_suggestion:I = 0x7f09046e

.field public static final textview_bg:I = 0x7f09046f

.field public static final textview_bharatclub:I = 0x7f090470

.field public static final textview_bigmumbai:I = 0x7f090471

.field public static final textview_bottom:I = 0x7f090472

.field public static final textview_c:I = 0x7f090473

.field public static final textview_c2:I = 0x7f090474

.field public static final textview_chatbot:I = 0x7f090475

.field public static final textview_d1:I = 0x7f090476

.field public static final textview_d2:I = 0x7f090477

.field public static final textview_d3:I = 0x7f090478

.field public static final textview_d4:I = 0x7f090479

.field public static final textview_d5:I = 0x7f09047a

.field public static final textview_daman:I = 0x7f09047b

.field public static final textview_disclaimer:I = 0x7f09047c

.field public static final textview_diuwin:I = 0x7f09047d

.field public static final textview_dream99:I = 0x7f09047e

.field public static final textview_empty_history:I = 0x7f09047f

.field public static final textview_fail:I = 0x7f090480

.field public static final textview_future_date1:I = 0x7f090481

.field public static final textview_future_date2:I = 0x7f090482

.field public static final textview_game:I = 0x7f090483

.field public static final textview_goagames:I = 0x7f090484

.field public static final textview_h:I = 0x7f090485

.field public static final textview_head:I = 0x7f090486

.field public static final textview_history_main_title:I = 0x7f090487

.field public static final textview_home:I = 0x7f090488

.field public static final textview_i1:I = 0x7f090489

.field public static final textview_i2:I = 0x7f09048a

.field public static final textview_i3:I = 0x7f09048b

.field public static final textview_id:I = 0x7f09048c

.field public static final textview_in999:I = 0x7f09048d

.field public static final textview_jalwagame:I = 0x7f09048e

.field public static final textview_jc:I = 0x7f09048f

.field public static final textview_join:I = 0x7f090490

.field public static final textview_join2:I = 0x7f090491

.field public static final textview_locked:I = 0x7f090492

.field public static final textview_logic_version:I = 0x7f090493

.field public static final textview_m:I = 0x7f090494

.field public static final textview_middle:I = 0x7f090495

.field public static final textview_new_head:I = 0x7f090496

.field public static final textview_new_version:I = 0x7f090497

.field public static final textview_nngames:I = 0x7f090498

.field public static final textview_number_result:I = 0x7f090499

.field public static final textview_okwin:I = 0x7f09049a

.field public static final textview_pass:I = 0x7f09049b

.field public static final textview_pfox1min:I = 0x7f09049c

.field public static final textview_pfox30sec:I = 0x7f09049d

.field public static final textview_pre_user:I = 0x7f09049e

.field public static final textview_present_date:I = 0x7f09049f

.field public static final textview_previous_date1:I = 0x7f0904a0

.field public static final textview_previous_date2:I = 0x7f0904a1

.field public static final textview_profile:I = 0x7f0904a2

.field public static final textview_rajagame:I = 0x7f0904a3

.field public static final textview_re_days:I = 0x7f0904a4

.field public static final textview_s:I = 0x7f0904a5

.field public static final textview_server:I = 0x7f0904a6

.field public static final textview_server_info:I = 0x7f0904a7

.field public static final textview_server_status:I = 0x7f0904a8

.field public static final textview_sikkim:I = 0x7f0904a9

.field public static final textview_stats_info:I = 0x7f0904aa

.field public static final textview_status:I = 0x7f0904ab

.field public static final textview_subhead:I = 0x7f0904ac

.field public static final textview_suggestion_signals:I = 0x7f0904ad

.field public static final textview_suggestion_signals_text:I = 0x7f0904ae

.field public static final textview_tashanwin:I = 0x7f0904af

.field public static final textview_tb:I = 0x7f0904b0

.field public static final textview_tclottery:I = 0x7f0904b1

.field public static final textview_tiranga:I = 0x7f0904b2

.field public static final textview_token:I = 0x7f0904b3

.field public static final textview_top:I = 0x7f0904b4

.field public static final textview_topic:I = 0x7f0904b5

.field public static final textview_try_again:I = 0x7f0904b6

.field public static final textview_update:I = 0x7f0904b7

.field public static final textview_update_details:I = 0x7f0904b8

.field public static final textview_web:I = 0x7f0904b9

.field public static final textview_win101:I = 0x7f0904ba

.field public static final textview_wingo:I = 0x7f0904bb

.field public static final textview_yw:I = 0x7f0904bc

.field public static final time:I = 0x7f0904bd

.field public static final timeer:I = 0x7f0904be

.field public static final timer30s:I = 0x7f0904bf

.field public static final timmmmeeer:I = 0x7f0904c0

.field public static final tirangaimage:I = 0x7f0904c1

.field public static final title:I = 0x7f0904c2

.field public static final titleDividerNoCustom:I = 0x7f0904c3

.field public static final title_template:I = 0x7f0904c4

.field public static final tl:I = 0x7f0904c5

.field public static final toggle:I = 0x7f0904c6

.field public static final top:I = 0x7f0904c7

.field public static final topPanel:I = 0x7f0904c8

.field public static final top_center:I = 0x7f0904c9

.field public static final top_to_bottom:I = 0x7f0904ca

.field public static final total_accuracy:I = 0x7f0904cb

.field public static final total_bet:I = 0x7f0904cc

.field public static final total_loss:I = 0x7f0904cd

.field public static final total_win:I = 0x7f0904ce

.field public static final touch_outside:I = 0x7f0904cf

.field public static final transitionToEnd:I = 0x7f0904d0

.field public static final transitionToStart:I = 0x7f0904d1

.field public static final transition_clip:I = 0x7f0904d2

.field public static final transition_current_scene:I = 0x7f0904d3

.field public static final transition_image_transform:I = 0x7f0904d4

.field public static final transition_layout_save:I = 0x7f0904d5

.field public static final transition_pause_alpha:I = 0x7f0904d6

.field public static final transition_position:I = 0x7f0904d7

.field public static final transition_scene_layoutid_cache:I = 0x7f0904d8

.field public static final transition_transform:I = 0x7f0904d9

.field public static final triangle:I = 0x7f0904da

.field public static final tt:I = 0x7f0904db

.field public static final tv_active_tier_heading:I = 0x7f0904dc

.field public static final tv_brand_name:I = 0x7f0904dd

.field public static final tv_brand_tagline:I = 0x7f0904de

.field public static final tv_chevron_chat:I = 0x7f0904df

.field public static final tv_chevron_details:I = 0x7f0904e0

.field public static final tv_chevron_pred:I = 0x7f0904e1

.field public static final tv_close_icon:I = 0x7f0904e2

.field public static final tv_col_basic:I = 0x7f0904e3

.field public static final tv_col_features:I = 0x7f0904e4

.field public static final tv_col_free:I = 0x7f0904e5

.field public static final tv_col_pro:I = 0x7f0904e6

.field public static final tv_comp_free_chats:I = 0x7f0904e7

.field public static final tv_comp_free_preds:I = 0x7f0904e8

.field public static final tv_comp_sub_1:I = 0x7f0904e9

.field public static final tv_comp_sub_2:I = 0x7f0904ea

.field public static final tv_comp_sub_3:I = 0x7f0904eb

.field public static final tv_comp_sub_4:I = 0x7f0904ec

.field public static final tv_comp_sub_5:I = 0x7f0904ed

.field public static final tv_comp_sub_6:I = 0x7f0904ee

.field public static final tv_comp_title_1:I = 0x7f0904ef

.field public static final tv_comp_title_2:I = 0x7f0904f0

.field public static final tv_comp_title_3:I = 0x7f0904f1

.field public static final tv_comp_title_4:I = 0x7f0904f2

.field public static final tv_comp_title_5:I = 0x7f0904f3

.field public static final tv_comp_title_6:I = 0x7f0904f4

.field public static final tv_current_plan_badge:I = 0x7f0904f5

.field public static final tv_current_tokens_status:I = 0x7f0904f6

.field public static final tv_free_price:I = 0x7f0904f7

.field public static final tv_info_tier_tagline:I = 0x7f0904f8

.field public static final tv_info_tier_title:I = 0x7f0904f9

.field public static final tv_legal_terms:I = 0x7f0904fa

.field public static final tv_live_indicator:I = 0x7f0904fb

.field public static final tv_metric1_lbl:I = 0x7f0904fc

.field public static final tv_metric1_val:I = 0x7f0904fd

.field public static final tv_metric2_lbl:I = 0x7f0904fe

.field public static final tv_metric2_val:I = 0x7f0904ff

.field public static final tv_metric3_lbl:I = 0x7f090500

.field public static final tv_metric3_val:I = 0x7f090501

.field public static final tv_monthly_price:I = 0x7f090502

.field public static final tv_perk_1:I = 0x7f090503

.field public static final tv_perk_2:I = 0x7f090504

.field public static final tv_perk_3:I = 0x7f090505

.field public static final tv_perk_4:I = 0x7f090506

.field public static final tv_perk_5:I = 0x7f090507

.field public static final tv_pill_basic_text:I = 0x7f090508

.field public static final tv_pill_pro_text:I = 0x7f090509

.field public static final tv_price_monthly_sub:I = 0x7f09050a

.field public static final tv_price_weekly_sub:I = 0x7f09050b

.field public static final tv_price_weekly_val:I = 0x7f09050c

.field public static final tv_profile_btn_upgrade:I = 0x7f09050d

.field public static final tv_profile_chat_note:I = 0x7f09050e

.field public static final tv_profile_chat_tokens:I = 0x7f09050f

.field public static final tv_profile_details_sub:I = 0x7f090510

.field public static final tv_profile_details_title:I = 0x7f090511

.field public static final tv_profile_membership_label:I = 0x7f090512

.field public static final tv_profile_plan_badge:I = 0x7f090513

.field public static final tv_profile_plan_expiry:I = 0x7f090514

.field public static final tv_profile_plan_name:I = 0x7f090515

.field public static final tv_profile_pred_note:I = 0x7f090516

.field public static final tv_profile_pred_tokens:I = 0x7f090517

.field public static final tv_profile_status_dot:I = 0x7f090518

.field public static final tv_segment_basic:I = 0x7f090519

.field public static final tv_segment_pro:I = 0x7f09051a

.field public static final tv_special_offer_tag:I = 0x7f09051b

.field public static final tv_tab_monthly:I = 0x7f09051c

.field public static final tv_tab_weekly:I = 0x7f09051d

.field public static final tv_toggle_comparison_text:I = 0x7f09051e

.field public static final tv_trust_access:I = 0x7f09051f

.field public static final tv_trust_secure:I = 0x7f090520

.field public static final tv_trust_support:I = 0x7f090521

.field public static final tv_yearly_discount:I = 0x7f090522

.field public static final tv_yearly_price:I = 0x7f090523

.field public static final txt_chat_subtitle:I = 0x7f090524

.field public static final txt_chat_title:I = 0x7f090525

.field public static final txt_chat_typing_text:I = 0x7f090526

.field public static final txt_starter_mode:I = 0x7f090527

.field public static final txt_starter_server:I = 0x7f090528

.field public static final txt_starter_timings:I = 0x7f090529

.field public static final txt_starter_trade:I = 0x7f09052a

.field public static final txt_voice_icon:I = 0x7f09052b

.field public static final txt_welcome_subtitle:I = 0x7f09052c

.field public static final txt_welcome_title:I = 0x7f09052d

.field public static final unchecked:I = 0x7f09052e

.field public static final uniform:I = 0x7f09052f

.field public static final unlabeled:I = 0x7f090530

.field public static final up:I = 0x7f090531

.field public static final useLogo:I = 0x7f090532

.field public static final usernam:I = 0x7f090533

.field public static final vertical:I = 0x7f090534

.field public static final vertical_only:I = 0x7f090535

.field public static final view21:I = 0x7f090536

.field public static final view22:I = 0x7f090537

.field public static final view45:I = 0x7f090538

.field public static final view82:I = 0x7f090539

.field public static final view84:I = 0x7f09053a

.field public static final view86:I = 0x7f09053b

.field public static final view88:I = 0x7f09053c

.field public static final view90:I = 0x7f09053d

.field public static final view_bottom_white_shadow:I = 0x7f09053e

.field public static final view_divider_plan_details:I = 0x7f09053f

.field public static final view_matrix_divider:I = 0x7f090540

.field public static final view_offset_helper:I = 0x7f090541

.field public static final view_top_white_shadow:I = 0x7f090542

.field public static final view_transition:I = 0x7f090543

.field public static final view_tree_disjoint_parent:I = 0x7f090544

.field public static final view_tree_lifecycle_owner:I = 0x7f090545

.field public static final view_tree_on_back_pressed_dispatcher_owner:I = 0x7f090546

.field public static final view_tree_saved_state_registry_owner:I = 0x7f090547

.field public static final view_tree_view_model_store_owner:I = 0x7f090548

.field public static final visible:I = 0x7f090549

.field public static final visible_removing_fragment_view_tag:I = 0x7f09054a

.field public static final vscroll1:I = 0x7f09054b

.field public static final vscroll3:I = 0x7f09054c

.field public static final vscroll_chat:I = 0x7f09054d

.field public static final w1:I = 0x7f09054e

.field public static final w2:I = 0x7f09054f

.field public static final web:I = 0x7f090550

.field public static final webview:I = 0x7f090551

.field public static final webview1:I = 0x7f090552

.field public static final webview_btn:I = 0x7f090553

.field public static final west:I = 0x7f090554

.field public static final wide:I = 0x7f090555

.field public static final win101image:I = 0x7f090556

.field public static final wingminnn5text:I = 0x7f090557

.field public static final wingo1min_stats:I = 0x7f090558

.field public static final wingo1minn:I = 0x7f090559

.field public static final wingo1mins1:I = 0x7f09055a

.field public static final wingo1mins2:I = 0x7f09055b

.field public static final wingo30s:I = 0x7f09055c

.field public static final wingo30secs1:I = 0x7f09055d

.field public static final wingo30secs2:I = 0x7f09055e

.field public static final wingo30stextt:I = 0x7f09055f

.field public static final wingo3min:I = 0x7f090560

.field public static final wingo3minntext:I = 0x7f090561

.field public static final wingo5miml:I = 0x7f090562

.field public static final wingoo30stexxxt:I = 0x7f090563

.field public static final wingotext1minnntext:I = 0x7f090564

.field public static final wingotexxxtlinear:I = 0x7f090565

.field public static final withText:I = 0x7f090566

.field public static final with_icon:I = 0x7f090567

.field public static final withinBounds:I = 0x7f090568

.field public static final wrap:I = 0x7f090569

.field public static final wrap_content:I = 0x7f09056a

.field public static final wrap_content_constrained:I = 0x7f09056b

.field public static final x_left:I = 0x7f09056c

.field public static final x_right:I = 0x7f09056d

.field public static final yaar_img:I = 0x7f09056e


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 13427
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
