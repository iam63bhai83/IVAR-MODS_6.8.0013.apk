# classes88.dex

.class public final Landroidx/activity/R$xml;
.super Ljava/lang/Object;
.source "FoxSource"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/activity/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "xml"
.end annotation


# static fields
.field public static final file_paths:I = 0x7f130000

.field public static final m3_button_group_child_size_change:I = 0x7f130001

.field public static final m3_split_button_inner_corner_size_state_list:I = 0x7f130002

.field public static final m3expressive_button_shape_state_list:I = 0x7f130003

.field public static final m3expressive_connected_buttons_inner_corner_size_state_list:I = 0x7f130004


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 50211
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
