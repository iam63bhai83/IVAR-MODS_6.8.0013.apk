# classes88.dex

.class public final Landroidx/activity/R$plurals;
.super Ljava/lang/Object;
.source "FoxSource"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/activity/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "plurals"
.end annotation


# static fields
.field public static final mtrl_badge_content_description:I = 0x7f0f0000


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 15045
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
