# classes88.dex

.class public final Landroidx/appcompat/R$drawable;
.super Ljava/lang/Object;
.source "FoxSource"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "drawable"
.end annotation


# static fields
.field public static final abc_ab_share_pack_mtrl_alpha:I = 0x7f070028

.field public static final abc_action_bar_item_background_material:I = 0x7f070029

.field public static final abc_btn_borderless_material:I = 0x7f07002a

.field public static final abc_btn_check_material:I = 0x7f07002b

.field public static final abc_btn_check_material_anim:I = 0x7f07002c

.field public static final abc_btn_check_to_on_mtrl_000:I = 0x7f07002d

.field public static final abc_btn_check_to_on_mtrl_015:I = 0x7f07002e

.field public static final abc_btn_colored_material:I = 0x7f07002f

.field public static final abc_btn_default_mtrl_shape:I = 0x7f070030

.field public static final abc_btn_radio_material:I = 0x7f070031

.field public static final abc_btn_radio_material_anim:I = 0x7f070032

.field public static final abc_btn_radio_to_on_mtrl_000:I = 0x7f070033

.field public static final abc_btn_radio_to_on_mtrl_015:I = 0x7f070034

.field public static final abc_btn_switch_to_on_mtrl_00001:I = 0x7f070035

.field public static final abc_btn_switch_to_on_mtrl_00012:I = 0x7f070036

.field public static final abc_cab_background_internal_bg:I = 0x7f070037

.field public static final abc_cab_background_top_material:I = 0x7f070038

.field public static final abc_cab_background_top_mtrl_alpha:I = 0x7f070039

.field public static final abc_control_background_material:I = 0x7f07003a

.field public static final abc_dialog_material_background:I = 0x7f07003b

.field public static final abc_edit_text_material:I = 0x7f07003c

.field public static final abc_ic_ab_back_material:I = 0x7f07003d

.field public static final abc_ic_arrow_drop_right_black_24dp:I = 0x7f07003e

.field public static final abc_ic_clear_material:I = 0x7f07003f

.field public static final abc_ic_commit_search_api_mtrl_alpha:I = 0x7f070040

.field public static final abc_ic_go_search_api_material:I = 0x7f070041

.field public static final abc_ic_menu_copy_mtrl_am_alpha:I = 0x7f070042

.field public static final abc_ic_menu_cut_mtrl_alpha:I = 0x7f070043

.field public static final abc_ic_menu_overflow_material:I = 0x7f070044

.field public static final abc_ic_menu_paste_mtrl_am_alpha:I = 0x7f070045

.field public static final abc_ic_menu_selectall_mtrl_alpha:I = 0x7f070046

.field public static final abc_ic_menu_share_mtrl_alpha:I = 0x7f070047

.field public static final abc_ic_search_api_material:I = 0x7f070048

.field public static final abc_ic_voice_search_api_material:I = 0x7f070049

.field public static final abc_item_background_holo_dark:I = 0x7f07004a

.field public static final abc_item_background_holo_light:I = 0x7f07004b

.field public static final abc_list_divider_material:I = 0x7f07004c

.field public static final abc_list_divider_mtrl_alpha:I = 0x7f07004d

.field public static final abc_list_focused_holo:I = 0x7f07004e

.field public static final abc_list_longpressed_holo:I = 0x7f07004f

.field public static final abc_list_pressed_holo_dark:I = 0x7f070050

.field public static final abc_list_pressed_holo_light:I = 0x7f070051

.field public static final abc_list_selector_background_transition_holo_dark:I = 0x7f070052

.field public static final abc_list_selector_background_transition_holo_light:I = 0x7f070053

.field public static final abc_list_selector_disabled_holo_dark:I = 0x7f070054

.field public static final abc_list_selector_disabled_holo_light:I = 0x7f070055

.field public static final abc_list_selector_holo_dark:I = 0x7f070056

.field public static final abc_list_selector_holo_light:I = 0x7f070057

.field public static final abc_menu_hardkey_panel_mtrl_mult:I = 0x7f070058

.field public static final abc_popup_background_mtrl_mult:I = 0x7f070059

.field public static final abc_ratingbar_indicator_material:I = 0x7f07005a

.field public static final abc_ratingbar_material:I = 0x7f07005b

.field public static final abc_ratingbar_small_material:I = 0x7f07005c

.field public static final abc_scrubber_control_off_mtrl_alpha:I = 0x7f07005d

.field public static final abc_scrubber_control_to_pressed_mtrl_000:I = 0x7f07005e

.field public static final abc_scrubber_control_to_pressed_mtrl_005:I = 0x7f07005f

.field public static final abc_scrubber_primary_mtrl_alpha:I = 0x7f070060

.field public static final abc_scrubber_track_mtrl_alpha:I = 0x7f070061

.field public static final abc_seekbar_thumb_material:I = 0x7f070062

.field public static final abc_seekbar_tick_mark_material:I = 0x7f070063

.field public static final abc_seekbar_track_material:I = 0x7f070064

.field public static final abc_spinner_mtrl_am_alpha:I = 0x7f070065

.field public static final abc_spinner_textfield_background_material:I = 0x7f070066

.field public static final abc_star_black_48dp:I = 0x7f070067

.field public static final abc_star_half_black_48dp:I = 0x7f070068

.field public static final abc_switch_thumb_material:I = 0x7f070069

.field public static final abc_switch_track_mtrl_alpha:I = 0x7f07006a

.field public static final abc_tab_indicator_material:I = 0x7f07006b

.field public static final abc_tab_indicator_mtrl_alpha:I = 0x7f07006c

.field public static final abc_text_cursor_material:I = 0x7f07006d

.field public static final abc_text_select_handle_left_mtrl:I = 0x7f07006e

.field public static final abc_text_select_handle_middle_mtrl:I = 0x7f07006f

.field public static final abc_text_select_handle_right_mtrl:I = 0x7f070070

.field public static final abc_textfield_activated_mtrl_alpha:I = 0x7f070071

.field public static final abc_textfield_default_mtrl_alpha:I = 0x7f070072

.field public static final abc_textfield_search_activated_mtrl_alpha:I = 0x7f070073

.field public static final abc_textfield_search_default_mtrl_alpha:I = 0x7f070074

.field public static final abc_textfield_search_material:I = 0x7f070075

.field public static final abc_vector_test:I = 0x7f070076

.field public static final about_img:I = 0x7f070077

.field public static final active:I = 0x7f070078

.field public static final api:I = 0x7f070079

.field public static final app_icon:I = 0x7f07007a

.field public static final automation_icon:I = 0x7f07007b

.field public static final avd_hide_password:I = 0x7f07007c

.field public static final avd_show_password:I = 0x7f07007d

.field public static final bg_best_value_badge:I = 0x7f07007e

.field public static final bg_btn_free:I = 0x7f07007f

.field public static final bg_btn_pro_upgrade_white:I = 0x7f070080

.field public static final bg_card_monthly_selected:I = 0x7f070081

.field public static final bg_card_monthly_unselected:I = 0x7f070082

.field public static final bg_card_weekly_selected:I = 0x7f070083

.field public static final bg_card_weekly_unselected:I = 0x7f070084

.field public static final bg_circle_ring_emerald:I = 0x7f070085

.field public static final bg_circle_ring_emerald_subtle:I = 0x7f070086

.field public static final bg_comp_card_basic:I = 0x7f070087

.field public static final bg_comp_card_pro:I = 0x7f070088

.field public static final bg_comp_header_basic:I = 0x7f070089

.field public static final bg_comp_header_pro:I = 0x7f07008a

.field public static final bg_comparison_toggle:I = 0x7f07008b

.field public static final bg_cta_gradient:I = 0x7f07008c

.field public static final bg_cta_shine:I = 0x7f07008d

.field public static final bg_header_glow:I = 0x7f07008e

.field public static final bg_icon_box_amber:I = 0x7f07008f

.field public static final bg_icon_box_blue:I = 0x7f070090

.field public static final bg_icon_box_green:I = 0x7f070091

.field public static final bg_icon_box_purple:I = 0x7f070092

.field public static final bg_icon_box_red:I = 0x7f070093

.field public static final bg_icon_box_rose:I = 0x7f070094

.field public static final bg_nav_box_active:I = 0x7f070095

.field public static final bg_nav_box_inactive:I = 0x7f070096

.field public static final bg_nav_dot_active:I = 0x7f070097

.field public static final bg_nav_fab_glow:I = 0x7f070098

.field public static final bg_nav_pill_dock:I = 0x7f070099

.field public static final bg_pro_member_emerald_card:I = 0x7f07009a

.field public static final bg_segmented_tabs:I = 0x7f07009b

.field public static final bg_shadow_white:I = 0x7f07009c

.field public static final bg_status_card:I = 0x7f07009d

.field public static final bg_status_pill:I = 0x7f07009e

.field public static final bg_step_badge_active:I = 0x7f07009f

.field public static final bg_step_badge_done:I = 0x7f0700a0

.field public static final bg_subscription_dialog:I = 0x7f0700a1

.field public static final bg_tab_basic_selected:I = 0x7f0700a2

.field public static final bg_tab_pro_selected:I = 0x7f0700a3

.field public static final bg_tilted_badge_mint:I = 0x7f0700a4

.field public static final bg_token_pill:I = 0x7f0700a5

.field public static final bigg:I = 0x7f0700a6

.field public static final bottom_3:I = 0x7f0700a7

.field public static final bottom_5:I = 0x7f0700a8

.field public static final bottom_8:I = 0x7f0700a9

.field public static final btn_checkbox_checked_mtrl:I = 0x7f0700aa

.field public static final btn_checkbox_checked_to_unchecked_mtrl_animation:I = 0x7f0700ab

.field public static final btn_checkbox_unchecked_mtrl:I = 0x7f0700ac

.field public static final btn_checkbox_unchecked_to_checked_mtrl_animation:I = 0x7f0700ad

.field public static final btn_radio_off_mtrl:I = 0x7f0700ae

.field public static final btn_radio_off_to_on_mtrl_animation:I = 0x7f0700af

.field public static final btn_radio_on_mtrl:I = 0x7f0700b0

.field public static final btn_radio_on_to_off_mtrl_animation:I = 0x7f0700b1

.field public static final coic:I = 0x7f0700b2

.field public static final common_full_open_on_phone:I = 0x7f0700b3

.field public static final common_google_signin_btn_icon_dark:I = 0x7f0700b4

.field public static final common_google_signin_btn_icon_dark_focused:I = 0x7f0700b5

.field public static final common_google_signin_btn_icon_dark_normal:I = 0x7f0700b6

.field public static final common_google_signin_btn_icon_dark_normal_background:I = 0x7f0700b7

.field public static final common_google_signin_btn_icon_disabled:I = 0x7f0700b8

.field public static final common_google_signin_btn_icon_light:I = 0x7f0700b9

.field public static final common_google_signin_btn_icon_light_focused:I = 0x7f0700ba

.field public static final common_google_signin_btn_icon_light_normal:I = 0x7f0700bb

.field public static final common_google_signin_btn_icon_light_normal_background:I = 0x7f0700bc

.field public static final common_google_signin_btn_text_dark:I = 0x7f0700bd

.field public static final common_google_signin_btn_text_dark_focused:I = 0x7f0700be

.field public static final common_google_signin_btn_text_dark_normal:I = 0x7f0700bf

.field public static final common_google_signin_btn_text_dark_normal_background:I = 0x7f0700c0

.field public static final common_google_signin_btn_text_disabled:I = 0x7f0700c1

.field public static final common_google_signin_btn_text_light:I = 0x7f0700c2

.field public static final common_google_signin_btn_text_light_focused:I = 0x7f0700c3

.field public static final common_google_signin_btn_text_light_normal:I = 0x7f0700c4

.field public static final common_google_signin_btn_text_light_normal_background:I = 0x7f0700c5

.field public static final crown:I = 0x7f0700c6

.field public static final customer_support_img:I = 0x7f0700c7

.field public static final default_image:I = 0x7f0700c8

.field public static final design_fab_background:I = 0x7f0700c9

.field public static final design_ic_visibility:I = 0x7f0700ca

.field public static final design_ic_visibility_off:I = 0x7f0700cb

.field public static final design_password_eye:I = 0x7f0700cc

.field public static final design_snackbar_background:I = 0x7f0700cd

.field public static final disclaimer:I = 0x7f0700ce

.field public static final dotted_border_background:I = 0x7f0700cf

.field public static final error:I = 0x7f0700d0

.field public static final error_img:I = 0x7f0700d1

.field public static final fjfjfjf:I = 0x7f0700d2

.field public static final fox:I = 0x7f0700d3

.field public static final fox_logo:I = 0x7f0700d4

.field public static final game_image:I = 0x7f0700d5

.field public static final generate:I = 0x7f0700d6

.field public static final gift:I = 0x7f0700d7

.field public static final gjfjff:I = 0x7f0700d8

.field public static final googleg_disabled_color_18:I = 0x7f0700d9

.field public static final googleg_standard_color_18:I = 0x7f0700da

.field public static final gradi:I = 0x7f0700db

.field public static final hhhhuhb:I = 0x7f0700dc

.field public static final hhhj:I = 0x7f0700dd

.field public static final home_enterface:I = 0x7f0700de

.field public static final ic_arrow_back_black:I = 0x7f0700df

.field public static final ic_arrow_back_black_24:I = 0x7f0700e0

.field public static final ic_arrow_chevron:I = 0x7f0700e1

.field public static final ic_best_value:I = 0x7f0700e2

.field public static final ic_call_answer:I = 0x7f0700e3

.field public static final ic_call_answer_low:I = 0x7f0700e4

.field public static final ic_call_answer_video:I = 0x7f0700e5

.field public static final ic_call_answer_video_low:I = 0x7f0700e6

.field public static final ic_call_decline:I = 0x7f0700e7

.field public static final ic_call_decline_low:I = 0x7f0700e8

.field public static final ic_check_circle:I = 0x7f0700e9

.field public static final ic_clear_black_24:I = 0x7f0700ea

.field public static final ic_clock_black_24dp:I = 0x7f0700eb

.field public static final ic_close:I = 0x7f0700ec

.field public static final ic_engine:I = 0x7f0700ed

.field public static final ic_exit_to_app_black:I = 0x7f0700ee

.field public static final ic_expand_less_22px:I = 0x7f0700ef

.field public static final ic_expand_more_22px:I = 0x7f0700f0

.field public static final ic_fox_ai:I = 0x7f0700f1

.field public static final ic_hud:I = 0x7f0700f2

.field public static final ic_keyboard_backspace_black:I = 0x7f0700f3

.field public static final ic_keyboard_black_24dp:I = 0x7f0700f4

.field public static final ic_lightning:I = 0x7f0700f5

.field public static final ic_lock_badge:I = 0x7f0700f6

.field public static final ic_m3_chip_check:I = 0x7f0700f7

.field public static final ic_m3_chip_checked_circle:I = 0x7f0700f8

.field public static final ic_m3_chip_close:I = 0x7f0700f9

.field public static final ic_mtrl_arrow_circle:I = 0x7f0700fa

.field public static final ic_mtrl_checked_circle:I = 0x7f0700fb

.field public static final ic_mtrl_chip_checked_black:I = 0x7f0700fc

.field public static final ic_mtrl_chip_checked_circle:I = 0x7f0700fd

.field public static final ic_mtrl_chip_close_circle:I = 0x7f0700fe

.field public static final ic_neural:I = 0x7f0700ff

.field public static final ic_radio_checked:I = 0x7f070100

.field public static final ic_radio_unchecked:I = 0x7f070101

.field public static final ic_restore:I = 0x7f070102

.field public static final ic_search_black_24:I = 0x7f070103

.field public static final ic_shield:I = 0x7f070104

.field public static final ic_token:I = 0x7f070105

.field public static final ic_vip_crown:I = 0x7f070106

.field public static final icon_content_copy_round:I = 0x7f070107

.field public static final icon_not_started_round:I = 0x7f070108

.field public static final iiiijjuu:I = 0x7f070109

.field public static final img_info_illustration:I = 0x7f07010a

.field public static final indeterminate_static:I = 0x7f07010b

.field public static final ivar_watermark:I = 0x7f07010c

.field public static final jjjji:I = 0x7f07010d

.field public static final join_img:I = 0x7f07010e

.field public static final loadingg:I = 0x7f07010f

.field public static final login_screen:I = 0x7f070110

.field public static final m3_avd_hide_password:I = 0x7f070111

.field public static final m3_avd_show_password:I = 0x7f070112

.field public static final m3_bottom_sheet_drag_handle:I = 0x7f070113

.field public static final m3_password_eye:I = 0x7f070114

.field public static final m3_popupmenu_background_overlay:I = 0x7f070115

.field public static final m3_radiobutton_ripple:I = 0x7f070116

.field public static final m3_selection_control_ripple:I = 0x7f070117

.field public static final m3_split_button_chevron_avd:I = 0x7f070118

.field public static final m3_tabs_background:I = 0x7f070119

.field public static final m3_tabs_line_indicator:I = 0x7f07011a

.field public static final m3_tabs_rounded_line_indicator:I = 0x7f07011b

.field public static final m3_tabs_transparent_background:I = 0x7f07011c

.field public static final main:I = 0x7f07011d

.field public static final material_cursor_drawable:I = 0x7f07011e

.field public static final material_ic_calendar_black_24dp:I = 0x7f07011f

.field public static final material_ic_clear_black_24dp:I = 0x7f070120

.field public static final material_ic_edit_black_24dp:I = 0x7f070121

.field public static final material_ic_keyboard_arrow_left_black_24dp:I = 0x7f070122

.field public static final material_ic_keyboard_arrow_next_black_24dp:I = 0x7f070123

.field public static final material_ic_keyboard_arrow_previous_black_24dp:I = 0x7f070124

.field public static final material_ic_keyboard_arrow_right_black_24dp:I = 0x7f070125

.field public static final material_ic_menu_arrow_down_black_24dp:I = 0x7f070126

.field public static final material_ic_menu_arrow_up_black_24dp:I = 0x7f070127

.field public static final menu:I = 0x7f070128

.field public static final mtrl_bottomsheet_drag_handle:I = 0x7f070129

.field public static final mtrl_checkbox_button:I = 0x7f07012a

.field public static final mtrl_checkbox_button_checked_unchecked:I = 0x7f07012b

.field public static final mtrl_checkbox_button_icon:I = 0x7f07012c

.field public static final mtrl_checkbox_button_icon_checked_indeterminate:I = 0x7f07012d

.field public static final mtrl_checkbox_button_icon_checked_unchecked:I = 0x7f07012e

.field public static final mtrl_checkbox_button_icon_indeterminate_checked:I = 0x7f07012f

.field public static final mtrl_checkbox_button_icon_indeterminate_unchecked:I = 0x7f070130

.field public static final mtrl_checkbox_button_icon_unchecked_checked:I = 0x7f070131

.field public static final mtrl_checkbox_button_icon_unchecked_indeterminate:I = 0x7f070132

.field public static final mtrl_checkbox_button_unchecked_checked:I = 0x7f070133

.field public static final mtrl_dialog_background:I = 0x7f070134

.field public static final mtrl_dropdown_arrow:I = 0x7f070135

.field public static final mtrl_ic_arrow_drop_down:I = 0x7f070136

.field public static final mtrl_ic_arrow_drop_up:I = 0x7f070137

.field public static final mtrl_ic_cancel:I = 0x7f070138

.field public static final mtrl_ic_check_mark:I = 0x7f070139

.field public static final mtrl_ic_checkbox_checked:I = 0x7f07013a

.field public static final mtrl_ic_checkbox_unchecked:I = 0x7f07013b

.field public static final mtrl_ic_error:I = 0x7f07013c

.field public static final mtrl_ic_indeterminate:I = 0x7f07013d

.field public static final mtrl_navigation_bar_item_background:I = 0x7f07013e

.field public static final mtrl_popupmenu_background:I = 0x7f07013f

.field public static final mtrl_popupmenu_background_overlay:I = 0x7f070140

.field public static final mtrl_switch_thumb:I = 0x7f070141

.field public static final mtrl_switch_thumb_checked:I = 0x7f070142

.field public static final mtrl_switch_thumb_checked_pressed:I = 0x7f070143

.field public static final mtrl_switch_thumb_checked_unchecked:I = 0x7f070144

.field public static final mtrl_switch_thumb_pressed:I = 0x7f070145

.field public static final mtrl_switch_thumb_pressed_checked:I = 0x7f070146

.field public static final mtrl_switch_thumb_pressed_unchecked:I = 0x7f070147

.field public static final mtrl_switch_thumb_unchecked:I = 0x7f070148

.field public static final mtrl_switch_thumb_unchecked_checked:I = 0x7f070149

.field public static final mtrl_switch_thumb_unchecked_pressed:I = 0x7f07014a

.field public static final mtrl_switch_track:I = 0x7f07014b

.field public static final mtrl_switch_track_decoration:I = 0x7f07014c

.field public static final mtrl_tabs_default_indicator:I = 0x7f07014d

.field public static final navigation_empty_icon:I = 0x7f07014e

.field public static final nointernet:I = 0x7f07014f

.field public static final notification_action_background:I = 0x7f070150

.field public static final notification_bg:I = 0x7f070151

.field public static final notification_bg_low:I = 0x7f070152

.field public static final notification_bg_low_normal:I = 0x7f070153

.field public static final notification_bg_low_pressed:I = 0x7f070154

.field public static final notification_bg_normal:I = 0x7f070155

.field public static final notification_bg_normal_pressed:I = 0x7f070156

.field public static final notification_icon_background:I = 0x7f070157

.field public static final notification_oversize_large_icon_bg:I = 0x7f070158

.field public static final notification_template_icon_bg:I = 0x7f070159

.field public static final notification_template_icon_low_bg:I = 0x7f07015a

.field public static final notification_tile_bg:I = 0x7f07015b

.field public static final notify_panel_notification_icon_bg:I = 0x7f07015c

.field public static final policy:I = 0x7f07015d

.field public static final premium_user:I = 0x7f07015e

.field public static final profile:I = 0x7f07015f

.field public static final profile_bg:I = 0x7f070160

.field public static final rbrjrjr:I = 0x7f070161

.field public static final rjrjrjr:I = 0x7f070162

.field public static final shared:I = 0x7f070163

.field public static final smalll:I = 0x7f070164

.field public static final telegram:I = 0x7f070165

.field public static final terms:I = 0x7f070166

.field public static final test_level_drawable:I = 0x7f070167

.field public static final time_set_icon1_1:I = 0x7f070168

.field public static final time_set_icon1_2:I = 0x7f070169

.field public static final timerr:I = 0x7f07016a

.field public static final toggle_off:I = 0x7f07016b

.field public static final toggle_on:I = 0x7f07016c

.field public static final tooltip_frame_dark:I = 0x7f07016d

.field public static final tooltip_frame_light:I = 0x7f07016e

.field public static final update_img:I = 0x7f07016f

.field public static final update_tg_img:I = 0x7f070170

.field public static final user_agreement:I = 0x7f070171

.field public static final vvv:I = 0x7f070172


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 13090
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
