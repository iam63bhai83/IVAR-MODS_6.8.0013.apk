# classes88.dex

.class public final Landroidx/appcompat/R;
.super Ljava/lang/Object;
.source "FoxSource"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/appcompat/R$anim;,
        Landroidx/appcompat/R$animator;,
        Landroidx/appcompat/R$attr;,
        Landroidx/appcompat/R$bool;,
        Landroidx/appcompat/R$color;,
        Landroidx/appcompat/R$dimen;,
        Landroidx/appcompat/R$drawable;,
        Landroidx/appcompat/R$font;,
        Landroidx/appcompat/R$id;,
        Landroidx/appcompat/R$integer;,
        Landroidx/appcompat/R$interpolator;,
        Landroidx/appcompat/R$layout;,
        Landroidx/appcompat/R$mipmap;,
        Landroidx/appcompat/R$plurals;,
        Landroidx/appcompat/R$string;,
        Landroidx/appcompat/R$style;,
        Landroidx/appcompat/R$styleable;,
        Landroidx/appcompat/R$xml;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
