# classes88.dex

.class public final Landroidx/appcompat/R$font;
.super Ljava/lang/Object;
.source "FoxSource"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "font"
.end annotation


# static fields
.field public static final digital:I = 0x7f080000

.field public static final ivxr:I = 0x7f080001


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 13423
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
