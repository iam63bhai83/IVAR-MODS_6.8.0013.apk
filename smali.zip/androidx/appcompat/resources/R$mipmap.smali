# classes88.dex

.class public final Landroidx/appcompat/resources/R$mipmap;
.super Ljava/lang/Object;
.source "FoxSource"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/resources/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "mipmap"
.end annotation


# static fields
.field public static final ic_launcher:I = 0x7f0e0000


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 15042
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
