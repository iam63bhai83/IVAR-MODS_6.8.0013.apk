# classes88.dex

.class public final Landroidx/appcompat/resources/R;
.super Ljava/lang/Object;
.source "FoxSource"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/appcompat/resources/R$anim;,
        Landroidx/appcompat/resources/R$animator;,
        Landroidx/appcompat/resources/R$attr;,
        Landroidx/appcompat/resources/R$bool;,
        Landroidx/appcompat/resources/R$color;,
        Landroidx/appcompat/resources/R$dimen;,
        Landroidx/appcompat/resources/R$drawable;,
        Landroidx/appcompat/resources/R$font;,
        Landroidx/appcompat/resources/R$id;,
        Landroidx/appcompat/resources/R$integer;,
        Landroidx/appcompat/resources/R$interpolator;,
        Landroidx/appcompat/resources/R$layout;,
        Landroidx/appcompat/resources/R$mipmap;,
        Landroidx/appcompat/resources/R$plurals;,
        Landroidx/appcompat/resources/R$string;,
        Landroidx/appcompat/resources/R$style;,
        Landroidx/appcompat/resources/R$styleable;,
        Landroidx/appcompat/resources/R$xml;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
