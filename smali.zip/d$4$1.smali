# classes88.dex

.class Ld$4$1;
.super Ljava/lang/Object;
.source "FoxSource"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ld$4;->onClick(Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ld$4;

.field private final synthetic b:Landroid/app/Activity;

.field private final synthetic c:Landroid/widget/TextView;

.field private final synthetic d:Landroid/view/View;

.field private final synthetic e:Landroid/widget/TextView;

.field private final synthetic f:Landroid/widget/Button;

.field private final synthetic g:Landroid/widget/TextView;

.field private final synthetic h:Landroid/widget/TextView;


# direct methods
.method constructor <init>(Ld$4;Landroid/app/Activity;Landroid/widget/TextView;Landroid/view/View;Landroid/widget/TextView;Landroid/widget/Button;Landroid/widget/TextView;Landroid/widget/TextView;)V
    .registers 9

    .line 2010
    iput-object p1, p0, Ld$4$1;->a:Ld$4;

    iput-object p2, p0, Ld$4$1;->b:Landroid/app/Activity;

    iput-object p3, p0, Ld$4$1;->c:Landroid/widget/TextView;

    iput-object p4, p0, Ld$4$1;->d:Landroid/view/View;

    iput-object p5, p0, Ld$4$1;->e:Landroid/widget/TextView;

    iput-object p6, p0, Ld$4$1;->f:Landroid/widget/Button;

    iput-object p7, p0, Ld$4$1;->g:Landroid/widget/TextView;

    iput-object p8, p0, Ld$4$1;->h:Landroid/widget/TextView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 8

    .line 2013
    iget-object v0, p0, Ld$4$1;->b:Landroid/app/Activity;

    invoke-static {v0}, Ld;->c(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    .line 2014
    iget-object v1, p0, Ld$4$1;->b:Landroid/app/Activity;

    invoke-static {v1}, Ld;->g(Landroid/content/Context;)I

    move-result v1

    .line 2015
    iget-object v2, p0, Ld$4$1;->b:Landroid/app/Activity;

    invoke-static {v2}, Ld;->h(Landroid/content/Context;)I

    .line 2016
    iget-object v2, p0, Ld$4$1;->b:Landroid/app/Activity;

    invoke-static {}, Ld;->r()Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x0

    invoke-virtual {v2, v3, v4}, Landroid/app/Activity;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v2

    .line 2017
    invoke-static {}, Le;->aP()Ljava/lang/String;

    move-result-object v3

    const-string v5, "MTUvQUEKJDRIXAo5J1U="

    invoke-static {v5}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/16 v6, 0x32

    invoke-interface {v2, v5, v6}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v5

    invoke-interface {v2, v3, v5}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    .line 2018
    invoke-static {}, Le;->aQ()Ljava/lang/String;

    move-result-object v3

    const-string v5, "MTUvQUEKNy5MTAo5J1U="

    invoke-static {v5}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/16 v6, 0xa

    invoke-interface {v2, v5, v6}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v5

    invoke-interface {v2, v3, v5}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    .line 2019
    iget-object v2, p0, Ld$4$1;->c:Landroid/widget/TextView;

    if-eqz v2, :cond_66

    .line 2020
    sget-object v3, Ld;->c:Ljava/lang/String;

    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_55

    const-string v3, "BSYpDW4cBA=="

    :goto_50
    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    goto :goto_63

    :cond_55
    sget-object v3, Ld;->b:Ljava/lang/String;

    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_60

    const-string v3, "FzU1RFt1Ag99"

    goto :goto_50

    :cond_60
    const-string v3, "EyYjSBgFOCdD"

    goto :goto_50

    :goto_63
    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2022
    :cond_66
    iget-object v2, p0, Ld$4$1;->d:Landroid/view/View;

    const-string v3, "dmV2bwFtZQ=="

    if-eqz v2, :cond_b1

    .line 2023
    new-instance v2, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v2}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const/4 v5, 0x1

    .line 2024
    invoke-virtual {v2, v5}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    .line 2025
    sget-object v5, Ld;->c:Ljava/lang/String;

    invoke-virtual {v5, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_8b

    .line 2026
    const-string v5, "dmN+GwgQFQ=="

    invoke-static {v5}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v2, v5}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    goto :goto_ac

    .line 2027
    :cond_8b
    sget-object v5, Ld;->b:Ljava/lang/String;

    invoke-virtual {v5, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_a1

    .line 2028
    const-string v5, "dmR+FAkXZg=="

    invoke-static {v5}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v2, v5}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    goto :goto_ac

    .line 2030
    :cond_a1
    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v2, v5}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 2032
    :goto_ac
    iget-object v5, p0, Ld$4$1;->d:Landroid/view/View;

    invoke-virtual {v5, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2034
    :cond_b1
    iget-object v2, p0, Ld$4$1;->e:Landroid/widget/TextView;

    if-eqz v2, :cond_10e

    .line 2035
    sget-object v2, Ld;->c:Ljava/lang/String;

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_f6

    sget-object v2, Ld;->b:Ljava/lang/String;

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_c6

    goto :goto_f6

    .line 2039
    :cond_c6
    iget-object v2, p0, Ld$4$1;->e:Landroid/widget/TextView;

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v5, "t9TkDQ=="

    invoke-static {v5}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-direct {v3, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "dRgjS0w="

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2040
    iget-object v1, p0, Ld$4$1;->e:Landroid/widget/TextView;

    const-string v2, "dmJyGgxtFg=="

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextColor(I)V

    goto :goto_10e

    .line 2036
    :cond_f6
    :goto_f6
    iget-object v1, p0, Ld$4$1;->e:Landroid/widget/TextView;

    const-string v2, "t9TkDW07OC9AUSExIg=="

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2037
    iget-object v1, p0, Ld$4$1;->e:Landroid/widget/TextView;

    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 2043
    :cond_10e
    :goto_10e
    iget-object v1, p0, Ld$4$1;->f:Landroid/widget/Button;

    if-eqz v1, :cond_13b

    .line 2044
    sget-object v1, Ld;->c:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_134

    sget-object v1, Ld;->b:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_123

    goto :goto_134

    .line 2047
    :cond_123
    iget-object v1, p0, Ld$4$1;->f:Landroid/widget/Button;

    invoke-virtual {v1, v4}, Landroid/widget/Button;->setVisibility(I)V

    .line 2048
    iget-object v1, p0, Ld$4$1;->f:Landroid/widget/Button;

    const-string v2, "FjsoWVE7ISMNficxIw=="

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    goto :goto_13b

    .line 2045
    :cond_134
    :goto_134
    iget-object v1, p0, Ld$4$1;->f:Landroid/widget/Button;

    const/16 v2, 0x8

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setVisibility(I)V

    .line 2051
    :cond_13b
    :goto_13b
    iget-object v1, p0, Ld$4$1;->g:Landroid/widget/TextView;

    if-eqz v1, :cond_14c

    .line 2052
    iget-object v2, p0, Ld$4$1;->b:Landroid/app/Activity;

    invoke-static {v2}, Ld;->q(Landroid/content/Context;)I

    move-result v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2054
    :cond_14c
    iget-object v1, p0, Ld$4$1;->h:Landroid/widget/TextView;

    if-eqz v1, :cond_15d

    .line 2055
    iget-object v2, p0, Ld$4$1;->b:Landroid/app/Activity;

    invoke-static {v2}, Ld;->r(Landroid/content/Context;)I

    move-result v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2057
    :cond_15d
    iget-object v1, p0, Ld$4$1;->b:Landroid/app/Activity;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Bi0oTl0xdWZuTScmI0NMdQQqTFZvdA=="

    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0, v4}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void
.end method
