# classes88.dex

.class Ld$17;
.super Ljava/lang/Object;
.source "FoxSource"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ld;->b(Landroid/app/Activity;Landroid/app/Dialog;Ljava/lang/String;IIIILandroid/content/SharedPreferences;)Landroid/view/View;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private final synthetic a:[Z

.field private final synthetic b:Landroid/widget/LinearLayout;

.field private final synthetic c:Ljava/lang/Runnable;


# direct methods
.method constructor <init>([ZLandroid/widget/LinearLayout;Ljava/lang/Runnable;)V
    .registers 4

    .line 3536
    iput-object p1, p0, Ld$17;->a:[Z

    iput-object p2, p0, Ld$17;->b:Landroid/widget/LinearLayout;

    iput-object p3, p0, Ld$17;->c:Ljava/lang/Runnable;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 3

    .line 3539
    iget-object p1, p0, Ld$17;->a:[Z

    const/4 v0, 0x0

    aput-boolean v0, p1, v0

    .line 3540
    iget-object p1, p0, Ld$17;->b:Landroid/widget/LinearLayout;

    iget-object v0, p0, Ld$17;->c:Ljava/lang/Runnable;

    invoke-static {p1, v0}, Ld;->a(Landroid/view/View;Ljava/lang/Runnable;)V

    return-void
.end method
