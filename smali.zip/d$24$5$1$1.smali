# classes88.dex

.class Ld$24$5$1$1;
.super Ljava/lang/Object;
.source "FoxSource"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ld$24$5$1;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ld$24$5$1;

.field private final synthetic b:Landroid/widget/Button;

.field private final synthetic c:Z

.field private final synthetic d:[Z

.field private final synthetic e:Landroid/content/SharedPreferences;

.field private final synthetic f:Landroid/app/Activity;

.field private final synthetic g:Landroid/app/Dialog;

.field private final synthetic h:Ljava/lang/Runnable;

.field private final synthetic i:Landroid/widget/TextView;


# direct methods
.method constructor <init>(Ld$24$5$1;Landroid/widget/Button;Z[ZLandroid/content/SharedPreferences;Landroid/app/Activity;Landroid/app/Dialog;Ljava/lang/Runnable;Landroid/widget/TextView;)V
    .registers 10

    .line 3987
    iput-object p1, p0, Ld$24$5$1$1;->a:Ld$24$5$1;

    iput-object p2, p0, Ld$24$5$1$1;->b:Landroid/widget/Button;

    iput-boolean p3, p0, Ld$24$5$1$1;->c:Z

    iput-object p4, p0, Ld$24$5$1$1;->d:[Z

    iput-object p5, p0, Ld$24$5$1$1;->e:Landroid/content/SharedPreferences;

    iput-object p6, p0, Ld$24$5$1$1;->f:Landroid/app/Activity;

    iput-object p7, p0, Ld$24$5$1$1;->g:Landroid/app/Dialog;

    iput-object p8, p0, Ld$24$5$1$1;->h:Ljava/lang/Runnable;

    iput-object p9, p0, Ld$24$5$1$1;->i:Landroid/widget/TextView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 4

    .line 3990
    iget-object v0, p0, Ld$24$5$1$1;->b:Landroid/widget/Button;

    const-string v1, "FjwjTlN1AiNfUTM9JUxMPDsoDWshNTJYSw=="

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 3991
    iget-object v0, p0, Ld$24$5$1$1;->b:Landroid/widget/Button;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setEnabled(Z)V

    .line 3993
    iget-boolean v0, p0, Ld$24$5$1$1;->c:Z

    if-eqz v0, :cond_49

    .line 3994
    iget-object v0, p0, Ld$24$5$1$1;->d:[Z

    const/4 v2, 0x0

    aput-boolean v1, v0, v2

    .line 3995
    iget-object v0, p0, Ld$24$5$1$1;->e:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-static {}, Ld;->p()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 3996
    iget-object v0, p0, Ld$24$5$1$1;->f:Landroid/app/Activity;

    const-string v2, "GjIgRFs8NSoNbDA4I0pKNDlmblA0OihIVHUCI19RMz0jSRl1EjRIXXUEKkxWdQEoQVc2PyNJFg=="

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 3997
    :try_start_3a
    iget-object v0, p0, Ld$24$5$1$1;->g:Landroid/app/Dialog;

    invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V
    :try_end_3f
    .catchall {:try_start_3a .. :try_end_3f} :catchall_40

    goto :goto_41

    :catchall_40
    nop

    .line 3998
    :goto_41
    iget-object v0, p0, Ld$24$5$1$1;->h:Ljava/lang/Runnable;

    if-eqz v0, :cond_48

    .line 3999
    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    :cond_48
    return-void

    .line 4002
    :cond_49
    iget-object v0, p0, Ld$24$5$1$1;->f:Landroid/app/Activity;

    const-string v2, "GiQjQxghPCMNSzA4I05MMDBmTlc4OTNDUSEtZk5QNDooSFR1NShJGDY7KFlROyEjAw=="

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 4003
    iget-object v0, p0, Ld$24$5$1$1;->i:Landroid/widget/TextView;

    const-string v1, "GiQjQxghPCMNSzA4I05MMDBmTlc4OTNDUSEtZk5QNDooSFR1NShJGDY7KFlROyEjAw=="

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method
