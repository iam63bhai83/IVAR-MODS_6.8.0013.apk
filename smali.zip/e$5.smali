# classes88.dex

.class Le$5;
.super Ljava/lang/Object;
.source "FoxSource"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Le;->a(Landroid/app/Activity;Landroid/content/SharedPreferences;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private final synthetic a:Landroid/app/Activity;


# direct methods
.method constructor <init>(Landroid/app/Activity;)V
    .registers 2

    .line 1481
    iput-object p1, p0, Le$5;->a:Landroid/app/Activity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 3

    const-wide/16 v0, 0x708

    .line 1485
    :try_start_2
    invoke-static {v0, v1}, Ljava/lang/Thread;->sleep(J)V

    .line 1486
    iget-object v0, p0, Le$5;->a:Landroid/app/Activity;

    invoke-static {v0}, Le;->n(Landroid/app/Activity;)Z

    move-result v0

    if-eqz v0, :cond_17

    iget-object v0, p0, Le$5;->a:Landroid/app/Activity;

    invoke-static {v0}, Le;->l(Landroid/app/Activity;)Z

    move-result v0

    if-nez v0, :cond_16

    goto :goto_17

    :cond_16
    return-void

    .line 1487
    :cond_17
    :goto_17
    iget-object v0, p0, Le$5;->a:Landroid/app/Activity;

    invoke-static {v0}, Le;->f(Landroid/app/Activity;)V
    :try_end_1c
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_1c} :catch_1d

    return-void

    .line 1490
    :catch_1d
    iget-object v0, p0, Le$5;->a:Landroid/app/Activity;

    invoke-static {v0}, Le;->f(Landroid/app/Activity;)V

    return-void
.end method
