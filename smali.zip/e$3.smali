# classes88.dex

.class Le$3;
.super Ljava/lang/Object;
.source "FoxSource"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Le;->e(Landroid/app/Activity;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private final synthetic a:Landroid/app/Activity;


# direct methods
.method constructor <init>(Landroid/app/Activity;)V
    .registers 2

    .line 355
    iput-object p1, p0, Le$3;->a:Landroid/app/Activity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 4

    .line 359
    :try_start_0
    iget-object v0, p0, Le$3;->a:Landroid/app/Activity;

    invoke-static {v0}, Le;->j(Landroid/app/Activity;)Z

    move-result v0

    if-eqz v0, :cond_28

    iget-object v0, p0, Le$3;->a:Landroid/app/Activity;

    invoke-static {v0}, Le;->k(Landroid/app/Activity;)Z

    move-result v0

    if-eqz v0, :cond_28

    iget-object v0, p0, Le$3;->a:Landroid/app/Activity;

    invoke-static {v0}, Le;->l(Landroid/app/Activity;)Z

    move-result v0

    if-eqz v0, :cond_28

    iget-object v0, p0, Le$3;->a:Landroid/app/Activity;

    invoke-static {v0}, Le;->m(Landroid/app/Activity;)Z

    move-result v0

    if-nez v0, :cond_28

    iget-object v0, p0, Le$3;->a:Landroid/app/Activity;

    invoke-static {v0}, Le;->n(Landroid/app/Activity;)Z

    move-result v0

    if-nez v0, :cond_46

    .line 360
    :cond_28
    iget-object v0, p0, Le$3;->a:Landroid/app/Activity;

    if-eqz v0, :cond_46

    .line 361
    new-instance v1, Le$3$1;

    iget-object v2, p0, Le$3;->a:Landroid/app/Activity;

    invoke-direct {v1, p0, v2}, Le$3$1;-><init>(Le$3;Landroid/app/Activity;)V

    invoke-virtual {v0, v1}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V
    :try_end_36
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_36} :catch_37

    return-void

    :catch_37
    nop

    .line 370
    iget-object v0, p0, Le$3;->a:Landroid/app/Activity;

    if-eqz v0, :cond_46

    .line 371
    new-instance v1, Le$3$2;

    iget-object v2, p0, Le$3;->a:Landroid/app/Activity;

    invoke-direct {v1, p0, v2}, Le$3$2;-><init>(Le$3;Landroid/app/Activity;)V

    invoke-virtual {v0, v1}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    :cond_46
    return-void
.end method
