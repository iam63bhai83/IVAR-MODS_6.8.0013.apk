# classes88.dex

.class Ld$6;
.super Ljava/lang/Object;
.source "FoxSource"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ld;->b(Landroid/app/Activity;Landroid/app/Dialog;Landroid/view/View;Ljava/lang/String;IIIILandroid/content/SharedPreferences;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private final synthetic A:Landroid/widget/ImageView;

.field private final synthetic B:Landroid/widget/ImageView;

.field private final synthetic C:Landroid/widget/ImageView;

.field private final synthetic D:Landroid/widget/ImageView;

.field private final synthetic E:Landroid/view/View;

.field private final synthetic F:Landroid/view/View;

.field private final synthetic G:Landroid/view/View;

.field private final synthetic H:Landroid/view/View;

.field private final synthetic I:Landroid/view/View;

.field private final synthetic J:Landroid/widget/TextView;

.field private final synthetic K:Landroid/widget/TextView;

.field private final synthetic L:Landroid/widget/TextView;

.field private final synthetic M:Landroid/widget/TextView;

.field private final synthetic N:Landroid/widget/TextView;

.field private final synthetic O:Landroid/widget/TextView;

.field private final synthetic P:Landroid/widget/TextView;

.field private final synthetic Q:Landroid/widget/TextView;

.field private final synthetic R:Landroid/widget/TextView;

.field private final synthetic S:Landroid/widget/TextView;

.field private final synthetic T:Landroid/widget/TextView;

.field private final synthetic U:Landroid/view/View;

.field private final synthetic V:Landroid/view/View;

.field private final synthetic W:Landroid/widget/TextView;

.field private final synthetic X:Landroid/widget/TextView;

.field private final synthetic Y:Landroid/widget/Button;

.field private final synthetic a:[Z

.field private final synthetic b:[Z

.field private final synthetic c:Landroid/view/View;

.field private final synthetic d:Landroid/view/View;

.field private final synthetic e:Landroid/app/Activity;

.field private final synthetic f:Landroid/widget/TextView;

.field private final synthetic g:Landroid/widget/TextView;

.field private final synthetic h:Landroid/view/View;

.field private final synthetic i:Landroid/view/View;

.field private final synthetic j:Landroid/view/View;

.field private final synthetic k:Landroid/view/View;

.field private final synthetic l:Landroid/view/View;

.field private final synthetic m:Landroid/widget/TextView;

.field private final synthetic n:Landroid/view/View;

.field private final synthetic o:Landroid/widget/TextView;

.field private final synthetic p:Landroid/widget/TextView;

.field private final synthetic q:Landroid/widget/TextView;

.field private final synthetic r:Landroid/view/View;

.field private final synthetic s:Landroid/widget/TextView;

.field private final synthetic t:Landroid/widget/TextView;

.field private final synthetic u:Landroid/content/SharedPreferences;

.field private final synthetic v:Landroid/widget/TextView;

.field private final synthetic w:Landroid/widget/TextView;

.field private final synthetic x:Landroid/widget/TextView;

.field private final synthetic y:Landroid/widget/TextView;

.field private final synthetic z:Landroid/widget/ImageView;


# direct methods
.method constructor <init>([Z[ZLandroid/view/View;Landroid/view/View;Landroid/app/Activity;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/view/View;Landroid/view/View;Landroid/view/View;Landroid/view/View;Landroid/view/View;Landroid/widget/TextView;Landroid/view/View;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/view/View;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/content/SharedPreferences;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/view/View;Landroid/view/View;Landroid/view/View;Landroid/view/View;Landroid/view/View;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/view/View;Landroid/view/View;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/Button;)V
    .registers 52

    .line 2095
    iput-object p1, p0, Ld$6;->a:[Z

    iput-object p2, p0, Ld$6;->b:[Z

    iput-object p3, p0, Ld$6;->c:Landroid/view/View;

    iput-object p4, p0, Ld$6;->d:Landroid/view/View;

    iput-object p5, p0, Ld$6;->e:Landroid/app/Activity;

    iput-object p6, p0, Ld$6;->f:Landroid/widget/TextView;

    iput-object p7, p0, Ld$6;->g:Landroid/widget/TextView;

    iput-object p8, p0, Ld$6;->h:Landroid/view/View;

    iput-object p9, p0, Ld$6;->i:Landroid/view/View;

    iput-object p10, p0, Ld$6;->j:Landroid/view/View;

    iput-object p11, p0, Ld$6;->k:Landroid/view/View;

    iput-object p12, p0, Ld$6;->l:Landroid/view/View;

    iput-object p13, p0, Ld$6;->m:Landroid/widget/TextView;

    iput-object p14, p0, Ld$6;->n:Landroid/view/View;

    iput-object p15, p0, Ld$6;->o:Landroid/widget/TextView;

    move-object/from16 p1, p16

    iput-object p1, p0, Ld$6;->p:Landroid/widget/TextView;

    move-object/from16 p1, p17

    iput-object p1, p0, Ld$6;->q:Landroid/widget/TextView;

    move-object/from16 p1, p18

    iput-object p1, p0, Ld$6;->r:Landroid/view/View;

    move-object/from16 p1, p19

    iput-object p1, p0, Ld$6;->s:Landroid/widget/TextView;

    move-object/from16 p1, p20

    iput-object p1, p0, Ld$6;->t:Landroid/widget/TextView;

    move-object/from16 p1, p21

    iput-object p1, p0, Ld$6;->u:Landroid/content/SharedPreferences;

    move-object/from16 p1, p22

    iput-object p1, p0, Ld$6;->v:Landroid/widget/TextView;

    move-object/from16 p1, p23

    iput-object p1, p0, Ld$6;->w:Landroid/widget/TextView;

    move-object/from16 p1, p24

    iput-object p1, p0, Ld$6;->x:Landroid/widget/TextView;

    move-object/from16 p1, p25

    iput-object p1, p0, Ld$6;->y:Landroid/widget/TextView;

    move-object/from16 p1, p26

    iput-object p1, p0, Ld$6;->z:Landroid/widget/ImageView;

    move-object/from16 p1, p27

    iput-object p1, p0, Ld$6;->A:Landroid/widget/ImageView;

    move-object/from16 p1, p28

    iput-object p1, p0, Ld$6;->B:Landroid/widget/ImageView;

    move-object/from16 p1, p29

    iput-object p1, p0, Ld$6;->C:Landroid/widget/ImageView;

    move-object/from16 p1, p30

    iput-object p1, p0, Ld$6;->D:Landroid/widget/ImageView;

    move-object/from16 p1, p31

    iput-object p1, p0, Ld$6;->E:Landroid/view/View;

    move-object/from16 p1, p32

    iput-object p1, p0, Ld$6;->F:Landroid/view/View;

    move-object/from16 p1, p33

    iput-object p1, p0, Ld$6;->G:Landroid/view/View;

    move-object/from16 p1, p34

    iput-object p1, p0, Ld$6;->H:Landroid/view/View;

    move-object/from16 p1, p35

    iput-object p1, p0, Ld$6;->I:Landroid/view/View;

    move-object/from16 p1, p36

    iput-object p1, p0, Ld$6;->J:Landroid/widget/TextView;

    move-object/from16 p1, p37

    iput-object p1, p0, Ld$6;->K:Landroid/widget/TextView;

    move-object/from16 p1, p38

    iput-object p1, p0, Ld$6;->L:Landroid/widget/TextView;

    move-object/from16 p1, p39

    iput-object p1, p0, Ld$6;->M:Landroid/widget/TextView;

    move-object/from16 p1, p40

    iput-object p1, p0, Ld$6;->N:Landroid/widget/TextView;

    move-object/from16 p1, p41

    iput-object p1, p0, Ld$6;->O:Landroid/widget/TextView;

    move-object/from16 p1, p42

    iput-object p1, p0, Ld$6;->P:Landroid/widget/TextView;

    move-object/from16 p1, p43

    iput-object p1, p0, Ld$6;->Q:Landroid/widget/TextView;

    move-object/from16 p1, p44

    iput-object p1, p0, Ld$6;->R:Landroid/widget/TextView;

    move-object/from16 p1, p45

    iput-object p1, p0, Ld$6;->S:Landroid/widget/TextView;

    move-object/from16 p1, p46

    iput-object p1, p0, Ld$6;->T:Landroid/widget/TextView;

    move-object/from16 p1, p47

    iput-object p1, p0, Ld$6;->U:Landroid/view/View;

    move-object/from16 p1, p48

    iput-object p1, p0, Ld$6;->V:Landroid/view/View;

    move-object/from16 p1, p49

    iput-object p1, p0, Ld$6;->W:Landroid/widget/TextView;

    move-object/from16 p1, p50

    iput-object p1, p0, Ld$6;->X:Landroid/widget/TextView;

    move-object/from16 p1, p51

    iput-object p1, p0, Ld$6;->Y:Landroid/widget/Button;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 29

    move-object/from16 v0, p0

    .line 2098
    const-string v1, ""

    iget-object v2, v0, Ld$6;->a:[Z

    const/4 v3, 0x0

    aget-boolean v2, v2, v3

    .line 2099
    iget-object v4, v0, Ld$6;->b:[Z

    aget-boolean v4, v4, v3

    .line 2101
    const-string v5, "dmN+GwgQFQ=="

    const-string v6, "dmR+FAkXZg=="

    if-eqz v2, :cond_18

    invoke-static {v5}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    goto :goto_1c

    :cond_18
    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    :goto_1c
    invoke-static {v7}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v7

    if-eqz v2, :cond_25

    .line 2102
    const-string v8, "dmB1HgAWFQ=="

    goto :goto_27

    :cond_25
    const-string v8, "dmQDGgxsZA=="

    :goto_27
    invoke-static {v8}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v8

    if-eqz v2, :cond_34

    .line 2103
    const-string v9, "dm11HgsQFQ=="

    goto :goto_36

    :cond_34
    const-string v9, "dmRwbw4RYA=="

    :goto_36
    invoke-static {v9}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v9

    if-eqz v2, :cond_43

    .line 2104
    const-string v10, "dhIHaw0TEg=="

    goto :goto_45

    :cond_43
    const-string v10, "dhJ2a3wTFQ=="

    :goto_45
    invoke-static {v10}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 2105
    const-string v10, "dhcFa3oTZQ=="

    if-eqz v2, :cond_57

    const-string v11, "dhACaQ4TEQ=="

    invoke-static {v11}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    goto :goto_5b

    :cond_57
    invoke-static {v10}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    :goto_5b
    invoke-static {v11}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 2106
    const-string v11, "dhECaAETEQ=="

    if-eqz v2, :cond_67

    invoke-static {v11}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    goto :goto_6b

    :cond_67
    invoke-static {v10}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    :goto_6b
    invoke-static {v12}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v12

    if-eqz v2, :cond_74

    .line 2107
    const-string v13, "dhJ1awgTEg=="

    goto :goto_76

    :cond_74
    const-string v13, "dhF2awoTEQ=="

    :goto_76
    invoke-static {v13}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-static {v13}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v13

    .line 2109
    iget-object v14, v0, Ld$6;->c:Landroid/view/View;

    const-string v15, "dmJyGgxtFg=="

    if-eqz v14, :cond_103

    iget-object v14, v0, Ld$6;->d:Landroid/view/View;

    if-eqz v14, :cond_103

    .line 2110
    iget-object v14, v0, Ld$6;->e:Landroid/app/Activity;

    const/16 v3, 0x8

    invoke-static {v14, v3}, Ld;->a(Landroid/content/Context;I)I

    move-result v14

    iget-object v3, v0, Ld$6;->e:Landroid/app/Activity;

    move/from16 v18, v2

    const/high16 v2, 0x3fc00000  # 1.5f

    invoke-static {v3, v2}, Ld;->a(Landroid/content/Context;F)I

    move-result v2

    const/4 v3, -0x1

    invoke-static {v3, v14, v2, v7}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    if-eqz v18, :cond_d2

    .line 2112
    iget-object v3, v0, Ld$6;->d:Landroid/view/View;

    invoke-virtual {v3, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2113
    iget-object v2, v0, Ld$6;->c:Landroid/view/View;

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Landroid/view/View;->setBackgroundColor(I)V

    .line 2114
    iget-object v2, v0, Ld$6;->f:Landroid/widget/TextView;

    if-eqz v2, :cond_bb

    invoke-virtual {v2, v7}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v2, v0, Ld$6;->f:Landroid/widget/TextView;

    const/4 v3, 0x1

    const/4 v14, 0x0

    invoke-virtual {v2, v14, v3}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    goto :goto_bc

    :cond_bb
    const/4 v14, 0x0

    .line 2115
    :goto_bc
    iget-object v2, v0, Ld$6;->g:Landroid/widget/TextView;

    if-eqz v2, :cond_105

    invoke-static {v15}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v2, v0, Ld$6;->g:Landroid/widget/TextView;

    const/4 v3, 0x0

    invoke-virtual {v2, v14, v3}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    goto :goto_105

    :cond_d2
    const/4 v3, 0x0

    .line 2117
    iget-object v14, v0, Ld$6;->c:Landroid/view/View;

    invoke-virtual {v14, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2118
    iget-object v2, v0, Ld$6;->d:Landroid/view/View;

    invoke-virtual {v2, v3}, Landroid/view/View;->setBackgroundColor(I)V

    .line 2119
    iget-object v2, v0, Ld$6;->g:Landroid/widget/TextView;

    if-eqz v2, :cond_ec

    invoke-virtual {v2, v7}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v2, v0, Ld$6;->g:Landroid/widget/TextView;

    const/4 v3, 0x1

    const/4 v14, 0x0

    invoke-virtual {v2, v14, v3}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    goto :goto_ed

    :cond_ec
    const/4 v14, 0x0

    .line 2120
    :goto_ed
    iget-object v2, v0, Ld$6;->f:Landroid/widget/TextView;

    if-eqz v2, :cond_105

    invoke-static {v15}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v2, v0, Ld$6;->f:Landroid/widget/TextView;

    const/4 v3, 0x0

    invoke-virtual {v2, v14, v3}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    goto :goto_105

    :cond_103
    move/from16 v18, v2

    .line 2124
    :cond_105
    :goto_105
    iget-object v2, v0, Ld$6;->h:Landroid/view/View;

    const-string v3, "dhF0aAATZA=="

    const/16 v14, 0x16

    move-object/from16 v19, v3

    if-eqz v2, :cond_137

    .line 2125
    iget-object v3, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v3, v14}, Ld;->a(Landroid/content/Context;I)I

    move-result v3

    iget-object v14, v0, Ld$6;->e:Landroid/app/Activity;

    move/from16 v21, v4

    const/4 v4, 0x1

    invoke-static {v14, v4}, Ld;->a(Landroid/content/Context;I)I

    move-result v14

    invoke-static/range {v19 .. v19}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v17

    invoke-static/range {v17 .. v17}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    move-object/from16 v23, v5

    const/4 v5, -0x1

    invoke-static {v5, v3, v14, v4}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2127
    iget-object v2, v0, Ld$6;->h:Landroid/view/View;

    const/4 v3, 0x1

    invoke-virtual {v2, v3}, Landroid/view/View;->setClipToOutline(Z)V

    goto :goto_13b

    :cond_137
    move/from16 v21, v4

    move-object/from16 v23, v5

    .line 2131
    :goto_13b
    iget-object v2, v0, Ld$6;->i:Landroid/view/View;

    const-string v5, "dmQAHA9nFQ=="

    if-eqz v2, :cond_1fa

    if-eqz v18, :cond_17b

    .line 2134
    new-instance v2, Landroid/graphics/drawable/GradientDrawable;

    .line 2135
    sget-object v14, Landroid/graphics/drawable/GradientDrawable$Orientation;->TL_BR:Landroid/graphics/drawable/GradientDrawable$Orientation;

    .line 2136
    invoke-static {v5}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v22

    const/16 v24, 0x6

    invoke-static/range {v22 .. v22}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    const-string v22, "dmd3H31tZQ=="

    invoke-static/range {v22 .. v22}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v22

    const/16 v25, 0x7

    invoke-static/range {v22 .. v22}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    const-string v22, "dmJ1Gw4TZQ=="

    invoke-static/range {v22 .. v22}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v22

    move-object/from16 v26, v5

    invoke-static/range {v22 .. v22}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    invoke-static/range {v23 .. v23}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v22

    move-object/from16 v27, v6

    invoke-static/range {v22 .. v22}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    filled-new-array {v4, v3, v5, v6}, [I

    move-result-object v3

    .line 2134
    invoke-direct {v2, v14, v3}, Landroid/graphics/drawable/GradientDrawable;-><init>(Landroid/graphics/drawable/GradientDrawable$Orientation;[I)V

    goto :goto_1b4

    :cond_17b
    move-object/from16 v26, v5

    move-object/from16 v27, v6

    const/16 v24, 0x6

    const/16 v25, 0x7

    .line 2139
    new-instance v2, Landroid/graphics/drawable/GradientDrawable;

    .line 2140
    sget-object v3, Landroid/graphics/drawable/GradientDrawable$Orientation;->TL_BR:Landroid/graphics/drawable/GradientDrawable$Orientation;

    .line 2141
    invoke-static/range {v27 .. v27}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    const-string v5, "dmRwbw4RYA=="

    invoke-static {v5}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    const-string v6, "dmd+b3wTbA=="

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    const-string v14, "dhYHaA4TEA=="

    invoke-static {v14}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-static {v14}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v14

    filled-new-array {v4, v5, v6, v14}, [I

    move-result-object v4

    .line 2139
    invoke-direct {v2, v3, v4}, Landroid/graphics/drawable/GradientDrawable;-><init>(Landroid/graphics/drawable/GradientDrawable$Orientation;[I)V

    .line 2144
    :goto_1b4
    iget-object v3, v0, Ld$6;->e:Landroid/app/Activity;

    const/16 v4, 0x16

    invoke-static {v3, v4}, Ld;->a(Landroid/content/Context;I)I

    move-result v3

    int-to-float v3, v3

    iget-object v5, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v5, v4}, Ld;->a(Landroid/content/Context;I)I

    move-result v5

    int-to-float v5, v5

    iget-object v6, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v6, v4}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    int-to-float v6, v6

    iget-object v14, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v14, v4}, Ld;->a(Landroid/content/Context;I)I

    move-result v4

    int-to-float v4, v4

    move/from16 v20, v3

    const/16 v14, 0x8

    new-array v3, v14, [F

    const/16 v16, 0x0

    aput v20, v3, v16

    const/16 v17, 0x1

    aput v5, v3, v17

    const/4 v5, 0x2

    aput v6, v3, v5

    const/4 v5, 0x3

    aput v4, v3, v5

    const/4 v4, 0x4

    const/4 v5, 0x0

    aput v5, v3, v4

    const/4 v4, 0x5

    aput v5, v3, v4

    aput v5, v3, v24

    aput v5, v3, v25

    invoke-virtual {v2, v3}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadii([F)V

    .line 2145
    iget-object v3, v0, Ld$6;->i:Landroid/view/View;

    invoke-virtual {v3, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    goto :goto_202

    :cond_1fa
    move-object/from16 v26, v5

    move-object/from16 v27, v6

    const/16 v24, 0x6

    const/16 v25, 0x7

    .line 2148
    :goto_202
    iget-object v2, v0, Ld$6;->j:Landroid/view/View;

    if-eqz v2, :cond_228

    .line 2149
    new-instance v2, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v2}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const/4 v3, 0x1

    .line 2150
    invoke-virtual {v2, v3}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    const/4 v5, -0x1

    .line 2151
    invoke-virtual {v2, v5}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 2152
    iget-object v4, v0, Ld$6;->e:Landroid/app/Activity;

    const/high16 v5, 0x40200000  # 2.5f

    invoke-static {v4, v5}, Ld;->a(Landroid/content/Context;F)I

    move-result v4

    invoke-virtual {v2, v4, v7}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 2153
    iget-object v4, v0, Ld$6;->j:Landroid/view/View;

    invoke-virtual {v4, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2155
    iget-object v2, v0, Ld$6;->j:Landroid/view/View;

    invoke-virtual {v2, v3}, Landroid/view/View;->setClipToOutline(Z)V

    .line 2161
    :cond_228
    :try_start_228
    iget-object v3, v0, Ld$6;->e:Landroid/app/Activity;

    const-string v4, "MiQ="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x0

    invoke-virtual {v3, v4, v5}, Landroid/app/Activity;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v3

    if-eqz v3, :cond_242

    .line 2162
    const-string v4, "JSYpS1E5MQ=="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-interface {v3, v4, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    goto :goto_243

    :cond_242
    move-object v3, v1

    :goto_243
    if-eqz v3, :cond_27e

    .line 2163
    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_27e

    iget-object v4, v0, Ld$6;->k:Landroid/view/View;

    instance-of v5, v4, Landroid/widget/ImageView;

    if-eqz v5, :cond_27e

    .line 2164
    check-cast v4, Landroid/widget/ImageView;

    .line 2165
    sget-object v5, Landroid/widget/ImageView$ScaleType;->CENTER_CROP:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v4, v5}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    const/4 v5, 0x0

    .line 2166
    invoke-virtual {v4, v5, v5, v5, v5}, Landroid/widget/ImageView;->setPadding(IIII)V

    .line 2167
    iget-object v5, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-virtual {v5}, Landroid/app/Activity;->getApplicationContext()Landroid/content/Context;

    move-result-object v5

    invoke-static {v5}, Lcom/bumptech/glide/Glide;->with(Landroid/content/Context;)Lcom/bumptech/glide/RequestManager;

    move-result-object v5

    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v3

    invoke-virtual {v5, v3}, Lcom/bumptech/glide/RequestManager;->load(Landroid/net/Uri;)Lcom/bumptech/glide/RequestBuilder;

    move-result-object v3

    invoke-virtual {v3, v4}, Lcom/bumptech/glide/RequestBuilder;->into(Landroid/widget/ImageView;)Lcom/bumptech/glide/request/target/ViewTarget;
    :try_end_279
    .catchall {:try_start_228 .. :try_end_279} :catchall_27d

    :cond_279
    :goto_279
    const/16 v5, 0x1a

    goto/16 :goto_31d

    :catchall_27d
    nop

    .line 2173
    :cond_27e
    iget-object v3, v0, Ld$6;->k:Landroid/view/View;

    instance-of v4, v3, Landroid/widget/ImageView;

    if-eqz v4, :cond_2db

    .line 2174
    check-cast v3, Landroid/widget/ImageView;

    .line 2175
    sget-object v4, Landroid/widget/ImageView$ScaleType;->CENTER_INSIDE:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v3, v4}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    .line 2176
    iget-object v4, v0, Ld$6;->e:Landroid/app/Activity;

    const/16 v14, 0x8

    invoke-static {v4, v14}, Ld;->a(Landroid/content/Context;I)I

    move-result v4

    iget-object v5, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v5, v14}, Ld;->a(Landroid/content/Context;I)I

    move-result v5

    iget-object v6, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v6, v14}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    iget-object v2, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v2, v14}, Ld;->a(Landroid/content/Context;I)I

    move-result v2

    invoke-virtual {v3, v4, v5, v6, v2}, Landroid/widget/ImageView;->setPadding(IIII)V

    if-eqz v18, :cond_2c7

    .line 2178
    iget-object v2, v0, Ld$6;->e:Landroid/app/Activity;

    const-string v4, "dhJzFH1lFg=="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    const-string v5, "dhIDawhtFQ=="

    invoke-static {v5}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    const/16 v6, 0x1c

    invoke-static {v2, v6, v4, v5}, Ld;->a(Landroid/content/Context;III)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    goto :goto_2d7

    .line 2179
    :cond_2c7
    iget-object v2, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static/range {v27 .. v27}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    const/16 v5, 0x1a

    invoke-static {v2, v5, v4}, Ld;->a(Landroid/content/Context;II)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    .line 2177
    :goto_2d7
    invoke-virtual {v3, v2}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    goto :goto_279

    .line 2180
    :cond_2db
    instance-of v2, v3, Landroid/widget/TextView;

    if-eqz v2, :cond_279

    .line 2181
    check-cast v3, Landroid/widget/TextView;

    invoke-virtual {v3, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2182
    iget-object v2, v0, Ld$6;->k:Landroid/view/View;

    check-cast v2, Landroid/widget/TextView;

    if-eqz v18, :cond_309

    .line 2183
    iget-object v3, v0, Ld$6;->e:Landroid/app/Activity;

    const-string v4, "dhJzFH1lFg=="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    const-string v5, "dhIDawhtFQ=="

    invoke-static {v5}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    const/16 v6, 0x1c

    invoke-static {v3, v6, v4, v5}, Ld;->a(Landroid/content/Context;III)Landroid/graphics/drawable/Drawable;

    move-result-object v3

    const/16 v5, 0x1a

    goto :goto_319

    .line 2184
    :cond_309
    iget-object v3, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static/range {v27 .. v27}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    const/16 v5, 0x1a

    invoke-static {v3, v5, v4}, Ld;->a(Landroid/content/Context;II)Landroid/graphics/drawable/Drawable;

    move-result-object v3

    :goto_319
    const/4 v14, 0x0

    .line 2182
    invoke-virtual {v2, v3, v14, v14, v14}, Landroid/widget/TextView;->setCompoundDrawablesWithIntrinsicBounds(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 2188
    :goto_31d
    iget-object v2, v0, Ld$6;->l:Landroid/view/View;

    instance-of v3, v2, Landroid/widget/ImageView;

    const/16 v4, 0x10

    if-eqz v3, :cond_332

    .line 2189
    check-cast v2, Landroid/widget/ImageView;

    iget-object v3, v0, Ld$6;->e:Landroid/app/Activity;

    const/4 v6, -0x1

    invoke-static {v3, v4, v7, v6}, Ld;->b(Landroid/content/Context;III)Landroid/graphics/drawable/Drawable;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    goto :goto_34a

    :cond_332
    const/4 v6, -0x1

    .line 2190
    instance-of v3, v2, Landroid/widget/TextView;

    if-eqz v3, :cond_34a

    .line 2191
    check-cast v2, Landroid/widget/TextView;

    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2192
    iget-object v2, v0, Ld$6;->l:Landroid/view/View;

    check-cast v2, Landroid/widget/TextView;

    iget-object v3, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v3, v4, v7, v6}, Ld;->b(Landroid/content/Context;III)Landroid/graphics/drawable/Drawable;

    move-result-object v3

    const/4 v14, 0x0

    invoke-virtual {v2, v3, v14, v14, v14}, Landroid/widget/TextView;->setCompoundDrawablesWithIntrinsicBounds(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 2195
    :cond_34a
    :goto_34a
    iget-object v2, v0, Ld$6;->m:Landroid/widget/TextView;

    if-eqz v2, :cond_36b

    if-eqz v18, :cond_353

    .line 2196
    const-string v3, "bWFjBhgZPTBI"

    goto :goto_355

    :cond_353
    const-string v3, "FDcyRE4w"

    :goto_355
    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2197
    iget-object v2, v0, Ld$6;->m:Landroid/widget/TextView;

    const-string v3, "dmV2bwFtZQ=="

    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setTextColor(I)V

    .line 2200
    :cond_36b
    iget-object v2, v0, Ld$6;->n:Landroid/view/View;

    if-eqz v2, :cond_38a

    .line 2201
    new-instance v2, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v2}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const/4 v3, 0x1

    .line 2202
    invoke-virtual {v2, v3}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    .line 2203
    const-string v3, "dmV2bwFtZQ=="

    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 2204
    iget-object v3, v0, Ld$6;->n:Landroid/view/View;

    invoke-virtual {v3, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2207
    :cond_38a
    iget-object v2, v0, Ld$6;->o:Landroid/widget/TextView;

    if-eqz v2, :cond_39c

    if-eqz v18, :cond_393

    const-string v3, "BSYpDW4cBA=="

    goto :goto_395

    :cond_393
    const-string v3, "FzU1RFt1Ag99"

    :goto_395
    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2208
    :cond_39c
    iget-object v2, v0, Ld$6;->p:Landroid/widget/TextView;

    if-eqz v2, :cond_3b2

    if-eqz v18, :cond_3a9

    .line 2210
    const-string v3, "FDgqDV07My9DXSZ4ZkVRMjxmWlE7JidZXXVyZktUOjUyRFYydA54fA=="

    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    goto :goto_3af

    .line 2211
    :cond_3a9
    const-string v3, "ADoqRFU8ICNJGCUmI0lRNiAvQlYmdGANeRx0NVlKNCAjSkF1Ny5MTA=="

    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 2209
    :goto_3af
    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2213
    :cond_3b2
    iget-object v2, v0, Ld$6;->q:Landroid/widget/TextView;

    if-eqz v2, :cond_3db

    if-eqz v18, :cond_3bb

    .line 2214
    const-string v3, "ABoKYnseEQI="

    goto :goto_3bd

    :cond_3bb
    const-string v3, "ABoKZHUcAANp"

    :goto_3bd
    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2215
    iget-object v2, v0, Ld$6;->q:Landroid/widget/TextView;

    invoke-virtual {v2, v7}, Landroid/widget/TextView;->setTextColor(I)V

    .line 2216
    iget-object v2, v0, Ld$6;->q:Landroid/widget/TextView;

    iget-object v3, v0, Ld$6;->e:Landroid/app/Activity;

    const/16 v14, 0x8

    invoke-static {v3, v14}, Ld;->a(Landroid/content/Context;I)I

    move-result v3

    const/4 v6, 0x0

    invoke-static {v12, v3, v6, v6}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2219
    :cond_3db
    iget-object v2, v0, Ld$6;->r:Landroid/view/View;

    if-eqz v2, :cond_407

    .line 2220
    const-string v3, "dhJ+a3kTFw=="

    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    iget-object v6, v0, Ld$6;->e:Landroid/app/Activity;

    const/16 v12, 0xc

    invoke-static {v6, v12}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    iget-object v12, v0, Ld$6;->e:Landroid/app/Activity;

    const/4 v14, 0x1

    invoke-static {v12, v14}, Ld;->a(Landroid/content/Context;I)I

    move-result v12

    invoke-static/range {v19 .. v19}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-static {v14}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v14

    invoke-static {v3, v6, v12, v14}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2223
    :cond_407
    iget-object v2, v0, Ld$6;->s:Landroid/widget/TextView;

    if-eqz v2, :cond_419

    if-eqz v18, :cond_410

    const-string v3, "bWFjBg=="

    goto :goto_412

    :cond_410
    const-string v3, "ADoqRFU="

    :goto_412
    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2224
    :cond_419
    iget-object v2, v0, Ld$6;->t:Landroid/widget/TextView;

    if-eqz v2, :cond_42b

    if-eqz v18, :cond_422

    const-string v3, "NDclWEo0Nz8="

    goto :goto_424

    :cond_422
    const-string v3, "Jj0hQ1k5Jw=="

    :goto_424
    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2226
    :cond_42b
    const-string v3, "t9b/HwFs"

    if-eqz v21, :cond_45b

    iget-object v6, v0, Ld$6;->u:Landroid/content/SharedPreferences;

    if-eqz v18, :cond_43e

    const-string v12, "JSYpck8wMS1BQQokNERbMAspS14wJg=="

    invoke-static {v12}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    goto :goto_44a

    :cond_43e
    const-string v12, "NzU1RFsKIyNIUzktGV1KPDcjclczMiNf"

    invoke-static {v12}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    const-string v14, "t9b/FAE="

    invoke-static {v14}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    :goto_44a
    invoke-interface {v6, v12, v14}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    if-eqz v18, :cond_453

    const/16 v12, 0x2a

    goto :goto_455

    :cond_453
    const/16 v12, 0xe

    :goto_455
    const/4 v14, 0x7

    invoke-static {v6, v14, v12}, Ld;->a(Ljava/lang/String;II)I

    move-result v6

    goto :goto_4a5

    :cond_45b
    if-eqz v18, :cond_47c

    iget-object v6, v0, Ld$6;->u:Landroid/content/SharedPreferences;

    const-string v12, "JSYpclU6OjJFVCwLNl9RNjEZQl4zMTQ="

    invoke-static {v12}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    iget-object v14, v0, Ld$6;->u:Landroid/content/SharedPreferences;

    const-string v20, "JSYpckgnPSVIZzoyIEhK"

    invoke-static/range {v20 .. v20}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v20, "t9b/GgFs"

    invoke-static/range {v20 .. v20}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-interface {v14, v5, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-interface {v6, v12, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    goto :goto_498

    :cond_47c
    iget-object v4, v0, Ld$6;->u:Landroid/content/SharedPreferences;

    const-string v5, "NzU1RFsKOSlDTD04P3JIJz0lSGc6MiBISg=="

    invoke-static {v5}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    iget-object v6, v0, Ld$6;->u:Landroid/content/SharedPreferences;

    const-string v12, "NzU1RFsKJDREWzALKUteMCY="

    invoke-static {v12}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-interface {v6, v12, v14}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-interface {v4, v5, v6}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    :goto_498
    if-eqz v18, :cond_49d

    const/16 v5, 0x1a

    goto :goto_49f

    :cond_49d
    const/16 v5, 0x9

    :goto_49f
    const/16 v6, 0x1e

    invoke-static {v4, v6, v5}, Ld;->a(Ljava/lang/String;II)I

    move-result v6

    .line 2227
    :goto_4a5
    iget-object v4, v0, Ld$6;->u:Landroid/content/SharedPreferences;

    if-eqz v18, :cond_4b6

    const-string v5, "JSYpclU6OjJFVCwLNl9RNjEZQl4zMTQ="

    invoke-static {v5}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v12, "t9b/GgFs"

    invoke-static {v12}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    goto :goto_4c0

    :cond_4b6
    const-string v5, "NzU1RFsKOSlDTD04P3JIJz0lSGc6MiBISg=="

    invoke-static {v5}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    :goto_4c0
    invoke-interface {v4, v5, v12}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ld;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 2228
    iget-object v5, v0, Ld$6;->v:Landroid/widget/TextView;

    if-eqz v5, :cond_4ed

    .line 2229
    new-instance v12, Ljava/lang/StringBuilder;

    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v12, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v12, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v4, "ejAnVA=="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v12, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v5, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2230
    iget-object v4, v0, Ld$6;->v:Landroid/widget/TextView;

    invoke-virtual {v4, v7}, Landroid/widget/TextView;->setTextColor(I)V

    .line 2232
    :cond_4ed
    iget-object v4, v0, Ld$6;->w:Landroid/widget/TextView;

    if-eqz v4, :cond_4fa

    const-string v5, "MTUvQUF1NyleTA=="

    invoke-static {v5}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2234
    :cond_4fa
    iget-object v4, v0, Ld$6;->x:Landroid/widget/TextView;

    if-eqz v4, :cond_51b

    if-eqz v18, :cond_503

    .line 2235
    const-string v5, "YGRjDXcTEg=="

    goto :goto_505

    :cond_503
    const-string v5, "YWRjDXcTEg=="

    :goto_505
    invoke-static {v5}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2236
    iget-object v4, v0, Ld$6;->x:Landroid/widget/TextView;

    const-string v5, "dmV2bwFtZQ=="

    invoke-static {v5}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setTextColor(I)V

    .line 2238
    :cond_51b
    iget-object v4, v0, Ld$6;->y:Landroid/widget/TextView;

    if-eqz v4, :cond_528

    const-string v5, "JjUwRFYyJw=="

    invoke-static {v5}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2240
    :cond_528
    iget-object v4, v0, Ld$6;->e:Landroid/app/Activity;

    const/16 v5, 0xa

    invoke-static {v4, v5}, Ld;->a(Landroid/content/Context;I)I

    move-result v4

    iget-object v6, v0, Ld$6;->e:Landroid/app/Activity;

    const/4 v14, 0x1

    invoke-static {v6, v14}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    if-eqz v18, :cond_53e

    invoke-static {v11}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    goto :goto_542

    :cond_53e
    invoke-static {v10}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    :goto_542
    invoke-static {v12}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v12

    const/4 v14, -0x1

    invoke-static {v14, v4, v6, v12}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v4

    .line 2241
    const-string v6, "dhJ+a3kTFw=="

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    iget-object v12, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v12, v5}, Ld;->a(Landroid/content/Context;I)I

    move-result v12

    iget-object v14, v0, Ld$6;->e:Landroid/app/Activity;

    const/4 v2, 0x1

    invoke-static {v14, v2}, Ld;->a(Landroid/content/Context;I)I

    move-result v14

    invoke-static/range {v19 .. v19}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-static {v6, v12, v14, v2}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    if-eqz v18, :cond_70b

    .line 2244
    iget-object v2, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v11}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    invoke-static/range {v23 .. v23}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v10

    const/16 v11, 0x14

    invoke-static {v2, v11, v6, v10}, Ld;->c(Landroid/content/Context;III)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    .line 2245
    iget-object v6, v0, Ld$6;->z:Landroid/widget/ImageView;

    if-eqz v6, :cond_58f

    invoke-virtual {v6, v2}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 2246
    :cond_58f
    iget-object v6, v0, Ld$6;->A:Landroid/widget/ImageView;

    if-eqz v6, :cond_596

    invoke-virtual {v6, v2}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 2247
    :cond_596
    iget-object v6, v0, Ld$6;->B:Landroid/widget/ImageView;

    if-eqz v6, :cond_59d

    invoke-virtual {v6, v2}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 2248
    :cond_59d
    iget-object v6, v0, Ld$6;->C:Landroid/widget/ImageView;

    if-eqz v6, :cond_5a4

    invoke-virtual {v6, v2}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 2249
    :cond_5a4
    iget-object v6, v0, Ld$6;->D:Landroid/widget/ImageView;

    if-eqz v6, :cond_5ab

    invoke-virtual {v6, v2}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 2251
    :cond_5ab
    iget-object v2, v0, Ld$6;->E:Landroid/view/View;

    if-eqz v2, :cond_5d2

    invoke-virtual {v2, v4}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    iget-object v2, v0, Ld$6;->E:Landroid/view/View;

    iget-object v6, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v6, v5}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    iget-object v10, v0, Ld$6;->e:Landroid/app/Activity;

    const/16 v14, 0x8

    invoke-static {v10, v14}, Ld;->a(Landroid/content/Context;I)I

    move-result v10

    iget-object v11, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v11, v5}, Ld;->a(Landroid/content/Context;I)I

    move-result v11

    iget-object v12, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v12, v14}, Ld;->a(Landroid/content/Context;I)I

    move-result v12

    invoke-virtual {v2, v6, v10, v11, v12}, Landroid/view/View;->setPadding(IIII)V

    goto :goto_5d4

    :cond_5d2
    const/16 v14, 0x8

    .line 2252
    :goto_5d4
    iget-object v2, v0, Ld$6;->F:Landroid/view/View;

    if-eqz v2, :cond_5f8

    invoke-virtual {v2, v4}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    iget-object v2, v0, Ld$6;->F:Landroid/view/View;

    iget-object v6, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v6, v5}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    iget-object v10, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v10, v14}, Ld;->a(Landroid/content/Context;I)I

    move-result v10

    iget-object v11, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v11, v5}, Ld;->a(Landroid/content/Context;I)I

    move-result v11

    iget-object v12, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v12, v14}, Ld;->a(Landroid/content/Context;I)I

    move-result v12

    invoke-virtual {v2, v6, v10, v11, v12}, Landroid/view/View;->setPadding(IIII)V

    .line 2253
    :cond_5f8
    iget-object v2, v0, Ld$6;->G:Landroid/view/View;

    if-eqz v2, :cond_61c

    invoke-virtual {v2, v4}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    iget-object v2, v0, Ld$6;->G:Landroid/view/View;

    iget-object v6, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v6, v5}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    iget-object v10, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v10, v14}, Ld;->a(Landroid/content/Context;I)I

    move-result v10

    iget-object v11, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v11, v5}, Ld;->a(Landroid/content/Context;I)I

    move-result v11

    iget-object v12, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v12, v14}, Ld;->a(Landroid/content/Context;I)I

    move-result v12

    invoke-virtual {v2, v6, v10, v11, v12}, Landroid/view/View;->setPadding(IIII)V

    .line 2254
    :cond_61c
    iget-object v2, v0, Ld$6;->H:Landroid/view/View;

    if-eqz v2, :cond_640

    invoke-virtual {v2, v4}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    iget-object v2, v0, Ld$6;->H:Landroid/view/View;

    iget-object v6, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v6, v5}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    iget-object v10, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v10, v14}, Ld;->a(Landroid/content/Context;I)I

    move-result v10

    iget-object v11, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v11, v5}, Ld;->a(Landroid/content/Context;I)I

    move-result v11

    iget-object v12, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v12, v14}, Ld;->a(Landroid/content/Context;I)I

    move-result v12

    invoke-virtual {v2, v6, v10, v11, v12}, Landroid/view/View;->setPadding(IIII)V

    .line 2255
    :cond_640
    iget-object v2, v0, Ld$6;->I:Landroid/view/View;

    if-eqz v2, :cond_664

    invoke-virtual {v2, v4}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    iget-object v2, v0, Ld$6;->I:Landroid/view/View;

    iget-object v4, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v4, v5}, Ld;->a(Landroid/content/Context;I)I

    move-result v4

    iget-object v6, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v6, v14}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    iget-object v10, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v10, v5}, Ld;->a(Landroid/content/Context;I)I

    move-result v10

    iget-object v11, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v11, v14}, Ld;->a(Landroid/content/Context;I)I

    move-result v11

    invoke-virtual {v2, v4, v6, v10, v11}, Landroid/view/View;->setPadding(IIII)V

    .line 2257
    :cond_664
    iget-object v2, v0, Ld$6;->J:Landroid/widget/TextView;

    if-eqz v2, :cond_685

    const-string v4, "BQYJDXs6OjVIViYhNQ0QbWFjBhgCPShfWSExbw=="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v2, v0, Ld$6;->J:Landroid/widget/TextView;

    invoke-static/range {v26 .. v26}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v2, v0, Ld$6;->J:Landroid/widget/TextView;

    const/4 v4, 0x0

    const/4 v14, 0x1

    invoke-virtual {v2, v4, v14}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 2258
    :cond_685
    iget-object v2, v0, Ld$6;->K:Landroid/widget/TextView;

    if-eqz v2, :cond_6a6

    const-string v4, "EzgpTEw8OiENcTt5AUxVMHQOeHw="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v2, v0, Ld$6;->K:Landroid/widget/TextView;

    invoke-static/range {v26 .. v26}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v2, v0, Ld$6;->K:Landroid/widget/TextView;

    const/4 v4, 0x0

    const/4 v14, 0x1

    invoke-virtual {v2, v4, v14}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 2259
    :cond_6a6
    iget-object v2, v0, Ld$6;->L:Landroid/widget/TextView;

    if-eqz v2, :cond_6c7

    const-string v4, "ADoqRFU8ICNJGBE1L0FBdQQ0SFw8NzJEVzsn"

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v2, v0, Ld$6;->L:Landroid/widget/TextView;

    invoke-static/range {v26 .. v26}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v2, v0, Ld$6;->L:Landroid/widget/TextView;

    const/4 v4, 0x0

    const/4 v14, 0x1

    invoke-virtual {v2, v4, v14}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 2260
    :cond_6c7
    iget-object v2, v0, Ld$6;->M:Landroid/widget/TextView;

    if-eqz v2, :cond_6e8

    const-string v4, "Z2BpGhgUHWZ+TCc1MkhfLHQFRVkh"

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v2, v0, Ld$6;->M:Landroid/widget/TextView;

    invoke-static/range {v26 .. v26}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v2, v0, Ld$6;->M:Landroid/widget/TextView;

    const/4 v4, 0x0

    const/4 v14, 0x1

    invoke-virtual {v2, v4, v14}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 2261
    :cond_6e8
    iget-object v2, v0, Ld$6;->N:Landroid/widget/TextView;

    if-eqz v2, :cond_8cb

    const-string v4, "DzE0QhURMSpMQXUCD30YBjE0W10nJw=="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v2, v0, Ld$6;->N:Landroid/widget/TextView;

    invoke-static/range {v26 .. v26}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v2, v0, Ld$6;->N:Landroid/widget/TextView;

    const/4 v4, 0x0

    const/4 v14, 0x1

    invoke-virtual {v2, v4, v14}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    goto/16 :goto_8cb

    .line 2263
    :cond_70b
    iget-object v6, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v10}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v10

    invoke-static/range {v27 .. v27}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-static {v11}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v11

    const/16 v12, 0x14

    invoke-static {v6, v12, v10, v11}, Ld;->c(Landroid/content/Context;III)Landroid/graphics/drawable/Drawable;

    move-result-object v6

    .line 2264
    iget-object v10, v0, Ld$6;->e:Landroid/app/Activity;

    const-string v11, "dhJ3aw0TbQ=="

    invoke-static {v11}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-static {v11}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v11

    const-string v12, "dm1ybAsXbA=="

    invoke-static {v12}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-static {v12}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v12

    const/16 v14, 0x14

    invoke-static {v10, v14, v11, v12}, Ld;->d(Landroid/content/Context;III)Landroid/graphics/drawable/Drawable;

    move-result-object v10

    .line 2265
    iget-object v11, v0, Ld$6;->z:Landroid/widget/ImageView;

    if-eqz v11, :cond_746

    invoke-virtual {v11, v6}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 2266
    :cond_746
    iget-object v11, v0, Ld$6;->A:Landroid/widget/ImageView;

    if-eqz v11, :cond_74d

    invoke-virtual {v11, v6}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 2267
    :cond_74d
    iget-object v11, v0, Ld$6;->B:Landroid/widget/ImageView;

    if-eqz v11, :cond_754

    invoke-virtual {v11, v6}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 2268
    :cond_754
    iget-object v6, v0, Ld$6;->C:Landroid/widget/ImageView;

    if-eqz v6, :cond_75b

    invoke-virtual {v6, v10}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 2269
    :cond_75b
    iget-object v6, v0, Ld$6;->D:Landroid/widget/ImageView;

    if-eqz v6, :cond_762

    invoke-virtual {v6, v10}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 2271
    :cond_762
    iget-object v6, v0, Ld$6;->E:Landroid/view/View;

    if-eqz v6, :cond_789

    invoke-virtual {v6, v4}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    iget-object v6, v0, Ld$6;->E:Landroid/view/View;

    iget-object v10, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v10, v5}, Ld;->a(Landroid/content/Context;I)I

    move-result v10

    iget-object v11, v0, Ld$6;->e:Landroid/app/Activity;

    const/16 v14, 0x8

    invoke-static {v11, v14}, Ld;->a(Landroid/content/Context;I)I

    move-result v11

    iget-object v12, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v12, v5}, Ld;->a(Landroid/content/Context;I)I

    move-result v12

    iget-object v5, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v5, v14}, Ld;->a(Landroid/content/Context;I)I

    move-result v5

    invoke-virtual {v6, v10, v11, v12, v5}, Landroid/view/View;->setPadding(IIII)V

    goto :goto_78b

    :cond_789
    const/16 v14, 0x8

    .line 2272
    :goto_78b
    iget-object v5, v0, Ld$6;->F:Landroid/view/View;

    if-eqz v5, :cond_7b1

    invoke-virtual {v5, v4}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    iget-object v5, v0, Ld$6;->F:Landroid/view/View;

    iget-object v6, v0, Ld$6;->e:Landroid/app/Activity;

    const/16 v10, 0xa

    invoke-static {v6, v10}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    iget-object v11, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v11, v14}, Ld;->a(Landroid/content/Context;I)I

    move-result v11

    iget-object v12, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v12, v10}, Ld;->a(Landroid/content/Context;I)I

    move-result v12

    iget-object v10, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v10, v14}, Ld;->a(Landroid/content/Context;I)I

    move-result v10

    invoke-virtual {v5, v6, v11, v12, v10}, Landroid/view/View;->setPadding(IIII)V

    .line 2273
    :cond_7b1
    iget-object v5, v0, Ld$6;->G:Landroid/view/View;

    if-eqz v5, :cond_7d8

    invoke-virtual {v5, v4}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    iget-object v4, v0, Ld$6;->G:Landroid/view/View;

    iget-object v5, v0, Ld$6;->e:Landroid/app/Activity;

    const/16 v10, 0xa

    invoke-static {v5, v10}, Ld;->a(Landroid/content/Context;I)I

    move-result v5

    iget-object v6, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v6, v14}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    iget-object v11, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v11, v10}, Ld;->a(Landroid/content/Context;I)I

    move-result v11

    iget-object v12, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v12, v14}, Ld;->a(Landroid/content/Context;I)I

    move-result v12

    invoke-virtual {v4, v5, v6, v11, v12}, Landroid/view/View;->setPadding(IIII)V

    goto :goto_7da

    :cond_7d8
    const/16 v10, 0xa

    .line 2274
    :goto_7da
    iget-object v4, v0, Ld$6;->H:Landroid/view/View;

    if-eqz v4, :cond_7fe

    invoke-virtual {v4, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    iget-object v4, v0, Ld$6;->H:Landroid/view/View;

    iget-object v5, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v5, v10}, Ld;->a(Landroid/content/Context;I)I

    move-result v5

    iget-object v6, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v6, v14}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    iget-object v11, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v11, v10}, Ld;->a(Landroid/content/Context;I)I

    move-result v11

    iget-object v12, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v12, v14}, Ld;->a(Landroid/content/Context;I)I

    move-result v12

    invoke-virtual {v4, v5, v6, v11, v12}, Landroid/view/View;->setPadding(IIII)V

    .line 2275
    :cond_7fe
    iget-object v4, v0, Ld$6;->I:Landroid/view/View;

    if-eqz v4, :cond_822

    invoke-virtual {v4, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    iget-object v2, v0, Ld$6;->I:Landroid/view/View;

    iget-object v4, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v4, v10}, Ld;->a(Landroid/content/Context;I)I

    move-result v4

    iget-object v5, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v5, v14}, Ld;->a(Landroid/content/Context;I)I

    move-result v5

    iget-object v6, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v6, v10}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    iget-object v10, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v10, v14}, Ld;->a(Landroid/content/Context;I)I

    move-result v10

    invoke-virtual {v2, v4, v5, v6, v10}, Landroid/view/View;->setPadding(IIII)V

    .line 2277
    :cond_822
    iget-object v2, v0, Ld$6;->J:Landroid/widget/TextView;

    if-eqz v2, :cond_843

    const-string v4, "ADoqRFU8ICNJGBE1L0FBdQQ0SFw8NzJEVzsn"

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v2, v0, Ld$6;->J:Landroid/widget/TextView;

    invoke-static/range {v26 .. v26}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v2, v0, Ld$6;->J:Landroid/widget/TextView;

    const/4 v4, 0x0

    const/4 v14, 0x1

    invoke-virtual {v2, v4, v14}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 2278
    :cond_843
    iget-object v2, v0, Ld$6;->K:Landroid/widget/TextView;

    if-eqz v2, :cond_864

    const-string v4, "Z2BpGhgUHWZ+TCc1MkhfLHQFRVkh"

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v2, v0, Ld$6;->K:Landroid/widget/TextView;

    invoke-static/range {v26 .. v26}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v2, v0, Ld$6;->K:Landroid/widget/TextView;

    const/4 v4, 0x0

    const/4 v14, 0x1

    invoke-virtual {v2, v4, v14}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 2279
    :cond_864
    iget-object v2, v0, Ld$6;->L:Landroid/widget/TextView;

    if-eqz v2, :cond_885

    const-string v4, "BiAnQ1w0JiINazAmMEhKdQc2SF0x"

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v2, v0, Ld$6;->L:Landroid/widget/TextView;

    invoke-static/range {v26 .. v26}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v2, v0, Ld$6;->L:Landroid/widget/TextView;

    const/4 v4, 0x0

    const/4 v14, 0x1

    invoke-virtual {v2, v4, v14}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 2280
    :cond_885
    iget-object v2, v0, Ld$6;->M:Landroid/widget/TextView;

    if-eqz v2, :cond_8a8

    const-string v4, "BQYJDXs6OjVIViYhNQ0QBSYpDW4cBGZiVjktbw=="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v2, v0, Ld$6;->M:Landroid/widget/TextView;

    const-string v4, "dm1ybAsXbA=="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v2, v0, Ld$6;->M:Landroid/widget/TextView;

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v2, v4, v5}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 2281
    :cond_8a8
    iget-object v2, v0, Ld$6;->N:Landroid/widget/TextView;

    if-eqz v2, :cond_8cb

    const-string v4, "EzgpTEw8OiENcAAQZgVoJztme3EFdAlDVCx9"

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    iget-object v2, v0, Ld$6;->N:Landroid/widget/TextView;

    const-string v4, "dm1ybAsXbA=="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextColor(I)V

    iget-object v2, v0, Ld$6;->N:Landroid/widget/TextView;

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v2, v4, v5}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    :cond_8cb
    :goto_8cb
    if-eqz v18, :cond_8de

    .line 2285
    iget-object v2, v0, Ld$6;->u:Landroid/content/SharedPreferences;

    const-string v4, "JSYpck8wMS1BQQokNERbMAspS14wJg=="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-interface {v2, v4, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    goto :goto_8f0

    .line 2286
    :cond_8de
    iget-object v2, v0, Ld$6;->u:Landroid/content/SharedPreferences;

    const-string v4, "NzU1RFsKIyNIUzktGV1KPDcjclczMiNf"

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const-string v5, "t9b/FAE="

    invoke-static {v5}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-interface {v2, v4, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    :goto_8f0
    if-eqz v18, :cond_911

    .line 2288
    iget-object v3, v0, Ld$6;->u:Landroid/content/SharedPreferences;

    const-string v4, "JSYpclU6OjJFVCwLNl9RNjEZQl4zMTQ="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    iget-object v5, v0, Ld$6;->u:Landroid/content/SharedPreferences;

    const-string v6, "JSYpckgnPSVIZzoyIEhK"

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const-string v10, "t9b/GgFs"

    invoke-static {v10}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-interface {v5, v6, v10}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-interface {v3, v4, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    goto :goto_92d

    .line 2289
    :cond_911
    iget-object v4, v0, Ld$6;->u:Landroid/content/SharedPreferences;

    const-string v5, "NzU1RFsKOSlDTD04P3JIJz0lSGc6MiBISg=="

    invoke-static {v5}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    iget-object v6, v0, Ld$6;->u:Landroid/content/SharedPreferences;

    const-string v10, "NzU1RFsKJDREWzALKUteMCY="

    invoke-static {v10}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v6, v10, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v4, v5, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 2291
    :goto_92d
    iget-object v4, v0, Ld$6;->O:Landroid/widget/TextView;

    if-eqz v4, :cond_934

    invoke-virtual {v4, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2292
    :cond_934
    iget-object v4, v0, Ld$6;->P:Landroid/widget/TextView;

    if-eqz v4, :cond_93b

    invoke-virtual {v4, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2294
    :cond_93b
    invoke-static {v2}, Ld;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 2295
    invoke-static {v3}, Ld;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    if-eqz v18, :cond_948

    const/16 v6, 0x2a

    goto :goto_94a

    :cond_948
    const/16 v6, 0xe

    :goto_94a
    const/4 v14, 0x7

    .line 2296
    invoke-static {v2, v14, v6}, Ld;->a(Ljava/lang/String;II)I

    move-result v6

    if-eqz v18, :cond_954

    const/16 v10, 0x1a

    goto :goto_956

    :cond_954
    const/16 v10, 0x9

    :goto_956
    const/16 v11, 0x1e

    .line 2297
    invoke-static {v3, v11, v10}, Ld;->a(Ljava/lang/String;II)I

    move-result v10

    if-eqz v18, :cond_981

    .line 2300
    iget-object v11, v0, Ld$6;->u:Landroid/content/SharedPreferences;

    const-string v12, "JSYpclU6OjJFVCwLNl9RNjEZQko8Mw=="

    invoke-static {v12}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    iget-object v14, v0, Ld$6;->u:Landroid/content/SharedPreferences;

    const-string v22, "JSYpckgnPSVIZzomL0o="

    move-object/from16 v23, v2

    invoke-static/range {v22 .. v22}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v22, "t9b/HAxsbQ=="

    move-object/from16 v25, v4

    invoke-static/range {v22 .. v22}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-interface {v14, v2, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-interface {v11, v12, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    goto :goto_9a3

    :cond_981
    move-object/from16 v23, v2

    move-object/from16 v25, v4

    .line 2301
    iget-object v2, v0, Ld$6;->u:Landroid/content/SharedPreferences;

    const-string v4, "NzU1RFsKOSlDTD04P3JIJz0lSGc6Ji9K"

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    iget-object v11, v0, Ld$6;->u:Landroid/content/SharedPreferences;

    const-string v12, "NzU1RFsKJDREWzALKV9RMg=="

    invoke-static {v12}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    const-string v14, "t9b/GQFs"

    invoke-static {v14}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-interface {v11, v12, v14}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-interface {v2, v4, v11}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    :goto_9a3
    if-eqz v18, :cond_9c6

    .line 2303
    iget-object v4, v0, Ld$6;->u:Landroid/content/SharedPreferences;

    const-string v11, "JSYpclU6OjJFVCwLIkRLNjszQ0wKICdK"

    invoke-static {v11}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    iget-object v12, v0, Ld$6;->u:Landroid/content/SharedPreferences;

    const-string v14, "JSYpclw8JyVCTTsgGVlZMg=="

    invoke-static {v14}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    const-string v22, "YGRjDXcTEg=="

    move-object/from16 v27, v5

    invoke-static/range {v22 .. v22}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-interface {v12, v14, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-interface {v4, v11, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    goto :goto_9e6

    :cond_9c6
    move-object/from16 v27, v5

    .line 2304
    iget-object v4, v0, Ld$6;->u:Landroid/content/SharedPreferences;

    const-string v5, "NzU1RFsKOSlDTD04P3JcPCclQk07IBlZWTI="

    invoke-static {v5}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    iget-object v11, v0, Ld$6;->u:Landroid/content/SharedPreferences;

    const-string v12, "NzU1RFsKMC9eWzohKFlnITUh"

    invoke-static {v12}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    const-string v14, "YWRjDXcTEg=="

    invoke-static {v14}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-interface {v11, v12, v14}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-interface {v4, v5, v11}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    :goto_9e6
    if-eqz v18, :cond_9eb

    .line 2306
    const-string v5, "BjUwSBhgZGM="

    goto :goto_9ed

    :cond_9eb
    const-string v5, "BjUwSBhhZGM="

    :goto_9ed
    invoke-static {v5}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v2, v3, v4, v5}, Ld;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 2308
    iget-object v4, v0, Ld$6;->Q:Landroid/widget/TextView;

    if-eqz v4, :cond_a63

    .line 2309
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-static/range {v25 .. v25}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v11

    invoke-direct {v5, v11}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v6, "ejAnVA=="

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    if-eqz v21, :cond_a35

    .line 2311
    iget-object v4, v0, Ld$6;->Q:Landroid/widget/TextView;

    iget-object v5, v0, Ld$6;->e:Landroid/app/Activity;

    const/4 v6, 0x6

    invoke-static {v5, v6}, Ld;->a(Landroid/content/Context;I)I

    move-result v5

    const/4 v6, 0x0

    invoke-static {v13, v5, v6, v6}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2312
    iget-object v4, v0, Ld$6;->Q:Landroid/widget/TextView;

    invoke-virtual {v4, v7}, Landroid/widget/TextView;->setTextColor(I)V

    .line 2313
    iget-object v4, v0, Ld$6;->Q:Landroid/widget/TextView;

    const/4 v5, 0x0

    const/4 v14, 0x1

    invoke-virtual {v4, v5, v14}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    goto :goto_a63

    .line 2315
    :cond_a35
    iget-object v4, v0, Ld$6;->Q:Landroid/widget/TextView;

    const-string v5, "dhJ3aw0TbQ=="

    invoke-static {v5}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    iget-object v6, v0, Ld$6;->e:Landroid/app/Activity;

    const/4 v11, 0x6

    invoke-static {v6, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    const/4 v11, 0x0

    invoke-static {v5, v6, v11, v11}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2316
    iget-object v4, v0, Ld$6;->Q:Landroid/widget/TextView;

    invoke-static {v15}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setTextColor(I)V

    .line 2317
    iget-object v4, v0, Ld$6;->Q:Landroid/widget/TextView;

    const/4 v14, 0x0

    invoke-virtual {v4, v14, v11}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 2321
    :cond_a63
    :goto_a63
    iget-object v4, v0, Ld$6;->R:Landroid/widget/TextView;

    if-eqz v4, :cond_ad2

    .line 2322
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-static/range {v27 .. v27}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v6, "ejAnVA=="

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    if-nez v21, :cond_aa3

    .line 2324
    iget-object v4, v0, Ld$6;->R:Landroid/widget/TextView;

    iget-object v5, v0, Ld$6;->e:Landroid/app/Activity;

    const/4 v6, 0x6

    invoke-static {v5, v6}, Ld;->a(Landroid/content/Context;I)I

    move-result v5

    const/4 v6, 0x0

    invoke-static {v13, v5, v6, v6}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2325
    iget-object v4, v0, Ld$6;->R:Landroid/widget/TextView;

    invoke-virtual {v4, v7}, Landroid/widget/TextView;->setTextColor(I)V

    .line 2326
    iget-object v4, v0, Ld$6;->R:Landroid/widget/TextView;

    const/4 v5, 0x0

    const/4 v14, 0x1

    invoke-virtual {v4, v5, v14}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    goto :goto_ad2

    .line 2328
    :cond_aa3
    iget-object v4, v0, Ld$6;->R:Landroid/widget/TextView;

    const-string v5, "dhJ3aw0TbQ=="

    invoke-static {v5}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    iget-object v6, v0, Ld$6;->e:Landroid/app/Activity;

    const/4 v11, 0x6

    invoke-static {v6, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    const/4 v11, 0x0

    invoke-static {v5, v6, v11, v11}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2329
    iget-object v4, v0, Ld$6;->R:Landroid/widget/TextView;

    invoke-static {v15}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setTextColor(I)V

    .line 2330
    iget-object v4, v0, Ld$6;->R:Landroid/widget/TextView;

    const/4 v14, 0x0

    invoke-virtual {v4, v14, v11}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    goto :goto_ad3

    :cond_ad2
    :goto_ad2
    const/4 v11, 0x0

    .line 2334
    :goto_ad3
    iget-object v4, v0, Ld$6;->S:Landroid/widget/TextView;

    if-eqz v4, :cond_aef

    .line 2335
    invoke-virtual {v2}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2336
    iget-object v4, v0, Ld$6;->S:Landroid/widget/TextView;

    iget-object v5, v0, Ld$6;->e:Landroid/app/Activity;

    const/16 v10, 0xa

    invoke-static {v5, v10}, Ld;->a(Landroid/content/Context;I)I

    move-result v5

    invoke-static {v7, v9, v5, v11, v11}, Ld;->a(IIIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v5

    invoke-virtual {v4, v5}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2338
    :cond_aef
    iget-object v4, v0, Ld$6;->T:Landroid/widget/TextView;

    if-eqz v4, :cond_b20

    .line 2339
    new-instance v5, Ljava/lang/StringBuilder;

    const-string v6, "BjUwSBg="

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v6, "BjUwSBg="

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "dSMvWVB1GSlDTD04Pw=="

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v4, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2340
    iget-object v1, v0, Ld$6;->T:Landroid/widget/TextView;

    invoke-virtual {v1, v7}, Landroid/widget/TextView;->setTextColor(I)V

    .line 2343
    :cond_b20
    iget-object v1, v0, Ld$6;->e:Landroid/app/Activity;

    const/16 v2, 0xe

    invoke-static {v1, v2}, Ld;->a(Landroid/content/Context;I)I

    move-result v1

    iget-object v4, v0, Ld$6;->e:Landroid/app/Activity;

    const/high16 v5, 0x40200000  # 2.5f

    invoke-static {v4, v5}, Ld;->a(Landroid/content/Context;F)I

    move-result v4

    const/4 v5, -0x1

    invoke-static {v5, v1, v4, v7}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v1

    .line 2344
    const-string v4, "dhJ+a3kTFw=="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    iget-object v5, v0, Ld$6;->e:Landroid/app/Activity;

    invoke-static {v5, v2}, Ld;->a(Landroid/content/Context;I)I

    move-result v2

    iget-object v5, v0, Ld$6;->e:Landroid/app/Activity;

    const/4 v14, 0x1

    invoke-static {v5, v14}, Ld;->a(Landroid/content/Context;I)I

    move-result v5

    invoke-static/range {v19 .. v19}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    invoke-static {v4, v2, v5, v6}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    .line 2346
    iget-object v4, v0, Ld$6;->U:Landroid/view/View;

    if-eqz v4, :cond_b64

    if-eqz v21, :cond_b60

    move-object v5, v1

    goto :goto_b61

    :cond_b60
    move-object v5, v2

    :goto_b61
    invoke-virtual {v4, v5}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2347
    :cond_b64
    iget-object v4, v0, Ld$6;->V:Landroid/view/View;

    if-eqz v4, :cond_b6f

    if-nez v21, :cond_b6b

    goto :goto_b6c

    :cond_b6b
    move-object v1, v2

    :goto_b6c
    invoke-virtual {v4, v1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2349
    :cond_b6f
    iget-object v1, v0, Ld$6;->W:Landroid/widget/TextView;

    if-eqz v1, :cond_b85

    if-eqz v21, :cond_b7a

    invoke-static/range {v26 .. v26}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    goto :goto_b7e

    :cond_b7a
    invoke-static {v15}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    :goto_b7e
    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 2350
    :cond_b85
    iget-object v1, v0, Ld$6;->X:Landroid/widget/TextView;

    if-eqz v1, :cond_b9b

    if-nez v21, :cond_b90

    invoke-static/range {v26 .. v26}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    goto :goto_b94

    :cond_b90
    invoke-static {v15}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    :goto_b94
    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 2352
    :cond_b9b
    iget-object v1, v0, Ld$6;->Y:Landroid/widget/Button;

    if-eqz v1, :cond_bf9

    if-eqz v21, :cond_ba4

    move-object/from16 v2, v23

    goto :goto_ba5

    :cond_ba4
    move-object v2, v3

    :goto_ba5
    if-eqz v18, :cond_baa

    .line 2354
    const-string v1, "BSYpDW4cBA=="

    goto :goto_bac

    :cond_baa
    const-string v1, "FzU1RFt1Ag99"

    :goto_bac
    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 2355
    iget-object v3, v0, Ld$6;->Y:Landroid/widget/Button;

    new-instance v4, Ljava/lang/StringBuilder;

    const-string v5, "ACQhX1kxMWZZV3U="

    invoke-static {v5}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "dXw="

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "fA=="

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 2356
    iget-object v1, v0, Ld$6;->Y:Landroid/widget/Button;

    iget-object v2, v0, Ld$6;->e:Landroid/app/Activity;

    const/16 v3, 0x10

    invoke-static {v2, v3}, Ld;->a(Landroid/content/Context;I)I

    move-result v2

    const/4 v5, 0x0

    invoke-static {v7, v8, v2, v5, v5}, Ld;->a(IIIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2357
    iget-object v1, v0, Ld$6;->Y:Landroid/widget/Button;

    const/4 v4, 0x0

    invoke-virtual {v1, v4, v4, v4, v4}, Landroid/widget/Button;->setCompoundDrawablesWithIntrinsicBounds(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 2358
    iget-object v1, v0, Ld$6;->Y:Landroid/widget/Button;

    invoke-virtual {v1, v5}, Landroid/widget/Button;->setCompoundDrawablePadding(I)V

    :cond_bf9
    return-void
.end method
