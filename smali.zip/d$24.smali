# classes88.dex

.class Ld$24;
.super Ljava/lang/Object;
.source "FoxSource"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ld;->a(Landroid/app/Activity;Ljava/lang/Runnable;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private final synthetic a:Landroid/app/Activity;

.field private final synthetic b:Landroid/content/SharedPreferences;

.field private final synthetic c:Ljava/lang/String;

.field private final synthetic d:Ljava/lang/Runnable;

.field private final synthetic e:Ljava/lang/String;

.field private final synthetic f:Ljava/lang/String;


# direct methods
.method constructor <init>(Landroid/app/Activity;Landroid/content/SharedPreferences;Ljava/lang/String;Ljava/lang/Runnable;Ljava/lang/String;Ljava/lang/String;)V
    .registers 7

    .line 3675
    iput-object p1, p0, Ld$24;->a:Landroid/app/Activity;

    iput-object p2, p0, Ld$24;->b:Landroid/content/SharedPreferences;

    iput-object p3, p0, Ld$24;->c:Ljava/lang/String;

    iput-object p4, p0, Ld$24;->d:Ljava/lang/Runnable;

    iput-object p5, p0, Ld$24;->e:Ljava/lang/String;

    iput-object p6, p0, Ld$24;->f:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 24

    move-object/from16 v1, p0

    .line 3679
    const-string v0, "dmwCGgETZg=="

    const-string v2, "dhACaQ4TFg=="

    const-string v3, "dhJ1awgTEg=="

    const-string v4, "dhF+aA0TFg=="

    const-string v5, "dmN+GwgQFQ=="

    :try_start_c
    new-instance v6, Landroid/app/Dialog;

    iget-object v7, v1, Ld$24;->a:Landroid/app/Activity;

    invoke-direct {v6, v7}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    const/4 v8, 0x1

    .line 3680
    invoke-virtual {v6, v8}, Landroid/app/Dialog;->requestWindowFeature(I)Z

    const/4 v10, 0x0

    .line 3681
    invoke-virtual {v6, v10}, Landroid/app/Dialog;->setCancelable(Z)V

    .line 3682
    invoke-virtual {v6, v10}, Landroid/app/Dialog;->setCanceledOnTouchOutside(Z)V

    .line 3684
    iget-object v7, v1, Ld$24;->a:Landroid/app/Activity;

    invoke-virtual {v7}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v7

    invoke-virtual {v7}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v7

    iget v11, v7, Landroid/util/DisplayMetrics;->density:F

    const/high16 v7, 0x41a00000  # 20.0f

    mul-float v7, v7, v11

    float-to-int v7, v7

    const/high16 v9, 0x41400000  # 12.0f

    mul-float v12, v11, v9

    float-to-int v13, v12

    .line 3690
    new-instance v14, Landroid/widget/LinearLayout;

    iget-object v15, v1, Ld$24;->a:Landroid/app/Activity;

    invoke-direct {v14, v15}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 3691
    invoke-virtual {v14, v8}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 3692
    invoke-virtual {v14, v8}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 3693
    invoke-virtual {v14, v7, v7, v7, v7}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 3695
    new-instance v7, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v7}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const/4 v15, -0x1

    .line 3696
    invoke-virtual {v7, v15}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const/high16 v16, 0x41b00000  # 22.0f

    mul-float v10, v11, v16

    .line 3697
    invoke-virtual {v7, v10}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    const/high16 v10, 0x3fc00000  # 1.5f

    mul-float v10, v10, v11

    float-to-int v10, v10

    .line 3698
    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v16

    invoke-static/range {v16 .. v16}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v15

    invoke-virtual {v7, v10, v15}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 3699
    invoke-virtual {v14, v7}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 3701
    new-instance v7, Landroid/widget/ImageView;

    iget-object v10, v1, Ld$24;->a:Landroid/app/Activity;

    invoke-direct {v7, v10}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    const/high16 v10, 0x42580000  # 54.0f

    mul-float v10, v10, v11

    float-to-int v10, v10

    .line 3703
    new-instance v15, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {v15, v10, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v16, 0x41200000  # 10.0f

    mul-float v9, v11, v16

    float-to-int v8, v9

    .line 3704
    iput v8, v15, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 3705
    invoke-virtual {v7, v15}, Landroid/widget/ImageView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 3706
    iget-object v15, v1, Ld$24;->a:Landroid/app/Activity;

    invoke-static {v15, v10}, Ld;->b(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v10

    invoke-virtual {v7, v10}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 3707
    invoke-virtual {v14, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 3709
    new-instance v7, Landroid/widget/TextView;

    iget-object v10, v1, Ld$24;->a:Landroid/app/Activity;

    invoke-direct {v7, v10}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 3710
    const-string v10, "GjIgRFs8NSoNez01KENdOXQUSEkgPTRIXA=="

    invoke-static {v10}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v7, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3711
    const-string v10, "dmUDHHphFg=="

    invoke-static {v10}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v10

    invoke-virtual {v7, v10}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v10, 0x41900000  # 18.0f

    .line 3712
    invoke-virtual {v7, v10}, Landroid/widget/TextView;->setTextSize(F)V

    .line 3713
    sget-object v10, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v7, v10}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    const/16 v10, 0x11

    .line 3714
    invoke-virtual {v7, v10}, Landroid/widget/TextView;->setGravity(I)V

    .line 3715
    invoke-virtual {v14, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 3717
    new-instance v7, Landroid/widget/TextView;

    iget-object v15, v1, Ld$24;->a:Landroid/app/Activity;

    invoke-direct {v7, v15}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 3718
    const-string v15, "EwYDaBgBHQN/GBQXEmRuFAAPYnY="

    invoke-static {v15}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v7, v15}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3719
    invoke-static {v5}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v15}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v15

    invoke-virtual {v7, v15}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v15, 0x41280000  # 10.5f

    .line 3720
    invoke-virtual {v7, v15}, Landroid/widget/TextView;->setTextSize(F)V

    .line 3721
    sget-object v15, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v7, v15}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    .line 3722
    invoke-virtual {v7, v10}, Landroid/widget/TextView;->setGravity(I)V

    const/high16 v15, 0x40800000  # 4.0f

    mul-float v15, v15, v11

    float-to-int v15, v15

    .line 3723
    invoke-virtual {v7, v13, v15, v13, v15}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 3725
    new-instance v10, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v10}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 3726
    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v19

    move-object/from16 v20, v0

    invoke-static/range {v19 .. v19}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {v10, v0}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 3727
    invoke-virtual {v10, v9}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    const/high16 v0, 0x3f800000  # 1.0f

    mul-float v0, v0, v11

    float-to-int v0, v0

    .line 3728
    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v9

    invoke-virtual {v10, v0, v9}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 3729
    invoke-virtual {v7, v10}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 3731
    new-instance v9, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v10, -0x2

    invoke-direct {v9, v10, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v19, 0x40c00000  # 6.0f

    mul-float v10, v11, v19

    float-to-int v10, v10

    .line 3732
    iput v10, v9, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 3733
    iput v13, v9, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 3734
    invoke-virtual {v7, v9}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 3735
    invoke-virtual {v14, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 3737
    new-instance v7, Landroid/widget/LinearLayout;

    iget-object v9, v1, Ld$24;->a:Landroid/app/Activity;

    invoke-direct {v7, v9}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v9, 0x1

    .line 3738
    invoke-virtual {v7, v9}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 3739
    invoke-virtual {v7, v13, v13, v13, v13}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 3740
    new-instance v9, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v9}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 3741
    const-string v13, "dhJ+a3kTFw=="

    invoke-static {v13}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-static {v13}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v13

    invoke-virtual {v9, v13}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 3742
    invoke-virtual {v9, v12}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 3743
    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v9, v0, v4}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 3744
    invoke-virtual {v7, v9}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 3746
    new-instance v4, Landroid/widget/TextView;

    iget-object v9, v1, Ld$24;->a:Landroid/app/Activity;

    invoke-direct {v4, v9}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 3747
    const-string v9, "FjsrQE07PTJUGDY8J0NWMDg1FzJfBDREVTQmPxcYPSAyXUtve2lZFjgxaQZxDCJ2aGs7Fg5eSD4OLGwJXwcjTlc7MCdfQW90LllMJSd8AhcheitIF34uAmB/YxsARXEsET50QhxtTCd3JTEoDVl1Ny5MVjsxKg1MOnQlQlYhPShYXXs="

    invoke-static {v9}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v4, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3748
    const-string v9, "dmBxGA1jbQ=="

    invoke-static {v9}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v9

    invoke-virtual {v4, v9}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v9, 0x41400000  # 12.0f

    .line 3749
    invoke-virtual {v4, v9}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v9, 0x0

    const/high16 v13, 0x3fa00000  # 1.25f

    .line 3750
    invoke-virtual {v4, v9, v13}, Landroid/widget/TextView;->setLineSpacing(FF)V

    .line 3751
    invoke-virtual {v7, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 3753
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v9, -0x2

    const/4 v13, -0x1

    invoke-direct {v4, v13, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v9, 0x41600000  # 14.0f

    mul-float v9, v9, v11

    float-to-int v9, v9

    .line 3754
    iput v9, v4, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 3755
    invoke-virtual {v7, v4}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 3756
    invoke-virtual {v14, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 3758
    new-instance v9, Landroid/widget/Button;

    iget-object v4, v1, Ld$24;->a:Landroid/app/Activity;

    invoke-direct {v9, v4}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    .line 3759
    const-string v4, "BiAjXRhkbmZiSDA6ZmJeMz0lRFk5dAVFWTs6I0E="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v9, v4}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    const/4 v13, -0x1

    .line 3760
    invoke-virtual {v9, v13}, Landroid/widget/Button;->setTextColor(I)V

    const/high16 v4, 0x41580000  # 13.5f

    .line 3761
    invoke-virtual {v9, v4}, Landroid/widget/Button;->setTextSize(F)V

    .line 3762
    sget-object v7, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v9, v7}, Landroid/widget/Button;->setTypeface(Landroid/graphics/Typeface;)V

    const/4 v7, 0x0

    .line 3763
    invoke-virtual {v9, v7}, Landroid/widget/Button;->setAllCaps(Z)V

    .line 3765
    new-instance v7, Landroid/graphics/drawable/GradientDrawable;

    .line 3766
    sget-object v13, Landroid/graphics/drawable/GradientDrawable$Orientation;->LEFT_RIGHT:Landroid/graphics/drawable/GradientDrawable$Orientation;

    .line 3767
    const-string v18, "dmR2FQAWFw=="

    invoke-static/range {v18 .. v18}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v18

    invoke-static/range {v18 .. v18}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    const-string v18, "dmR2Gg8XYQ=="

    invoke-static/range {v18 .. v18}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v18

    move-object/from16 v21, v2

    invoke-static/range {v18 .. v18}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    filled-new-array {v4, v2}, [I

    move-result-object v2

    .line 3765
    invoke-direct {v7, v13, v2}, Landroid/graphics/drawable/GradientDrawable;-><init>(Landroid/graphics/drawable/GradientDrawable$Orientation;[I)V

    .line 3769
    invoke-virtual {v7, v12}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 3770
    invoke-virtual {v9, v7}, Landroid/widget/Button;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 3772
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v4, 0x42380000  # 46.0f

    mul-float v4, v4, v11

    float-to-int v4, v4

    const/4 v13, -0x1

    invoke-direct {v2, v13, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 3773
    iput v8, v2, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 3774
    invoke-virtual {v9, v2}, Landroid/widget/Button;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 3775
    invoke-virtual {v14, v9}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 3777
    new-instance v13, Landroid/widget/Button;

    iget-object v2, v1, Ld$24;->a:Landroid/app/Activity;

    invoke-direct {v13, v2}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    .line 3778
    const-string v2, "BiAjXRhnbmZiSDA6Zm5QNDooSFQ="

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v13, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    const/4 v2, -0x1

    .line 3779
    invoke-virtual {v13, v2}, Landroid/widget/Button;->setTextColor(I)V

    const/high16 v2, 0x41580000  # 13.5f

    .line 3780
    invoke-virtual {v13, v2}, Landroid/widget/Button;->setTextSize(F)V

    .line 3781
    sget-object v2, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v13, v2}, Landroid/widget/Button;->setTypeface(Landroid/graphics/Typeface;)V

    const/4 v7, 0x0

    .line 3782
    invoke-virtual {v13, v7}, Landroid/widget/Button;->setAllCaps(Z)V

    .line 3784
    new-instance v2, Landroid/graphics/drawable/GradientDrawable;

    .line 3785
    sget-object v7, Landroid/graphics/drawable/GradientDrawable$Orientation;->LEFT_RIGHT:Landroid/graphics/drawable/GradientDrawable$Orientation;

    .line 3786
    invoke-static/range {v20 .. v20}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v18

    move-object/from16 v19, v3

    invoke-static/range {v18 .. v18}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    invoke-static {v5}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v18

    move-object/from16 v22, v5

    invoke-static/range {v18 .. v18}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    filled-new-array {v3, v5}, [I

    move-result-object v3

    .line 3784
    invoke-direct {v2, v7, v3}, Landroid/graphics/drawable/GradientDrawable;-><init>(Landroid/graphics/drawable/GradientDrawable$Orientation;[I)V

    .line 3788
    invoke-virtual {v2, v12}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 3789
    invoke-virtual {v13, v2}, Landroid/widget/Button;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 3791
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v3, -0x1

    invoke-direct {v2, v3, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 3792
    iput v8, v2, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 3793
    invoke-virtual {v13, v2}, Landroid/widget/Button;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 3794
    invoke-virtual {v14, v13}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 3796
    new-instance v2, Landroid/widget/Button;

    iget-object v3, v1, Ld$24;->a:Landroid/app/Activity;

    invoke-direct {v2, v3}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    .line 3797
    const-string v3, "FjwjTlN1AiNfUTM9JUxMPDsoDWshNTJYSw=="

    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 3798
    invoke-static/range {v22 .. v22}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setTextColor(I)V

    const/high16 v3, 0x41480000  # 12.5f

    .line 3799
    invoke-virtual {v2, v3}, Landroid/widget/Button;->setTextSize(F)V

    .line 3800
    sget-object v3, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setTypeface(Landroid/graphics/Typeface;)V

    const/4 v7, 0x0

    .line 3801
    invoke-virtual {v2, v7}, Landroid/widget/Button;->setAllCaps(Z)V

    .line 3803
    new-instance v3, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v3}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 3804
    invoke-static/range {v19 .. v19}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v3, v4}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 3805
    invoke-virtual {v3, v12}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 3806
    invoke-static/range {v21 .. v21}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v3, v0, v4}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 3807
    invoke-virtual {v2, v3}, Landroid/widget/Button;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 3809
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v3, 0x42280000  # 42.0f

    mul-float v3, v3, v11

    float-to-int v3, v3

    const/4 v4, -0x1

    invoke-direct {v0, v4, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 3810
    iput v8, v0, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 3811
    invoke-virtual {v2, v0}, Landroid/widget/Button;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 3812
    invoke-virtual {v14, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 3814
    new-instance v8, Landroid/widget/TextView;

    iget-object v0, v1, Ld$24;->a:Landroid/app/Activity;

    invoke-direct {v8, v0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 3815
    const-string v0, "ATU2DWshMTYNCnUgKQ1XJTEoDUw9MWZOUDQ6KEhUew=="

    invoke-static {v0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v8, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3816
    const-string v0, "dmJyGgxtFg=="

    invoke-static {v0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {v8, v0}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v0, 0x41300000  # 11.0f

    .line 3817
    invoke-virtual {v8, v0}, Landroid/widget/TextView;->setTextSize(F)V

    const/16 v0, 0x11

    .line 3818
    invoke-virtual {v8, v0}, Landroid/widget/TextView;->setGravity(I)V

    .line 3819
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v3, -0x2

    const/4 v4, -0x1

    invoke-direct {v0, v4, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/high16 v3, 0x41000000  # 8.0f

    mul-float v3, v3, v11

    float-to-int v3, v3

    .line 3820
    iput v3, v0, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 3821
    invoke-virtual {v8, v0}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 3822
    invoke-virtual {v14, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 3824
    new-instance v12, Landroid/widget/TextView;

    iget-object v0, v1, Ld$24;->a:Landroid/app/Activity;

    invoke-direct {v12, v0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 3825
    const-string v0, "AjUoWRg8OjVZWTsgZlhWOT0rREwwMGZMWzYxNV4YIj0yRVcgIGZHVzw6L0NfanQTXV8nNSJIGCE7ZntxBQ=="

    invoke-static {v0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v12, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3826
    invoke-static/range {v20 .. v20}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {v12, v0}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v0, 0x41380000  # 11.5f

    .line 3827
    invoke-virtual {v12, v0}, Landroid/widget/TextView;->setTextSize(F)V

    .line 3828
    sget-object v0, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v12, v0}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    const/16 v0, 0x11

    .line 3829
    invoke-virtual {v12, v0}, Landroid/widget/TextView;->setGravity(I)V

    .line 3830
    invoke-virtual {v12, v15, v10, v15, v15}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 3831
    invoke-virtual {v14, v12}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    move-object v3, v2

    const/4 v0, 0x1

    .line 3833
    new-array v2, v0, [Z

    .line 3834
    new-instance v10, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-direct {v10, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 3836
    new-instance v0, Ld$24$1;

    move-object v4, v3

    iget-object v3, v1, Ld$24;->a:Landroid/app/Activity;

    move-object v5, v4

    iget-object v4, v1, Ld$24;->b:Landroid/content/SharedPreferences;

    move-object v7, v5

    iget-object v5, v1, Ld$24;->c:Ljava/lang/String;

    move-object v15, v7

    iget-object v7, v1, Ld$24;->d:Ljava/lang/Runnable;

    invoke-direct/range {v0 .. v7}, Ld$24$1;-><init>(Ld$24;[ZLandroid/app/Activity;Landroid/content/SharedPreferences;Ljava/lang/String;Landroid/app/Dialog;Ljava/lang/Runnable;)V

    move-object/from16 v17, v6

    const/4 v3, 0x1

    .line 3905
    new-array v4, v3, [I

    move-object v5, v0

    .line 3906
    new-instance v0, Ld$24$2;

    iget-object v3, v1, Ld$24;->a:Landroid/app/Activity;

    move-object v6, v10

    invoke-direct/range {v0 .. v6}, Ld$24$2;-><init>(Ld$24;[ZLandroid/app/Activity;[ILjava/lang/Runnable;Landroid/os/Handler;)V

    move-object v10, v2

    move-object v3, v6

    .line 3918
    new-instance v2, Ld$24$3;

    iget-object v5, v1, Ld$24;->a:Landroid/app/Activity;

    iget-object v6, v1, Ld$24;->e:Ljava/lang/String;

    invoke-direct {v2, v1, v9, v5, v6}, Ld$24$3;-><init>(Ld$24;Landroid/widget/Button;Landroid/app/Activity;Ljava/lang/String;)V

    invoke-virtual {v9, v2}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    move-object v2, v8

    move-object v8, v0

    .line 3926
    new-instance v0, Ld$24$4;

    move-object v6, v4

    iget-object v4, v1, Ld$24;->a:Landroid/app/Activity;

    iget-object v5, v1, Ld$24;->f:Ljava/lang/String;

    move-object v7, v3

    move-object v3, v13

    invoke-direct/range {v0 .. v8}, Ld$24$4;-><init>(Ld$24;Landroid/widget/TextView;Landroid/widget/Button;Landroid/app/Activity;Ljava/lang/String;[ILandroid/os/Handler;Ljava/lang/Runnable;)V

    move-object v13, v7

    move-object/from16 v16, v8

    invoke-virtual {v3, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 3939
    new-instance v0, Ld$24$5;

    iget-object v3, v1, Ld$24;->b:Landroid/content/SharedPreferences;

    iget-object v4, v1, Ld$24;->a:Landroid/app/Activity;

    iget-object v5, v1, Ld$24;->c:Ljava/lang/String;

    iget-object v8, v1, Ld$24;->d:Ljava/lang/Runnable;

    move-object v9, v2

    move-object v6, v10

    move-object v2, v15

    move-object/from16 v7, v17

    invoke-direct/range {v0 .. v9}, Ld$24$5;-><init>(Ld$24;Landroid/widget/Button;Landroid/content/SharedPreferences;Landroid/app/Activity;Ljava/lang/String;[ZLandroid/app/Dialog;Ljava/lang/Runnable;Landroid/widget/TextView;)V

    move-object v15, v2

    move-object v2, v6

    move-object/from16 v17, v7

    invoke-virtual {v15, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 4023
    new-instance v0, Ld$24$6;

    iget-object v6, v1, Ld$24;->a:Landroid/app/Activity;

    move-object v3, v13

    move-object/from16 v4, v16

    move-object/from16 v5, v17

    invoke-direct/range {v0 .. v6}, Ld$24$6;-><init>(Ld$24;[ZLandroid/os/Handler;Ljava/lang/Runnable;Landroid/app/Dialog;Landroid/app/Activity;)V

    move-object v2, v0

    move-object v0, v4

    invoke-virtual {v12, v2}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const-wide/16 v6, 0x7d0

    .line 4033
    invoke-virtual {v3, v0, v6, v7}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 4035
    invoke-virtual {v5, v14}, Landroid/app/Dialog;->setContentView(Landroid/view/View;)V

    .line 4036
    invoke-virtual {v5}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    if-eqz v0, :cond_3d6

    .line 4037
    invoke-virtual {v5}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    new-instance v2, Landroid/graphics/drawable/ColorDrawable;

    const/4 v7, 0x0

    invoke-direct {v2, v7}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    invoke-virtual {v0, v2}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 4038
    invoke-virtual {v5}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    move-result-object v0

    .line 4039
    iget-object v2, v1, Ld$24;->a:Landroid/app/Activity;

    invoke-virtual {v2}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v2

    iget v2, v2, Landroid/util/DisplayMetrics;->widthPixels:I

    const/high16 v3, 0x43be0000  # 380.0f

    mul-float v11, v11, v3

    float-to-int v3, v11

    int-to-float v2, v2

    const v4, 0x3f6b851f  # 0.92f

    mul-float v2, v2, v4

    float-to-int v2, v2

    .line 4040
    invoke-static {v3, v2}, Ljava/lang/Math;->min(II)I

    move-result v2

    iput v2, v0, Landroid/view/WindowManager$LayoutParams;->width:I

    const/4 v3, -0x2

    .line 4041
    iput v3, v0, Landroid/view/WindowManager$LayoutParams;->height:I

    .line 4042
    invoke-virtual {v5}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v2

    invoke-virtual {v2, v0}, Landroid/view/Window;->setAttributes(Landroid/view/WindowManager$LayoutParams;)V

    .line 4044
    :cond_3d6
    invoke-virtual {v5}, Landroid/app/Dialog;->show()V
    :try_end_3d9
    .catchall {:try_start_c .. :try_end_3d9} :catchall_3da

    return-void

    :catchall_3da
    move-exception v0

    .line 4047
    const-string v2, "Ezs+fVQ0OgtMVjQzI18="

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "JjwpWnU0OiJMTDomP3ldOTEhX1k4EC9MVDozZkhKJzs0"

    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    return-void
.end method
