# classes88.dex

.class Le$4$1;
.super Ljava/lang/Object;
.source "FoxSource"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Le$4;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Le$4;

.field private final synthetic b:Landroid/app/Activity;


# direct methods
.method constructor <init>(Le$4;Landroid/app/Activity;)V
    .registers 3

    .line 1097
    iput-object p1, p0, Le$4$1;->a:Le$4;

    iput-object p2, p0, Le$4$1;->b:Landroid/app/Activity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .registers 3

    .line 1100
    iget-object p1, p0, Le$4$1;->b:Landroid/app/Activity;

    invoke-static {p1}, Le;->f(Landroid/app/Activity;)V

    return-void
.end method
