# classes88.dex

.class Ld$4;
.super Ljava/lang/Object;
.source "FoxSource"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ld;->b(Landroid/app/Activity;Landroid/app/Dialog;Landroid/view/View;Ljava/lang/String;IIIILandroid/content/SharedPreferences;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private final synthetic a:Landroid/app/Activity;

.field private final synthetic b:Landroid/widget/TextView;

.field private final synthetic c:Landroid/view/View;

.field private final synthetic d:Landroid/widget/TextView;

.field private final synthetic e:Landroid/widget/Button;

.field private final synthetic f:Landroid/widget/TextView;

.field private final synthetic g:Landroid/widget/TextView;


# direct methods
.method constructor <init>(Landroid/app/Activity;Landroid/widget/TextView;Landroid/view/View;Landroid/widget/TextView;Landroid/widget/Button;Landroid/widget/TextView;Landroid/widget/TextView;)V
    .registers 8

    .line 2006
    iput-object p1, p0, Ld$4;->a:Landroid/app/Activity;

    iput-object p2, p0, Ld$4;->b:Landroid/widget/TextView;

    iput-object p3, p0, Ld$4;->c:Landroid/view/View;

    iput-object p4, p0, Ld$4;->d:Landroid/widget/TextView;

    iput-object p5, p0, Ld$4;->e:Landroid/widget/Button;

    iput-object p6, p0, Ld$4;->f:Landroid/widget/TextView;

    iput-object p7, p0, Ld$4;->g:Landroid/widget/TextView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 11

    .line 2009
    iget-object p1, p0, Ld$4;->a:Landroid/app/Activity;

    const-string v0, "Bi0oTlE7M2ZdVDQ6ZlpRITxmXl0nIiNfFnt6"

    invoke-static {v0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    invoke-static {p1, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p1

    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 2010
    iget-object p1, p0, Ld$4;->a:Landroid/app/Activity;

    new-instance v0, Ld$4$1;

    iget-object v2, p0, Ld$4;->a:Landroid/app/Activity;

    iget-object v3, p0, Ld$4;->b:Landroid/widget/TextView;

    iget-object v4, p0, Ld$4;->c:Landroid/view/View;

    iget-object v5, p0, Ld$4;->d:Landroid/widget/TextView;

    iget-object v6, p0, Ld$4;->e:Landroid/widget/Button;

    iget-object v7, p0, Ld$4;->f:Landroid/widget/TextView;

    iget-object v8, p0, Ld$4;->g:Landroid/widget/TextView;

    move-object v1, p0

    invoke-direct/range {v0 .. v8}, Ld$4$1;-><init>(Ld$4;Landroid/app/Activity;Landroid/widget/TextView;Landroid/view/View;Landroid/widget/TextView;Landroid/widget/Button;Landroid/widget/TextView;Landroid/widget/TextView;)V

    invoke-static {p1, v0}, Ld;->a(Landroid/content/Context;Ljava/lang/Runnable;)V

    return-void
.end method
