# classes88.dex

.class Lb$5$1;
.super Ljava/lang/Object;
.source "FoxSource"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lb$5;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lb$5;

.field private final synthetic b:Landroid/widget/LinearLayout;

.field private final synthetic c:Landroid/widget/LinearLayout;


# direct methods
.method constructor <init>(Lb$5;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;)V
    .registers 4

    .line 294
    iput-object p1, p0, Lb$5$1;->a:Lb$5;

    iput-object p2, p0, Lb$5$1;->b:Landroid/widget/LinearLayout;

    iput-object p3, p0, Lb$5$1;->c:Landroid/widget/LinearLayout;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 4

    .line 297
    iget-object v0, p0, Lb$5$1;->b:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->removeAllViews()V

    .line 298
    iget-object v0, p0, Lb$5$1;->b:Landroid/widget/LinearLayout;

    const/high16 v1, 0x3f800000  # 1.0f

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setAlpha(F)V

    .line 299
    iget-object v0, p0, Lb$5$1;->b:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setScaleY(F)V

    .line 301
    iget-object v0, p0, Lb$5$1;->c:Landroid/widget/LinearLayout;

    if-eqz v0, :cond_32

    const/4 v2, 0x0

    .line 302
    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 303
    iget-object v0, p0, Lb$5$1;->c:Landroid/widget/LinearLayout;

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setAlpha(F)V

    .line 304
    iget-object v0, p0, Lb$5$1;->c:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    const-wide/16 v1, 0xfa

    invoke-virtual {v0, v1, v2}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/ViewPropertyAnimator;->start()V

    :cond_32
    return-void
.end method
