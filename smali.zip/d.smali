# classes88.dex

.class public Ld;
.super Ljava/lang/Object;
.source "FoxSource"


# static fields
.field public static final a:Ljava/lang/String;

.field public static final b:Ljava/lang/String;

.field public static final c:Ljava/lang/String;

.field private static final d:Ljava/lang/String;

.field private static final e:Ljava/lang/String;

.field private static final f:Ljava/lang/String;

.field private static final g:Ljava/lang/String;

.field private static final h:Ljava/lang/String;

.field private static final i:Ljava/lang/String;

.field private static final j:Ljava/lang/String;

.field private static final k:Ljava/lang/String;

.field private static final l:Ljava/lang/String;

.field private static final m:Ljava/lang/String;

.field private static final n:Ljava/lang/String;

.field private static final o:Ljava/lang/String;

.field private static final p:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 51
    invoke-static {}, Le;->N()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Ld;->a:Ljava/lang/String;

    .line 52
    invoke-static {}, Le;->M()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Ld;->b:Ljava/lang/String;

    .line 53
    invoke-static {}, Le;->L()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Ld;->c:Ljava/lang/String;

    .line 58
    invoke-static {}, Le;->p()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Ld;->d:Ljava/lang/String;

    .line 59
    invoke-static {}, Le;->q()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Ld;->e:Ljava/lang/String;

    .line 60
    invoke-static {}, Le;->r()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Ld;->f:Ljava/lang/String;

    .line 61
    invoke-static {}, Le;->s()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Ld;->g:Ljava/lang/String;

    .line 62
    invoke-static {}, Le;->t()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Ld;->h:Ljava/lang/String;

    .line 63
    invoke-static {}, Le;->aH()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Ld;->i:Ljava/lang/String;

    .line 64
    invoke-static {}, Le;->aI()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Ld;->j:Ljava/lang/String;

    .line 65
    invoke-static {}, Le;->aJ()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Ld;->k:Ljava/lang/String;

    .line 66
    invoke-static {}, Le;->aK()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Ld;->l:Ljava/lang/String;

    .line 67
    invoke-static {}, Le;->aL()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Ld;->m:Ljava/lang/String;

    .line 68
    invoke-static {}, Le;->aM()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Ld;->n:Ljava/lang/String;

    .line 69
    invoke-static {}, Le;->aN()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Ld;->o:Ljava/lang/String;

    .line 70
    invoke-static {}, Le;->aO()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Ld;->p:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    .line 49
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static a(Landroid/content/Context;F)I
    .registers 2

    if-nez p0, :cond_8

    const/high16 p0, 0x40000000  # 2.0f

    mul-float p1, p1, p0

    :goto_6
    float-to-int p0, p1

    return p0

    .line 939
    :cond_8
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    iget p0, p0, Landroid/util/DisplayMetrics;->density:F

    mul-float p1, p1, p0

    const/high16 p0, 0x3f000000  # 0.5f

    add-float/2addr p1, p0

    goto :goto_6
.end method

.method public static a(Landroid/content/Context;I)I
    .registers 2

    int-to-float p1, p1

    .line 943
    invoke-static {p0, p1}, Ld;->a(Landroid/content/Context;F)I

    move-result p0

    return p0
.end method

.method public static a(Ljava/lang/String;I)I
    .registers 4

    if-eqz p0, :cond_25

    .line 1586
    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_d

    goto :goto_25

    .line 1590
    :cond_d
    :try_start_d
    const-string v0, "Dgp2AAEI"

    invoke-static {v0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, ""

    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    .line 1591
    invoke-virtual {p0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_20

    goto :goto_25

    .line 1594
    :cond_20
    invoke-static {p0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p0
    :try_end_24
    .catch Ljava/lang/Exception; {:try_start_d .. :try_end_24} :catch_25

    return p0

    :catch_25
    :cond_25
    :goto_25
    return p1
.end method

.method public static a(Ljava/lang/String;II)I
    .registers 4

    if-gtz p1, :cond_3

    goto :goto_a

    :cond_3
    const/4 v0, -0x1

    .line 1611
    invoke-static {p0, v0}, Ld;->a(Ljava/lang/String;I)I

    move-result p0

    if-gtz p0, :cond_b

    :goto_a
    return p2

    .line 1615
    :cond_b
    div-int p1, p0, p1

    if-gtz p1, :cond_13

    if-lez p0, :cond_13

    const/4 p0, 0x1

    return p0

    :cond_13
    return p1
.end method

.method public static a(Landroid/content/Context;II)Landroid/graphics/drawable/Drawable;
    .registers 10

    const/4 v0, 0x0

    if-nez p0, :cond_4

    return-object v0

    .line 1072
    :cond_4
    invoke-static {p0, p1}, Ld;->a(Landroid/content/Context;I)I

    move-result p1

    if-gtz p1, :cond_c

    const/16 p1, 0x30

    .line 1075
    :cond_c
    :try_start_c
    sget-object v1, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {p1, p1, v1}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v1

    .line 1076
    new-instance v2, Landroid/graphics/Canvas;

    invoke-direct {v2, v1}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    .line 1078
    new-instance v3, Landroid/graphics/Paint;

    const/4 v4, 0x1

    invoke-direct {v3, v4}, Landroid/graphics/Paint;-><init>(I)V

    .line 1079
    sget-object v4, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1080
    invoke-virtual {v3, p2}, Landroid/graphics/Paint;->setColor(I)V

    int-to-float p1, p1

    .line 1085
    new-instance p2, Landroid/graphics/Path;

    invoke-direct {p2}, Landroid/graphics/Path;-><init>()V

    const v4, 0x3f147ae1  # 0.58f

    mul-float v4, v4, p1

    const v5, 0x3df5c28f  # 0.12f

    mul-float v5, v5, p1

    .line 1086
    invoke-virtual {p2, v4, v5}, Landroid/graphics/Path;->moveTo(FF)V

    const v4, 0x3e75c28f  # 0.24f

    mul-float v4, v4, p1

    const v5, 0x3f051eb8  # 0.52f

    mul-float v5, v5, p1

    .line 1087
    invoke-virtual {p2, v4, v5}, Landroid/graphics/Path;->lineTo(FF)V

    const v4, 0x3ef5c28f  # 0.48f

    mul-float v4, v4, p1

    .line 1088
    invoke-virtual {p2, v4, v5}, Landroid/graphics/Path;->lineTo(FF)V

    const v4, 0x3ed70a3d  # 0.42f

    mul-float v4, v4, p1

    const v6, 0x3f6147ae  # 0.88f

    mul-float v6, v6, p1

    .line 1089
    invoke-virtual {p2, v4, v6}, Landroid/graphics/Path;->lineTo(FF)V

    const v4, 0x3f428f5c  # 0.76f

    mul-float v4, v4, p1

    const v6, 0x3ee147ae  # 0.44f

    mul-float p1, p1, v6

    .line 1090
    invoke-virtual {p2, v4, p1}, Landroid/graphics/Path;->lineTo(FF)V

    .line 1091
    invoke-virtual {p2, v5, p1}, Landroid/graphics/Path;->lineTo(FF)V

    .line 1092
    invoke-virtual {p2}, Landroid/graphics/Path;->close()V

    .line 1094
    invoke-virtual {v2, p2, v3}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 1096
    new-instance p1, Landroid/graphics/drawable/BitmapDrawable;

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-direct {p1, p0, v1}, Landroid/graphics/drawable/BitmapDrawable;-><init>(Landroid/content/res/Resources;Landroid/graphics/Bitmap;)V
    :try_end_79
    .catchall {:try_start_c .. :try_end_79} :catchall_7a

    return-object p1

    :catchall_7a
    return-object v0
.end method

.method public static a(Landroid/content/Context;III)Landroid/graphics/drawable/Drawable;
    .registers 16

    const/4 v0, 0x0

    if-nez p0, :cond_4

    return-object v0

    .line 1023
    :cond_4
    invoke-static {p0, p1}, Ld;->a(Landroid/content/Context;I)I

    move-result p1

    if-gtz p1, :cond_c

    const/16 p1, 0x30

    .line 1026
    :cond_c
    :try_start_c
    sget-object v1, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {p1, p1, v1}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v1

    .line 1027
    new-instance v2, Landroid/graphics/Canvas;

    invoke-direct {v2, v1}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    .line 1029
    new-instance v3, Landroid/graphics/Paint;

    const/4 v4, 0x1

    invoke-direct {v3, v4}, Landroid/graphics/Paint;-><init>(I)V

    .line 1030
    sget-object v5, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v3, v5}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1031
    invoke-virtual {v3, p2}, Landroid/graphics/Paint;->setColor(I)V

    int-to-float p1, p1

    .line 1036
    new-instance p2, Landroid/graphics/RectF;

    const v5, 0x3e23d70a  # 0.16f

    mul-float v5, v5, p1

    const v6, 0x3f3851ec  # 0.72f

    mul-float v6, v6, p1

    const v7, 0x3f570a3d  # 0.84f

    mul-float v7, v7, p1

    invoke-direct {p2, v5, v6, v7, v7}, Landroid/graphics/RectF;-><init>(FFFF)V

    const/4 v5, 0x2

    .line 1037
    invoke-static {p0, v5}, Ld;->a(Landroid/content/Context;I)I

    move-result v7

    int-to-float v7, v7

    invoke-static {p0, v5}, Ld;->a(Landroid/content/Context;I)I

    move-result v5

    int-to-float v5, v5

    invoke-virtual {v2, p2, v7, v5, v3}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 1039
    new-instance p2, Landroid/graphics/Path;

    invoke-direct {p2}, Landroid/graphics/Path;-><init>()V

    const v5, 0x3e3851ec  # 0.18f

    mul-float v5, v5, p1

    .line 1040
    invoke-virtual {p2, v5, v6}, Landroid/graphics/Path;->moveTo(FF)V

    const v7, 0x3ec28f5c  # 0.38f

    mul-float v7, v7, p1

    .line 1041
    invoke-virtual {p2, v5, v7}, Landroid/graphics/Path;->lineTo(FF)V

    const v8, 0x3eb851ec  # 0.36f

    mul-float v8, v8, p1

    const v9, 0x3f0a3d71  # 0.54f

    mul-float v9, v9, p1

    .line 1042
    invoke-virtual {p2, v8, v9}, Landroid/graphics/Path;->lineTo(FF)V

    const/high16 v10, 0x3f000000  # 0.5f

    mul-float v10, v10, p1

    const v11, 0x3e6147ae  # 0.22f

    mul-float v11, v11, p1

    .line 1043
    invoke-virtual {p2, v10, v11}, Landroid/graphics/Path;->lineTo(FF)V

    const v11, 0x3f23d70a  # 0.64f

    mul-float v11, v11, p1

    .line 1044
    invoke-virtual {p2, v11, v9}, Landroid/graphics/Path;->lineTo(FF)V

    const v9, 0x3f51eb85  # 0.82f

    mul-float v9, v9, p1

    .line 1045
    invoke-virtual {p2, v9, v7}, Landroid/graphics/Path;->lineTo(FF)V

    .line 1046
    invoke-virtual {p2, v9, v6}, Landroid/graphics/Path;->lineTo(FF)V

    .line 1047
    invoke-virtual {p2}, Landroid/graphics/Path;->close()V

    .line 1048
    invoke-virtual {v2, p2, v3}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 1050
    new-instance p2, Landroid/graphics/Paint;

    invoke-direct {p2, v4}, Landroid/graphics/Paint;-><init>(I)V

    .line 1051
    sget-object v3, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {p2, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1052
    invoke-virtual {p2, p3}, Landroid/graphics/Paint;->setColor(I)V

    const p3, 0x3d6147ae  # 0.055f

    mul-float p3, p3, p1

    .line 1055
    invoke-virtual {v2, v5, v8, p3, p2}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    const v3, 0x3e4ccccd  # 0.2f

    mul-float v3, v3, p1

    const v4, 0x3f933333  # 1.15f

    mul-float v4, v4, p3

    .line 1056
    invoke-virtual {v2, v10, v3, v4, p2}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1057
    invoke-virtual {v2, v9, v8, p3, p2}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    const p3, 0x3d03126f  # 0.032f

    mul-float p3, p3, p1

    const v3, 0x3ea3d70a  # 0.32f

    mul-float v3, v3, p1

    const v4, 0x3f47ae14  # 0.78f

    mul-float v4, v4, p1

    .line 1060
    invoke-virtual {v2, v3, v4, p3, p2}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1061
    invoke-virtual {v2, v10, v4, p3, p2}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    const v3, 0x3f2e147b  # 0.68f

    mul-float p1, p1, v3

    .line 1062
    invoke-virtual {v2, p1, v4, p3, p2}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1064
    new-instance p1, Landroid/graphics/drawable/BitmapDrawable;

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-direct {p1, p0, v1}, Landroid/graphics/drawable/BitmapDrawable;-><init>(Landroid/content/res/Resources;Landroid/graphics/Bitmap;)V
    :try_end_da
    .catchall {:try_start_c .. :try_end_da} :catchall_db

    return-object p1

    :catchall_db
    return-object v0
.end method

.method public static a(IIII)Landroid/graphics/drawable/GradientDrawable;
    .registers 5

    .line 1003
    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v0}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 1004
    invoke-virtual {v0, p0}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    int-to-float p0, p1

    .line 1005
    invoke-virtual {v0, p0}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    if-lez p2, :cond_11

    .line 1007
    invoke-virtual {v0, p2, p3}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    :cond_11
    return-object v0
.end method

.method public static a(IIIII)Landroid/graphics/drawable/GradientDrawable;
    .registers 7

    .line 1013
    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    sget-object v1, Landroid/graphics/drawable/GradientDrawable$Orientation;->LEFT_RIGHT:Landroid/graphics/drawable/GradientDrawable$Orientation;

    filled-new-array {p0, p1}, [I

    move-result-object p0

    invoke-direct {v0, v1, p0}, Landroid/graphics/drawable/GradientDrawable;-><init>(Landroid/graphics/drawable/GradientDrawable$Orientation;[I)V

    int-to-float p0, p2

    .line 1014
    invoke-virtual {v0, p0}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    if-lez p3, :cond_14

    .line 1016
    invoke-virtual {v0, p3, p4}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    :cond_14
    return-object v0
.end method

.method static synthetic a(Landroid/app/Activity;Landroid/app/Dialog;Ljava/lang/String;IIIILandroid/content/SharedPreferences;)Landroid/view/View;
    .registers 8

    .line 2437
    invoke-static/range {p0 .. p7}, Ld;->b(Landroid/app/Activity;Landroid/app/Dialog;Ljava/lang/String;IIIILandroid/content/SharedPreferences;)Landroid/view/View;

    move-result-object p0

    return-object p0
.end method

.method private static a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;
    .registers 8

    const/4 v0, 0x0

    if-eqz p0, :cond_35

    if-eqz p1, :cond_35

    if-nez p2, :cond_8

    goto :goto_35

    .line 930
    :cond_8
    invoke-virtual {p0}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const-string v2, "PDA="

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p0}, Landroid/app/Activity;->getPackageName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, p2, v3, v4}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v1

    if-nez v1, :cond_2e

    .line 932
    invoke-virtual {p0}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "NjsrA1EjNTQDVTowNQNZPA=="

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p0, p2, v1, v2}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v1

    :cond_2e
    if-eqz v1, :cond_35

    .line 934
    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p0

    return-object p0

    :cond_35
    :goto_35
    return-object v0
.end method

.method public static a()Ljava/lang/String;
    .registers 1

    .line 73
    invoke-static {}, Le;->h()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static a(J)Ljava/lang/String;
    .registers 3

    .line 120
    sget-object v0, Ld;->a:Ljava/lang/String;

    invoke-static {p0, p1, v0}, Ld;->a(JLjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static a(JLjava/lang/String;)Ljava/lang/String;
    .registers 7

    .line 105
    const-string v0, "LC0/VHUYMCJlcDg5"

    if-eqz p2, :cond_47

    sget-object v1, Ld;->a:Ljava/lang/String;

    invoke-virtual {p2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {v1, p2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result p2

    if-eqz p2, :cond_11

    goto :goto_47

    :cond_11
    const-wide/16 v1, 0x0

    cmp-long p2, p0, v1

    if-gtz p2, :cond_1e

    .line 111
    const-string p0, "Z2R/FAlnZ3cfC2Bt"

    invoke-static {p0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    .line 113
    :cond_1e
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object p2

    const-wide v1, 0x174876e800L

    cmp-long v3, p0, v1

    if-lez v3, :cond_2c

    goto :goto_30

    :cond_2c
    const-wide/16 v1, 0x3e8

    mul-long p0, p0, v1

    .line 115
    :goto_30
    invoke-virtual {p2, p0, p1}, Ljava/util/Calendar;->setTimeInMillis(J)V

    .line 116
    new-instance p0, Ljava/text/SimpleDateFormat;

    invoke-static {v0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    sget-object v0, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-direct {p0, p1, v0}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    invoke-virtual {p2}, Ljava/util/Calendar;->getTime()Ljava/util/Date;

    move-result-object p1

    invoke-virtual {p0, p1}, Ljava/text/SimpleDateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    .line 107
    :cond_47
    :goto_47
    new-instance p0, Ljava/text/SimpleDateFormat;

    invoke-static {v0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    sget-object p2, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-direct {p0, p1, p2}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    new-instance p1, Ljava/util/Date;

    invoke-direct {p1}, Ljava/util/Date;-><init>()V

    invoke-virtual {p0, p1}, Ljava/text/SimpleDateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static a(Ljava/lang/String;)Ljava/lang/String;
    .registers 4

    .line 1601
    const-string v0, "t9b/"

    if-eqz p0, :cond_3b

    .line 1602
    invoke-static {v0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_13

    invoke-static {v0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    .line 1603
    :cond_13
    const-string v1, "cQ=="

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p0, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_24

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    .line 1604
    :cond_24
    invoke-virtual {p0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object p0

    const-string v1, "Jyc="

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p0

    if-eqz p0, :cond_3b

    const-string p0, "BydoDQ=="

    invoke-static {p0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0

    .line 1606
    :cond_3b
    invoke-static {v0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 6

    .line 1624
    const-string v0, "BjUwSBg="

    const/4 v1, -0x1

    :try_start_3
    invoke-static {p0, v1}, Ld;->a(Ljava/lang/String;I)I

    move-result p0

    .line 1625
    invoke-static {p1, v1}, Ld;->a(Ljava/lang/String;I)I

    move-result p1

    if-le p0, p1, :cond_3d

    if-lez p0, :cond_3d

    sub-int p1, p0, p1

    int-to-float p1, p1

    int-to-float p0, p0

    div-float/2addr p1, p0

    const/high16 p0, 0x42c80000  # 100.0f

    mul-float p1, p1, p0

    .line 1627
    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p0

    if-lez p0, :cond_3d

    const/16 p1, 0x64

    if-ge p0, p1, :cond_3d

    .line 1629
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-static {v0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {p1, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p0, "cA=="

    invoke-static {p0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_3b
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3b} :catch_3c

    return-object p0

    :catch_3c
    nop

    :cond_3d
    if-eqz p2, :cond_87

    .line 1634
    invoke-virtual {p2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->isEmpty()Z

    move-result p0

    if-nez p0, :cond_87

    .line 1635
    invoke-virtual {p2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    .line 1636
    invoke-virtual {p0}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object p1

    const-string p2, "GhIA"

    invoke-static {p2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p1

    if-eqz p1, :cond_86

    .line 1637
    const-string p1, "fQgiBh18"

    invoke-static {p1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object p1

    invoke-virtual {p1, p0}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object p1

    .line 1638
    invoke-virtual {p1}, Ljava/util/regex/Matcher;->find()Z

    move-result p2

    if-eqz p2, :cond_86

    .line 1639
    new-instance p0, Ljava/lang/StringBuilder;

    invoke-static {v0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-direct {p0, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 p2, 0x1

    invoke-virtual {p1, p2}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    :cond_86
    return-object p0

    :cond_87
    return-object p3
.end method

.method public static a(Landroid/app/Activity;)V
    .registers 11

    if-eqz p0, :cond_79

    .line 341
    invoke-static {p0}, Ld;->e(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_9

    goto :goto_79

    .line 343
    :cond_9
    sget-object v0, Ld;->d:Ljava/lang/String;

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/app/Activity;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    .line 344
    sget-object v2, Ld;->f:Ljava/lang/String;

    const/16 v3, 0x32

    invoke-interface {v0, v2, v3}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v3

    add-int/lit8 v3, v3, -0x1

    .line 345
    invoke-static {v1, v3}, Ljava/lang/Math;->max(II)I

    move-result v1

    .line 346
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    invoke-interface {v3, v2, v1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 348
    new-instance v2, Ld$11;

    invoke-direct {v2, v0, p0, v1}, Ld$11;-><init>(Landroid/content/SharedPreferences;Landroid/app/Activity;I)V

    invoke-virtual {p0, v2}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 370
    invoke-static {}, Le;->v()Ljava/lang/String;

    move-result-object v1

    const-string v2, "ICYtSEE="

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v3, ""

    invoke-interface {v0, v2, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 371
    invoke-static {}, Le;->D()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 372
    invoke-static {}, Le;->E()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 373
    invoke-static {p0}, Le;->c(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v8

    .line 375
    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_6b

    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_6b

    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_79

    .line 376
    :cond_6b
    new-instance v0, Ljava/lang/Thread;

    new-instance v4, Ld$22;

    move-object v9, p0

    invoke-direct/range {v4 .. v9}, Ld$22;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/app/Activity;)V

    invoke-direct {v0, v4}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 395
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    :cond_79
    :goto_79
    return-void
.end method

.method static synthetic a(Landroid/app/Activity;Landroid/app/Dialog;Landroid/view/View;Ljava/lang/String;IIIILandroid/content/SharedPreferences;)V
    .registers 9

    .line 1647
    invoke-static/range {p0 .. p8}, Ld;->b(Landroid/app/Activity;Landroid/app/Dialog;Landroid/view/View;Ljava/lang/String;IIIILandroid/content/SharedPreferences;)V

    return-void
.end method

.method public static a(Landroid/app/Activity;Ljava/lang/Runnable;)V
    .registers 3

    if-eqz p0, :cond_10

    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    move-result v0

    if-nez v0, :cond_10

    if-eqz p1, :cond_10

    invoke-interface {p1}, Ljava/lang/Runnable;->run()V

    :cond_10
    return-void
.end method

.method public static a(Landroid/content/Context;)V
    .registers 9

    if-nez p0, :cond_4

    goto/16 :goto_ee

    .line 126
    :cond_4
    :try_start_4
    sget-object v0, Ld;->d:Ljava/lang/String;

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    .line 127
    invoke-static {}, Le;->q()Ljava/lang/String;

    move-result-object v1

    sget-object v2, Ld;->a:Ljava/lang/String;

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    sget-object v3, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-virtual {v1, v3}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v1

    .line 128
    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2
    :try_end_1f
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_1f} :catch_ee

    const/16 v3, 0xc

    const-string v4, "ZQ=="

    const-string v5, "LC0/VHUYMCJlcDg5"

    const-string v6, ""

    if-eqz v2, :cond_81

    .line 129
    :try_start_29
    invoke-static {}, Le;->u()Ljava/lang/String;

    move-result-object p0

    invoke-interface {v0, p0, v6}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    if-eqz p0, :cond_5d

    .line 131
    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_5d

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_5d

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1
    :try_end_4b
    .catch Ljava/lang/Exception; {:try_start_29 .. :try_end_4b} :catch_ee

    if-eq v1, v3, :cond_4e

    goto :goto_5d

    .line 135
    :cond_4e
    :try_start_4e
    new-instance v1, Ljava/text/SimpleDateFormat;

    invoke-static {v5}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    sget-object v3, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-direct {v1, v2, v3}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    invoke-virtual {v1, p0}, Ljava/text/SimpleDateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;
    :try_end_5c
    .catch Ljava/lang/Exception; {:try_start_4e .. :try_end_5c} :catch_5d

    return-void

    .line 141
    :catch_5d
    :cond_5d
    :goto_5d
    :try_start_5d
    new-instance p0, Ljava/text/SimpleDateFormat;

    invoke-static {v5}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    sget-object v2, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-direct {p0, v1, v2}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    new-instance v1, Ljava/util/Date;

    invoke-direct {v1}, Ljava/util/Date;-><init>()V

    invoke-virtual {p0, v1}, Ljava/text/SimpleDateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object p0

    .line 142
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-static {}, Le;->u()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1, p0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    goto :goto_ee

    .line 146
    :cond_81
    invoke-static {}, Le;->u()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v2, v6}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    if-eqz v2, :cond_c1

    .line 148
    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    move-result v7

    if-nez v7, :cond_c1

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_c1

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v4

    if-eq v4, v3, :cond_a6

    goto :goto_c1

    .line 150
    :cond_a6
    const-string v3, "Z2R/FA=="

    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3
    :try_end_b0
    .catch Ljava/lang/Exception; {:try_start_5d .. :try_end_b0} :catch_ee

    if-nez v3, :cond_ee

    .line 152
    :try_start_b2
    new-instance v3, Ljava/text/SimpleDateFormat;

    invoke-static {v5}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    sget-object v5, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-direct {v3, v4, v5}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    invoke-virtual {v3, v2}, Ljava/text/SimpleDateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;
    :try_end_c0
    .catch Ljava/lang/Exception; {:try_start_b2 .. :try_end_c0} :catch_c1

    return-void

    .line 160
    :catch_c1
    :cond_c1
    :goto_c1
    :try_start_c1
    invoke-static {v2}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v2
    :try_end_c5
    .catch Ljava/lang/Exception; {:try_start_c1 .. :try_end_c5} :catch_c6

    goto :goto_c8

    :catch_c6
    const-wide/16 v2, 0x0

    .line 162
    :goto_c8
    :try_start_c8
    invoke-static {v2, v3, v1}, Ld;->a(JLjava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 163
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    invoke-static {}, Le;->u()Ljava/lang/String;

    move-result-object v4

    invoke-interface {v3, v4, v2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    invoke-interface {v3}, Landroid/content/SharedPreferences$Editor;->commit()Z

    .line 165
    invoke-static {}, Le;->v()Ljava/lang/String;

    move-result-object v3

    invoke-interface {v0, v3, v6}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 166
    sget-object v3, Ld;->a:Ljava/lang/String;

    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_ee

    .line 167
    invoke-static {p0, v1, v2, v0}, Le;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_ee
    .catch Ljava/lang/Exception; {:try_start_c8 .. :try_end_ee} :catch_ee

    :catch_ee
    :cond_ee
    :goto_ee
    return-void
.end method

.method public static a(Landroid/content/Context;Ljava/lang/Runnable;)V
    .registers 12

    if-nez p0, :cond_3

    return-void

    .line 496
    :cond_3
    sget-object v0, Ld;->d:Ljava/lang/String;

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v8

    .line 497
    invoke-static {}, Le;->v()Ljava/lang/String;

    move-result-object v0

    const-string v1, ""

    invoke-interface {v8, v0, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 498
    invoke-static {}, Le;->D()Ljava/lang/String;

    move-result-object v0

    invoke-interface {v8, v0, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 499
    invoke-static {}, Le;->E()Ljava/lang/String;

    move-result-object v0

    invoke-interface {v8, v0, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 500
    invoke-static {p0}, Le;->c(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v6

    .line 502
    new-instance v0, Ljava/lang/Thread;

    new-instance v2, Ld$28;

    move-object v7, p0

    move-object v9, p1

    invoke-direct/range {v2 .. v9}, Ld$28;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;Landroid/content/SharedPreferences;Ljava/lang/Runnable;)V

    invoke-direct {v0, v2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 721
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    return-void
.end method

.method public static a(Landroid/content/Context;Ljava/lang/String;)V
    .registers 5

    invoke-static {}, Le;->aZ()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_e

    invoke-static {}, Le;->n()Ljava/lang/String;

    move-result-object p1

    :cond_e
    if-eqz p0, :cond_4b

    if-eqz p1, :cond_4b

    .line 4054
    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_19

    goto :goto_4b

    .line 4056
    :cond_19
    :try_start_19
    new-instance v0, Landroid/content/Intent;

    const-string v1, "NDoiX1c8MGhEViExKFkWNDcyRFc7ehBkfQI="

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    const/high16 v1, 0x10000000

    .line 4057
    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 4058
    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_30
    .catch Ljava/lang/Exception; {:try_start_19 .. :try_end_30} :catch_31

    return-void

    .line 4060
    :catch_31
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Az01RExvdA=="

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v0, 0x1

    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    :cond_4b
    :goto_4b
    return-void
.end method

.method public static a(Landroid/view/View;Landroid/content/Context;)V
    .registers 4

    if-nez p0, :cond_3

    return-void

    :cond_3
    const/4 v0, 0x0

    .line 889
    invoke-virtual {p0, v0}, Landroid/view/View;->setAlpha(F)V

    const/16 v1, 0x28

    .line 890
    invoke-static {p1, v1}, Ld;->a(Landroid/content/Context;I)I

    move-result p1

    int-to-float p1, p1

    invoke-virtual {p0, p1}, Landroid/view/View;->setTranslationY(F)V

    .line 891
    invoke-virtual {p0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    const/high16 p1, 0x3f800000  # 1.0f

    .line 892
    invoke-virtual {p0, p1}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    .line 893
    invoke-virtual {p0, v0}, Landroid/view/ViewPropertyAnimator;->translationY(F)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    const-wide/16 v0, 0x104

    .line 894
    invoke-virtual {p0, v0, v1}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    .line 895
    new-instance p1, Landroid/view/animation/DecelerateInterpolator;

    const/high16 v0, 0x40000000  # 2.0f

    invoke-direct {p1, v0}, Landroid/view/animation/DecelerateInterpolator;-><init>(F)V

    invoke-virtual {p0, p1}, Landroid/view/ViewPropertyAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    .line 896
    invoke-virtual {p0}, Landroid/view/ViewPropertyAnimator;->start()V

    return-void
.end method

.method public static a(Landroid/view/View;Ljava/lang/Runnable;)V
    .registers 5

    if-nez p0, :cond_8

    if-eqz p1, :cond_7

    .line 905
    invoke-interface {p1}, Ljava/lang/Runnable;->run()V

    :cond_7
    return-void

    .line 908
    :cond_8
    invoke-virtual {p0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    const/4 v1, 0x0

    .line 909
    invoke-virtual {v0, v1}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    const/high16 v1, -0x3f000000  # -8.0f

    .line 910
    invoke-virtual {v0, v1}, Landroid/view/ViewPropertyAnimator;->translationY(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    const-wide/16 v1, 0x50

    .line 911
    invoke-virtual {v0, v1, v2}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    .line 912
    new-instance v1, Ld$30;

    invoke-direct {v1, p1, p0}, Ld$30;-><init>(Ljava/lang/Runnable;Landroid/view/View;)V

    invoke-virtual {v0, v1}, Landroid/view/ViewPropertyAnimator;->withEndAction(Ljava/lang/Runnable;)Landroid/view/ViewPropertyAnimator;

    move-result-object p0

    .line 925
    invoke-virtual {p0}, Landroid/view/ViewPropertyAnimator;->start()V

    return-void
.end method

.method public static applyTactileTouch(Landroid/view/View;)V
    .registers 2

    if-nez p0, :cond_3

    return-void

    .line 1568
    :cond_3
    new-instance v0, Ld$1;

    invoke-direct {v0}, Ld$1;-><init>()V

    invoke-virtual {p0, v0}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    return-void
.end method

.method public static b(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    .registers 12

    .line 3619
    const-string v0, "dmR2FQAWFw=="

    const/high16 v1, 0x40000000  # 2.0f

    :try_start_4
    sget-object v2, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {p1, p1, v2}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v2

    .line 3620
    new-instance v3, Landroid/graphics/Canvas;

    invoke-direct {v3, v2}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    .line 3622
    new-instance v4, Landroid/graphics/Paint;

    const/4 v5, 0x1

    invoke-direct {v4, v5}, Landroid/graphics/Paint;-><init>(I)V

    .line 3623
    invoke-static {v0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    invoke-virtual {v4, v6}, Landroid/graphics/Paint;->setColor(I)V

    int-to-float v6, p1

    div-float v7, v6, v1

    .line 3624
    invoke-virtual {v3, v7, v7, v7, v4}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 3626
    new-instance v4, Landroid/graphics/Paint;

    invoke-direct {v4, v5}, Landroid/graphics/Paint;-><init>(I)V

    const/4 v5, -0x1

    .line 3627
    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setColor(I)V

    .line 3628
    sget-object v5, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/high16 v5, 0x42c80000  # 100.0f

    div-float/2addr v6, v5

    .line 3631
    new-instance v5, Landroid/graphics/Path;

    invoke-direct {v5}, Landroid/graphics/Path;-><init>()V

    const/high16 v7, 0x41c80000  # 25.0f

    mul-float v7, v7, v6

    const/high16 v8, 0x42400000  # 48.0f

    mul-float v8, v8, v6

    .line 3632
    invoke-virtual {v5, v7, v8}, Landroid/graphics/Path;->moveTo(FF)V

    const/high16 v7, 0x42980000  # 76.0f

    mul-float v7, v7, v6

    const/high16 v9, 0x41d00000  # 26.0f

    mul-float v9, v9, v6

    .line 3633
    invoke-virtual {v5, v7, v9}, Landroid/graphics/Path;->lineTo(FF)V

    const/high16 v9, 0x42820000  # 65.0f

    mul-float v9, v9, v6

    .line 3634
    invoke-virtual {v5, v9, v7}, Landroid/graphics/Path;->lineTo(FF)V

    const/high16 v7, 0x427c0000  # 63.0f

    mul-float v7, v7, v6

    .line 3635
    invoke-virtual {v5, v8, v7}, Landroid/graphics/Path;->lineTo(FF)V

    const/high16 v7, 0x421c0000  # 39.0f

    mul-float v7, v7, v6

    const/high16 v8, 0x428e0000  # 71.0f

    mul-float v8, v8, v6

    .line 3636
    invoke-virtual {v5, v7, v8}, Landroid/graphics/Path;->lineTo(FF)V

    const/high16 v7, 0x42240000  # 41.0f

    mul-float v7, v7, v6

    const/high16 v8, 0x42600000  # 56.0f

    mul-float v8, v8, v6

    .line 3637
    invoke-virtual {v5, v7, v8}, Landroid/graphics/Path;->lineTo(FF)V

    const/high16 v7, 0x42880000  # 68.0f

    mul-float v7, v7, v6

    const/high16 v8, 0x42080000  # 34.0f

    mul-float v8, v8, v6

    .line 3638
    invoke-virtual {v5, v7, v8}, Landroid/graphics/Path;->lineTo(FF)V

    const/high16 v7, 0x42040000  # 33.0f

    mul-float v7, v7, v6

    const/high16 v8, 0x42580000  # 54.0f

    mul-float v6, v6, v8

    .line 3639
    invoke-virtual {v5, v7, v6}, Landroid/graphics/Path;->lineTo(FF)V

    .line 3640
    invoke-virtual {v5}, Landroid/graphics/Path;->close()V

    .line 3641
    invoke-virtual {v3, v5, v4}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 3643
    new-instance v3, Landroid/graphics/drawable/BitmapDrawable;

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-direct {v3, p0, v2}, Landroid/graphics/drawable/BitmapDrawable;-><init>(Landroid/content/res/Resources;Landroid/graphics/Bitmap;)V
    :try_end_9b
    .catchall {:try_start_4 .. :try_end_9b} :catchall_9c

    return-object v3

    .line 3645
    :catchall_9c
    new-instance p0, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {p0}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 3646
    invoke-static {v0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {p0, v0}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    int-to-float p1, p1

    div-float/2addr p1, v1

    .line 3647
    invoke-virtual {p0, p1}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    return-object p0
.end method

.method public static b(Landroid/content/Context;II)Landroid/graphics/drawable/Drawable;
    .registers 21

    const/4 v0, 0x0

    if-nez p0, :cond_4

    return-object v0

    .line 1156
    :cond_4
    invoke-static/range {p0 .. p1}, Ld;->a(Landroid/content/Context;I)I

    move-result v1

    if-gtz v1, :cond_c

    const/16 v1, 0x20

    .line 1159
    :cond_c
    :try_start_c
    sget-object v2, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {v1, v1, v2}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v2

    .line 1160
    new-instance v3, Landroid/graphics/Canvas;

    invoke-direct {v3, v2}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    .line 1162
    new-instance v4, Landroid/graphics/Paint;

    const/4 v5, 0x1

    invoke-direct {v4, v5}, Landroid/graphics/Paint;-><init>(I)V

    .line 1163
    sget-object v5, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    move/from16 v5, p2

    .line 1164
    invoke-virtual {v4, v5}, Landroid/graphics/Paint;->setColor(I)V

    int-to-float v1, v1

    const/high16 v5, 0x40000000  # 2.0f

    div-float v5, v1, v5

    const v6, 0x3ee147ae  # 0.44f

    mul-float v1, v1, v6

    const v6, 0x3ed70a3d  # 0.42f

    mul-float v6, v6, v1

    .line 1171
    new-instance v7, Landroid/graphics/Path;

    invoke-direct {v7}, Landroid/graphics/Path;-><init>()V

    const-wide v8, 0x400921fb54442d18L  # Math.PI

    const/4 v10, 0x5

    int-to-double v10, v10

    div-double/2addr v8, v10

    const/4 v10, 0x0

    :goto_44
    const/16 v11, 0xa

    if-lt v10, v11, :cond_58

    .line 1182
    invoke-virtual {v7}, Landroid/graphics/Path;->close()V

    .line 1183
    invoke-virtual {v3, v7, v4}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 1185
    new-instance v1, Landroid/graphics/drawable/BitmapDrawable;

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-direct {v1, v3, v2}, Landroid/graphics/drawable/BitmapDrawable;-><init>(Landroid/content/res/Resources;Landroid/graphics/Bitmap;)V

    return-object v1

    .line 1175
    :cond_58
    rem-int/lit8 v11, v10, 0x2

    if-nez v11, :cond_5e

    move v11, v1

    goto :goto_5f

    :cond_5e
    move v11, v6

    :goto_5f
    int-to-double v12, v10

    mul-double v12, v12, v8

    const-wide v14, 0x3ff921fb54442d18L  # 1.5707963267948966

    sub-double/2addr v12, v14

    float-to-double v14, v11

    .line 1177
    invoke-static {v12, v13}, Ljava/lang/Math;->cos(D)D

    move-result-wide v16
    :try_end_6d
    .catchall {:try_start_c .. :try_end_6d} :catchall_8b

    move-object v11, v0

    move/from16 p1, v1

    mul-double v0, v14, v16

    double-to-float v0, v0

    add-float/2addr v0, v5

    .line 1178
    :try_start_74
    invoke-static {v12, v13}, Ljava/lang/Math;->sin(D)D

    move-result-wide v12

    mul-double v14, v14, v12

    double-to-float v1, v14

    add-float/2addr v1, v5

    if-nez v10, :cond_82

    .line 1179
    invoke-virtual {v7, v0, v1}, Landroid/graphics/Path;->moveTo(FF)V

    goto :goto_85

    .line 1180
    :cond_82
    invoke-virtual {v7, v0, v1}, Landroid/graphics/Path;->lineTo(FF)V
    :try_end_85
    .catchall {:try_start_74 .. :try_end_85} :catchall_8c

    :goto_85
    add-int/lit8 v10, v10, 0x1

    move/from16 v1, p1

    move-object v0, v11

    goto :goto_44

    :catchall_8b
    move-object v11, v0

    :catchall_8c
    return-object v11
.end method

.method public static b(Landroid/content/Context;III)Landroid/graphics/drawable/Drawable;
    .registers 25

    const/4 v0, 0x0

    if-nez p0, :cond_4

    return-object v0

    .line 1104
    :cond_4
    invoke-static/range {p0 .. p1}, Ld;->a(Landroid/content/Context;I)I

    move-result v1

    if-gtz v1, :cond_c

    const/16 v1, 0x20

    .line 1107
    :cond_c
    :try_start_c
    sget-object v2, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {v1, v1, v2}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v2

    .line 1108
    new-instance v3, Landroid/graphics/Canvas;

    invoke-direct {v3, v2}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    int-to-float v1, v1

    const/high16 v4, 0x40000000  # 2.0f

    div-float v5, v1, v4

    const v6, 0x3eeb851f  # 0.46f

    mul-float v6, v6, v1

    const v7, 0x3ec7ae14  # 0.39f

    mul-float v7, v7, v1

    .line 1117
    new-instance v8, Landroid/graphics/Paint;

    const/4 v9, 0x1

    invoke-direct {v8, v9}, Landroid/graphics/Paint;-><init>(I)V

    .line 1118
    sget-object v10, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v8, v10}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    move/from16 v10, p2

    .line 1119
    invoke-virtual {v8, v10}, Landroid/graphics/Paint;->setColor(I)V

    .line 1121
    new-instance v10, Landroid/graphics/Path;

    invoke-direct {v10}, Landroid/graphics/Path;-><init>()V

    const-wide v11, 0x400921fb54442d18L  # Math.PI

    const/16 v13, 0xc

    int-to-double v13, v13

    div-double/2addr v11, v13

    const/4 v13, 0x0

    :goto_45
    const/16 v14, 0x18

    if-lt v13, v14, :cond_a8

    .line 1132
    invoke-virtual {v10}, Landroid/graphics/Path;->close()V

    .line 1133
    invoke-virtual {v3, v10, v8}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 1135
    new-instance v5, Landroid/graphics/Paint;

    invoke-direct {v5, v9}, Landroid/graphics/Paint;-><init>(I)V

    .line 1136
    sget-object v7, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v5, v7}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    move/from16 v14, p3

    .line 1137
    invoke-virtual {v5, v14}, Landroid/graphics/Paint;->setColor(I)V

    const v7, 0x3df5c28f  # 0.12f

    mul-float v7, v7, v1

    .line 1138
    invoke-static {v4, v7}, Ljava/lang/Math;->max(FF)F

    move-result v4

    invoke-virtual {v5, v4}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 1139
    sget-object v4, Landroid/graphics/Paint$Cap;->ROUND:Landroid/graphics/Paint$Cap;

    invoke-virtual {v5, v4}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    .line 1140
    sget-object v4, Landroid/graphics/Paint$Join;->ROUND:Landroid/graphics/Paint$Join;

    invoke-virtual {v5, v4}, Landroid/graphics/Paint;->setStrokeJoin(Landroid/graphics/Paint$Join;)V

    .line 1142
    new-instance v4, Landroid/graphics/Path;

    invoke-direct {v4}, Landroid/graphics/Path;-><init>()V

    const v7, 0x3ea3d70a  # 0.32f

    mul-float v7, v7, v1

    const v8, 0x3f028f5c  # 0.51f

    mul-float v8, v8, v1

    .line 1143
    invoke-virtual {v4, v7, v8}, Landroid/graphics/Path;->moveTo(FF)V

    const v7, 0x3f266666  # 0.65f

    mul-float v7, v7, v1

    .line 1144
    invoke-virtual {v4, v6, v7}, Landroid/graphics/Path;->lineTo(FF)V

    const v6, 0x3f333333  # 0.7f

    mul-float v6, v6, v1

    const v7, 0x3ebd70a4  # 0.37f

    mul-float v1, v1, v7

    .line 1145
    invoke-virtual {v4, v6, v1}, Landroid/graphics/Path;->lineTo(FF)V

    .line 1146
    invoke-virtual {v3, v4, v5}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 1148
    new-instance v1, Landroid/graphics/drawable/BitmapDrawable;

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-direct {v1, v3, v2}, Landroid/graphics/drawable/BitmapDrawable;-><init>(Landroid/content/res/Resources;Landroid/graphics/Bitmap;)V

    return-object v1

    :cond_a8
    move/from16 v14, p3

    .line 1125
    rem-int/lit8 v15, v13, 0x2
    :try_end_ac
    .catchall {:try_start_c .. :try_end_ac} :catchall_f1

    if-nez v15, :cond_b0

    move v15, v6

    goto :goto_b1

    :cond_b0
    move v15, v7

    :goto_b1
    move-object/from16 v16, v0

    move/from16 p1, v1

    int-to-double v0, v13

    mul-double v0, v0, v11

    const-wide v17, 0x3ff921fb54442d18L  # 1.5707963267948966

    sub-double v0, v0, v17

    move/from16 v17, v5

    float-to-double v4, v15

    .line 1127
    :try_start_c2
    invoke-static {v0, v1}, Ljava/lang/Math;->cos(D)D

    move-result-wide v19

    move-object/from16 p2, v10

    mul-double v9, v4, v19

    double-to-float v9, v9

    add-float v9, v17, v9

    .line 1128
    invoke-static {v0, v1}, Ljava/lang/Math;->sin(D)D

    move-result-wide v0

    mul-double v4, v4, v0

    double-to-float v0, v4

    add-float v5, v17, v0

    if-nez v13, :cond_de

    move-object/from16 v0, p2

    .line 1129
    invoke-virtual {v0, v9, v5}, Landroid/graphics/Path;->moveTo(FF)V

    goto :goto_e3

    :cond_de
    move-object/from16 v0, p2

    .line 1130
    invoke-virtual {v0, v9, v5}, Landroid/graphics/Path;->lineTo(FF)V
    :try_end_e3
    .catchall {:try_start_c2 .. :try_end_e3} :catchall_f3

    :goto_e3
    add-int/lit8 v13, v13, 0x1

    move/from16 v1, p1

    move-object v10, v0

    move-object/from16 v0, v16

    move/from16 v5, v17

    const/high16 v4, 0x40000000  # 2.0f

    const/4 v9, 0x1

    goto/16 :goto_45

    :catchall_f1
    move-object/from16 v16, v0

    :catchall_f3
    return-object v16
.end method

.method private static b(Landroid/app/Activity;Landroid/app/Dialog;Ljava/lang/String;IIIILandroid/content/SharedPreferences;)Landroid/view/View;
    .registers 90

    move-object/from16 v8, p0

    move-object/from16 v0, p2

    move-object/from16 v7, p7

    .line 2440
    const-string v1, "NzU1RFsKIyNIUzktGV1KPDcjclczMiNf"

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "t9b/FAE="

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-interface {v7, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 2441
    const-string v1, "NzU1RFsKOSlDTD04P3JIJz0lSGc6MiBISg=="

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "t9b/HwFs"

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-interface {v7, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 2442
    const-string v1, "JSYpck8wMS1BQQokNERbMAspS14wJg=="

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "t9b/HwFs"

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-interface {v7, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 2443
    const-string v1, "JSYpclU6OjJFVCwLNl9RNjEZQl4zMTQ="

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "JSYpckgnPSVIZzoyIEhK"

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v5, "t9b/GgFs"

    invoke-static {v5}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-interface {v7, v2, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-interface {v7, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 2444
    const-string v1, "NjsoWVk2IBlBUTs/"

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    sget-object v2, Ld;->j:Ljava/lang/String;

    invoke-static {}, Le;->n()Ljava/lang/String;

    move-result-object v9

    invoke-interface {v7, v2, v9}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-interface {v7, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v39

    .line 2445
    const-string v1, "ICcjX2cgPSI="

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "ICYtSEE="

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v9, ""

    invoke-interface {v7, v2, v9}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-interface {v7, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v40

    .line 2446
    const-string v1, "ICcjX2cwOSdEVA=="

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, ""

    invoke-interface {v7, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v41

    const/4 v1, 0x1

    .line 2448
    new-array v2, v1, [Z

    const/4 v9, 0x0

    aput-boolean v1, v2, v9

    move-object v10, v2

    .line 2449
    new-array v2, v1, [Z

    .line 2451
    new-instance v11, Landroid/widget/FrameLayout;

    invoke-direct {v11, v8}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    .line 2452
    invoke-static {v8}, Ld;->s(Landroid/content/Context;)Landroid/graphics/drawable/Drawable;

    move-result-object v12

    invoke-virtual {v11, v12}, Landroid/widget/FrameLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2454
    invoke-virtual {v11, v1}, Landroid/widget/FrameLayout;->setClipToOutline(Z)V

    .line 2457
    new-instance v12, Landroid/widget/ScrollView;

    invoke-direct {v12, v8}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    .line 2458
    invoke-virtual {v12, v1}, Landroid/widget/ScrollView;->setFillViewport(Z)V

    .line 2459
    invoke-virtual {v12, v9}, Landroid/widget/ScrollView;->setVerticalScrollBarEnabled(Z)V

    .line 2460
    invoke-virtual {v12, v9}, Landroid/widget/ScrollView;->setBackgroundColor(I)V

    .line 2461
    new-instance v13, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v14, -0x1

    invoke-direct {v13, v14, v14}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v11, v12, v13}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2463
    new-instance v13, Landroid/widget/LinearLayout;

    invoke-direct {v13, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 2464
    invoke-virtual {v13, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v15, 0x10

    .line 2465
    invoke-static {v8, v15}, Ld;->a(Landroid/content/Context;I)I

    move-result v1

    const/16 v14, 0xc

    invoke-static {v8, v14}, Ld;->a(Landroid/content/Context;I)I

    move-result v9

    invoke-static {v8, v15}, Ld;->a(Landroid/content/Context;I)I

    move-result v14

    const/16 v15, 0x1a

    invoke-static {v8, v15}, Ld;->a(Landroid/content/Context;I)I

    move-result v15

    invoke-virtual {v13, v1, v9, v14, v15}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    const/4 v1, 0x0

    .line 2466
    invoke-virtual {v13, v1}, Landroid/widget/LinearLayout;->setBackgroundColor(I)V

    .line 2467
    invoke-virtual {v12, v13}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 2469
    new-instance v9, Landroid/view/View;

    invoke-direct {v9, v8}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 2470
    invoke-static {}, Ld;->d()Landroid/graphics/drawable/Drawable;

    move-result-object v12

    invoke-virtual {v9, v12}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2471
    invoke-virtual {v9, v1}, Landroid/view/View;->setClickable(Z)V

    .line 2472
    invoke-virtual {v9, v1}, Landroid/view/View;->setFocusable(Z)V

    .line 2473
    new-instance v1, Landroid/widget/FrameLayout$LayoutParams;

    const/16 v12, 0x24

    invoke-static {v8, v12}, Ld;->a(Landroid/content/Context;I)I

    move-result v12

    const/4 v14, -0x1

    invoke-direct {v1, v14, v12}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    const/16 v12, 0x30

    .line 2474
    iput v12, v1, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 2475
    invoke-virtual {v11, v9, v1}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2476
    invoke-virtual {v9}, Landroid/view/View;->bringToFront()V

    .line 2478
    new-instance v1, Landroid/view/View;

    invoke-direct {v1, v8}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 2479
    invoke-static {}, Ld;->e()Landroid/graphics/drawable/Drawable;

    move-result-object v9

    invoke-virtual {v1, v9}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 v9, 0x0

    .line 2480
    invoke-virtual {v1, v9}, Landroid/view/View;->setClickable(Z)V

    .line 2481
    invoke-virtual {v1, v9}, Landroid/view/View;->setFocusable(Z)V

    .line 2482
    new-instance v9, Landroid/widget/FrameLayout$LayoutParams;

    const/16 v12, 0x2a

    invoke-static {v8, v12}, Ld;->a(Landroid/content/Context;I)I

    move-result v12

    const/4 v14, -0x1

    invoke-direct {v9, v14, v12}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    const/16 v12, 0x50

    .line 2483
    iput v12, v9, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 2484
    invoke-virtual {v11, v1, v9}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2485
    invoke-virtual {v1}, Landroid/view/View;->bringToFront()V

    .line 2487
    new-instance v1, Landroid/widget/LinearLayout;

    invoke-direct {v1, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v9, 0x1

    .line 2488
    invoke-virtual {v1, v9}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/4 v9, 0x2

    .line 2489
    invoke-static {v8, v9}, Ld;->a(Landroid/content/Context;I)I

    move-result v12

    const/4 v14, 0x6

    invoke-static {v8, v14}, Ld;->a(Landroid/content/Context;I)I

    move-result v15

    const/4 v14, 0x0

    invoke-virtual {v1, v14, v12, v14, v15}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 2490
    new-instance v12, Landroid/view/View;

    invoke-direct {v12, v8}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 2491
    new-instance v14, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v15, 0x26

    invoke-static {v8, v15}, Ld;->a(Landroid/content/Context;I)I

    move-result v15

    const/4 v9, 0x4

    move-object/from16 v20, v2

    invoke-static {v8, v9}, Ld;->a(Landroid/content/Context;I)I

    move-result v2

    invoke-direct {v14, v15, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v12, v14}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 2492
    const-string v2, "dhF0aAATZA=="

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-static {v14}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v14

    const/4 v15, 0x2

    invoke-static {v8, v15}, Ld;->a(Landroid/content/Context;I)I

    move-result v9

    const/4 v15, 0x0

    invoke-static {v14, v9, v15, v15}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v9

    invoke-virtual {v12, v9}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2493
    invoke-virtual {v1, v12}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2494
    invoke-virtual {v13, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2496
    new-instance v1, Landroid/widget/RelativeLayout;

    invoke-direct {v1, v8}, Landroid/widget/RelativeLayout;-><init>(Landroid/content/Context;)V

    const/16 v9, 0x8

    .line 2497
    invoke-static {v8, v9}, Ld;->a(Landroid/content/Context;I)I

    move-result v12

    invoke-virtual {v1, v15, v15, v15, v12}, Landroid/widget/RelativeLayout;->setPadding(IIII)V

    .line 2499
    new-instance v12, Landroid/widget/LinearLayout;

    invoke-direct {v12, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/16 v14, 0x11

    .line 2500
    invoke-virtual {v12, v14}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 2501
    new-instance v15, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v15}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const/4 v14, 0x1

    .line 2502
    invoke-virtual {v15, v14}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    .line 2503
    const-string v23, "dhJ+a3kTFw=="

    invoke-static/range {v23 .. v23}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v23

    invoke-static/range {v23 .. v23}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v9

    invoke-virtual {v15, v9}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 2504
    invoke-static {v8, v14}, Ld;->a(Landroid/content/Context;I)I

    move-result v9

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-static {v14}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v14

    invoke-virtual {v15, v9, v14}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 2505
    invoke-virtual {v12, v15}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2506
    new-instance v9, Landroid/widget/TextView;

    invoke-direct {v9, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 2507
    const-string v14, "t8jT"

    invoke-static {v14}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v9, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2508
    const-string v14, "dmBxGA1jbQ=="

    invoke-static {v14}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-static {v14}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v14

    invoke-virtual {v9, v14}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v14, 0x41600000  # 14.0f

    .line 2509
    invoke-virtual {v9, v14}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v14, 0x0

    const/4 v15, 0x1

    .line 2510
    invoke-virtual {v9, v14, v15}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 2511
    invoke-virtual {v12, v9}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2513
    new-instance v9, Landroid/widget/RelativeLayout$LayoutParams;

    const/16 v15, 0x22

    invoke-static {v8, v15}, Ld;->a(Landroid/content/Context;I)I

    move-result v15

    const/16 v14, 0x22

    invoke-static {v8, v14}, Ld;->a(Landroid/content/Context;I)I

    move-result v14

    invoke-direct {v9, v15, v14}, Landroid/widget/RelativeLayout$LayoutParams;-><init>(II)V

    const/16 v14, 0x14

    .line 2514
    invoke-virtual {v9, v14}, Landroid/widget/RelativeLayout$LayoutParams;->addRule(I)V

    const/16 v14, 0xf

    .line 2515
    invoke-virtual {v9, v14}, Landroid/widget/RelativeLayout$LayoutParams;->addRule(I)V

    .line 2516
    invoke-virtual {v1, v12, v9}, Landroid/widget/RelativeLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2518
    new-instance v9, Landroid/widget/TextView;

    invoke-direct {v9, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 2519
    const-string v14, "Bi0oThgFOCdD"

    invoke-static {v14}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v9, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2520
    const-string v14, "dmN+GwgQFQ=="

    invoke-static {v14}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v15}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v15

    invoke-virtual {v9, v15}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v15, 0x41400000  # 12.0f

    .line 2521
    invoke-virtual {v9, v15}, Landroid/widget/TextView;->setTextSize(F)V

    move-object/from16 v26, v2

    const/4 v2, 0x0

    const/4 v15, 0x1

    .line 2522
    invoke-virtual {v9, v2, v15}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    const/16 v2, 0xa

    .line 2523
    invoke-static {v8, v2}, Ld;->a(Landroid/content/Context;I)I

    move-result v15

    move-object/from16 v27, v4

    const/4 v4, 0x5

    move-object/from16 v28, v6

    invoke-static {v8, v4}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    move-object/from16 v29, v10

    invoke-static {v8, v2}, Ld;->a(Landroid/content/Context;I)I

    move-result v10

    invoke-static {v8, v4}, Ld;->a(Landroid/content/Context;I)I

    move-result v2

    invoke-virtual {v9, v15, v6, v10, v2}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 2524
    const-string v2, "dhJ1awgTEg=="

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    const/16 v6, 0x8

    invoke-static {v8, v6}, Ld;->a(Landroid/content/Context;I)I

    move-result v10

    const/4 v15, 0x1

    invoke-static {v8, v15}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    const-string v15, "dhACaQ4TFg=="

    invoke-static {v15}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v15}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v15

    invoke-static {v2, v10, v6, v15}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    invoke-virtual {v9, v2}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2526
    new-instance v2, Landroid/widget/RelativeLayout$LayoutParams;

    const/4 v6, -0x2

    invoke-direct {v2, v6, v6}, Landroid/widget/RelativeLayout$LayoutParams;-><init>(II)V

    const/16 v10, 0x15

    .line 2527
    invoke-virtual {v2, v10}, Landroid/widget/RelativeLayout$LayoutParams;->addRule(I)V

    const/16 v10, 0xf

    .line 2528
    invoke-virtual {v2, v10}, Landroid/widget/RelativeLayout$LayoutParams;->addRule(I)V

    .line 2529
    invoke-virtual {v1, v9, v2}, Landroid/widget/RelativeLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2530
    invoke-virtual {v13, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2532
    invoke-static {v12}, Ld;->applyTactileTouch(Landroid/view/View;)V

    .line 2533
    invoke-static {v9}, Ld;->applyTactileTouch(Landroid/view/View;)V

    .line 2535
    new-instance v1, Landroid/widget/LinearLayout;

    invoke-direct {v1, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v15, 0x0

    .line 2536
    invoke-virtual {v1, v15}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v2, 0x10

    .line 2537
    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/16 v2, 0xc

    .line 2538
    invoke-static {v8, v2}, Ld;->a(Landroid/content/Context;I)I

    move-result v10

    const/16 v15, 0x9

    invoke-static {v8, v15}, Ld;->a(Landroid/content/Context;I)I

    move-result v15

    invoke-static {v8, v2}, Ld;->a(Landroid/content/Context;I)I

    move-result v4

    const/16 v6, 0x9

    invoke-static {v8, v6}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    invoke-virtual {v1, v10, v15, v4, v6}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 2539
    const-string v4, "dhJ+a3kTFw=="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-static {v8, v2}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    const/4 v15, 0x1

    invoke-static {v8, v15}, Ld;->a(Landroid/content/Context;I)I

    move-result v10

    invoke-static/range {v26 .. v26}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v15}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v15

    invoke-static {v4, v6, v10, v15}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v4

    invoke-virtual {v1, v4}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2540
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v6, -0x1

    const/4 v10, -0x2

    invoke-direct {v4, v6, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 2541
    invoke-static {v8, v2}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    iput v6, v4, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 2542
    invoke-virtual {v13, v1, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2544
    new-instance v2, Landroid/view/View;

    invoke-direct {v2, v8}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 2545
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v6, 0x8

    invoke-static {v8, v6}, Ld;->a(Landroid/content/Context;I)I

    move-result v10

    invoke-static {v8, v6}, Ld;->a(Landroid/content/Context;I)I

    move-result v15

    invoke-direct {v4, v10, v15}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v4}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 2546
    new-instance v4, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v4}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const/4 v15, 0x1

    .line 2547
    invoke-virtual {v4, v15}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    .line 2548
    sget-object v6, Ld;->c:Ljava/lang/String;

    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    const-string v15, "dmV2bwFtZQ=="

    if-eqz v10, :cond_316

    .line 2549
    invoke-static {v14}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v10

    invoke-virtual {v4, v10}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    goto :goto_337

    .line 2550
    :cond_316
    sget-object v10, Ld;->b:Ljava/lang/String;

    invoke-virtual {v10, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_32c

    .line 2551
    const-string v10, "dmR+FAkXZg=="

    invoke-static {v10}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v10

    invoke-virtual {v4, v10}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    goto :goto_337

    .line 2553
    :cond_32c
    invoke-static {v15}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v10

    invoke-virtual {v4, v10}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 2555
    :goto_337
    invoke-virtual {v2, v4}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2556
    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v4

    check-cast v4, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v33, v9

    const/16 v10, 0x8

    .line 2557
    invoke-static {v8, v10}, Ld;->a(Landroid/content/Context;I)I

    move-result v9

    iput v9, v4, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    .line 2558
    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2560
    new-instance v4, Landroid/widget/TextView;

    invoke-direct {v4, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 2561
    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_35f

    const-string v9, "BSYpDW4cBA=="

    :goto_35a
    invoke-static {v9}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    goto :goto_36d

    :cond_35f
    sget-object v9, Ld;->b:Ljava/lang/String;

    invoke-virtual {v9, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_36a

    const-string v9, "FzU1RFt1Ag99"

    goto :goto_35a

    :cond_36a
    const-string v9, "EyYjSBgFOCdD"

    goto :goto_35a

    :goto_36d
    invoke-virtual {v4, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2562
    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_37f

    invoke-static {v14}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    :goto_37a
    invoke-static {v9}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v9

    goto :goto_391

    :cond_37f
    sget-object v9, Ld;->b:Ljava/lang/String;

    invoke-virtual {v9, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_38a

    const-string v9, "dmR+FAkXZg=="

    goto :goto_38c

    :cond_38a
    const-string v9, "dmUDHHphFg=="

    :goto_38c
    invoke-static {v9}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    goto :goto_37a

    :goto_391
    invoke-virtual {v4, v9}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v9, 0x41300000  # 11.0f

    .line 2563
    invoke-virtual {v4, v9}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v9, 0x1

    const/4 v10, 0x0

    .line 2564
    invoke-virtual {v4, v10, v9}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 2565
    invoke-virtual {v1, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2567
    new-instance v9, Landroid/widget/TextView;

    invoke-direct {v9, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 2568
    new-instance v10, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v34, v2

    const/high16 v2, 0x3f800000  # 1.0f

    move-object/from16 v35, v4

    move-object/from16 v36, v11

    const/4 v4, 0x0

    const/4 v11, -0x2

    invoke-direct {v10, v4, v11, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const v4, 0x800005

    .line 2569
    invoke-virtual {v9, v4}, Landroid/widget/TextView;->setGravity(I)V

    .line 2570
    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const-string v6, "dmJyGgxtFg=="

    if-nez v4, :cond_3fb

    sget-object v4, Ld;->b:Ljava/lang/String;

    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_3cf

    goto :goto_3fb

    .line 2574
    :cond_3cf
    new-instance v4, Ljava/lang/StringBuilder;

    const-string v10, "t9TkDQ=="

    invoke-static {v10}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-direct {v4, v10}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    move/from16 v10, p3

    invoke-virtual {v4, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v10, "dRgjS0w="

    invoke-static {v10}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v4, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v9, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2575
    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v9, v4}, Landroid/widget/TextView;->setTextColor(I)V

    goto :goto_40f

    .line 2571
    :cond_3fb
    :goto_3fb
    const-string v4, "t9TkDW07OC9AUSExIg=="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v9, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2572
    invoke-static {v15}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v9, v4}, Landroid/widget/TextView;->setTextColor(I)V

    :goto_40f
    const/high16 v4, 0x41300000  # 11.0f

    .line 2577
    invoke-virtual {v9, v4}, Landroid/widget/TextView;->setTextSize(F)V

    .line 2578
    invoke-virtual {v1, v9}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2580
    new-instance v1, Landroid/widget/LinearLayout;

    invoke-direct {v1, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v4, 0x1

    .line 2581
    invoke-virtual {v1, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 2582
    invoke-virtual {v1, v4}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/16 v4, 0xe

    .line 2583
    invoke-static {v8, v4}, Ld;->a(Landroid/content/Context;I)I

    move-result v10

    const/4 v11, 0x0

    invoke-virtual {v1, v11, v11, v11, v10}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 2585
    new-instance v10, Landroid/widget/LinearLayout;

    invoke-direct {v10, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 2586
    invoke-virtual {v10, v11}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v11, 0x10

    .line 2587
    invoke-virtual {v10, v11}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/16 v11, 0xc

    .line 2588
    invoke-static {v8, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v4

    move-object/from16 v38, v6

    const/4 v2, 0x4

    invoke-static {v8, v2}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    move-object/from16 v42, v9

    invoke-static {v8, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v9

    invoke-static {v8, v2}, Ld;->a(Landroid/content/Context;I)I

    move-result v11

    invoke-virtual {v10, v4, v6, v9, v11}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 2589
    const-string v2, "dhJ1awgTEg=="

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    const/16 v11, 0xc

    invoke-static {v8, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v4

    const/4 v9, 0x1

    invoke-static {v8, v9}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    const-string v9, "dhECaAETEQ=="

    invoke-static {v9}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v9

    invoke-static {v2, v4, v6, v9}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    invoke-virtual {v10, v2}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2590
    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 2591
    const-string v4, "Ax0WDWgUBxU="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2592
    invoke-static {v14}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v4, 0x41200000  # 10.0f

    .line 2593
    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v6, 0x0

    const/4 v9, 0x1

    .line 2594
    invoke-virtual {v2, v6, v9}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 2595
    invoke-static {v14}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v9

    const/16 v11, 0xc

    invoke-static {v8, v11, v9}, Ld;->b(Landroid/content/Context;II)Landroid/graphics/drawable/Drawable;

    move-result-object v9

    invoke-virtual {v2, v9, v6, v6, v6}, Landroid/widget/TextView;->setCompoundDrawablesWithIntrinsicBounds(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    const/4 v6, 0x5

    .line 2596
    invoke-static {v8, v6}, Ld;->a(Landroid/content/Context;I)I

    move-result v9

    invoke-virtual {v2, v9}, Landroid/widget/TextView;->setCompoundDrawablePadding(I)V

    .line 2597
    invoke-virtual {v10, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2598
    invoke-virtual {v1, v10}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2600
    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 2601
    const-string v6, "Ezs+DXkcdBBkaA=="

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2602
    const-string v6, "dmQAHA9nFQ=="

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    invoke-virtual {v2, v6}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v6, 0x41b80000  # 23.0f

    .line 2603
    invoke-virtual {v2, v6}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v9, 0x1

    const/4 v10, 0x0

    .line 2604
    invoke-virtual {v2, v10, v9}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    const/4 v6, 0x6

    .line 2605
    invoke-static {v8, v6}, Ld;->a(Landroid/content/Context;I)I

    move-result v9

    const/4 v11, 0x0

    invoke-virtual {v2, v11, v9, v11, v11}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 2606
    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2608
    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 2609
    const-string v6, "HT0hRRgUNyVYSjQ3Pw0edRIqQlkhPShKGB0BAg=="

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2610
    invoke-static/range {v38 .. v38}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    invoke-virtual {v2, v6}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v6, 0x41400000  # 12.0f

    .line 2611
    invoke-virtual {v2, v6}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v6, 0x3

    .line 2612
    invoke-static {v8, v6}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    const/4 v11, 0x0

    invoke-virtual {v2, v11, v6, v11, v11}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 2613
    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2614
    invoke-virtual {v13, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2616
    new-instance v1, Landroid/widget/LinearLayout;

    invoke-direct {v1, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 2617
    invoke-virtual {v1, v11}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 2618
    const-string v2, "dhJ3aw0TbQ=="

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    const/16 v6, 0xc

    invoke-static {v8, v6}, Ld;->a(Landroid/content/Context;I)I

    move-result v9

    invoke-static {v2, v9, v11, v11}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 v2, 0x4

    .line 2619
    invoke-static {v8, v2}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    invoke-static {v8, v2}, Ld;->a(Landroid/content/Context;I)I

    move-result v9

    invoke-static {v8, v2}, Ld;->a(Landroid/content/Context;I)I

    move-result v10

    invoke-static {v8, v2}, Ld;->a(Landroid/content/Context;I)I

    move-result v11

    invoke-virtual {v1, v6, v9, v10, v11}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 2620
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v6, 0x30

    invoke-static {v8, v6}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    const/4 v9, -0x1

    invoke-direct {v2, v9, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v11, 0x10

    .line 2621
    invoke-static {v8, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    iput v6, v2, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 2622
    invoke-virtual {v13, v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2624
    new-instance v10, Landroid/widget/LinearLayout;

    invoke-direct {v10, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 2625
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v6, 0x3f800000  # 1.0f

    const/4 v11, 0x0

    invoke-direct {v2, v11, v9, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v10, v2}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/16 v2, 0x11

    .line 2626
    invoke-virtual {v10, v2}, Landroid/widget/LinearLayout;->setGravity(I)V

    move-object v2, v12

    .line 2627
    new-instance v12, Landroid/widget/TextView;

    invoke-direct {v12, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 2628
    const-string v6, "FzU1RFs="

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v12, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/high16 v6, 0x41400000  # 12.0f

    .line 2629
    invoke-virtual {v12, v6}, Landroid/widget/TextView;->setTextSize(F)V

    .line 2630
    invoke-static/range {v38 .. v38}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    invoke-virtual {v12, v6}, Landroid/widget/TextView;->setTextColor(I)V

    .line 2631
    invoke-virtual {v10, v12}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2632
    invoke-virtual {v1, v10}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2634
    new-instance v9, Landroid/widget/LinearLayout;

    invoke-direct {v9, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 2635
    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v44, v2

    const/4 v2, -0x1

    const/4 v4, 0x0

    const/high16 v11, 0x3f800000  # 1.0f

    invoke-direct {v6, v4, v2, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v9, v6}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/16 v2, 0x11

    .line 2636
    invoke-virtual {v9, v2}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 2637
    new-instance v11, Landroid/widget/TextView;

    invoke-direct {v11, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 2638
    const-string v2, "BSYpDW4cBA=="

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v11, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/high16 v6, 0x41400000  # 12.0f

    .line 2639
    invoke-virtual {v11, v6}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v2, 0x0

    const/4 v4, 0x1

    .line 2640
    invoke-virtual {v11, v2, v4}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 2641
    invoke-static {v14}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v11, v2}, Landroid/widget/TextView;->setTextColor(I)V

    const/16 v6, 0x8

    .line 2642
    invoke-static {v8, v6}, Ld;->a(Landroid/content/Context;I)I

    move-result v2

    invoke-static {v8, v4}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    invoke-static/range {v26 .. v26}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v45

    invoke-static/range {v45 .. v45}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    move-object/from16 v45, v10

    const/4 v10, -0x1

    invoke-static {v10, v2, v6, v4}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    invoke-virtual {v9, v2}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2643
    invoke-virtual {v9, v11}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2644
    invoke-virtual {v1, v9}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2646
    invoke-static/range {v45 .. v45}, Ld;->applyTactileTouch(Landroid/view/View;)V

    .line 2647
    invoke-static {v9}, Ld;->applyTactileTouch(Landroid/view/View;)V

    .line 2649
    new-instance v1, Landroid/widget/LinearLayout;

    invoke-direct {v1, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v4, 0x1

    .line 2650
    invoke-virtual {v1, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v2, 0x16

    .line 2651
    invoke-static {v8, v2}, Ld;->a(Landroid/content/Context;I)I

    move-result v2

    invoke-static {v8, v4}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    invoke-static/range {v26 .. v26}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v10

    const/4 v4, -0x1

    invoke-static {v4, v2, v6, v10}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 v2, 0x1

    .line 2653
    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setClipToOutline(Z)V

    const/16 v2, 0x10

    .line 2655
    invoke-static {v8, v2}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    const/4 v10, 0x0

    invoke-virtual {v1, v10, v10, v10, v6}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 2656
    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v10, -0x2

    invoke-direct {v6, v4, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 2657
    invoke-static {v8, v2}, Ld;->a(Landroid/content/Context;I)I

    move-result v10

    iput v10, v6, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 2658
    invoke-virtual {v13, v1, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2660
    new-instance v2, Landroid/view/View;

    invoke-direct {v2, v8}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 2661
    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v10, 0x44

    invoke-static {v8, v10}, Ld;->a(Landroid/content/Context;I)I

    move-result v10

    invoke-direct {v6, v4, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v6}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 2662
    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2664
    new-instance v6, Landroid/widget/RelativeLayout;

    invoke-direct {v6, v8}, Landroid/widget/RelativeLayout;-><init>(Landroid/content/Context;)V

    .line 2665
    new-instance v10, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v46, v2

    const/4 v2, -0x2

    invoke-direct {v10, v4, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v6, v10}, Landroid/widget/RelativeLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 2666
    invoke-virtual {v6}, Landroid/widget/RelativeLayout;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    check-cast v2, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v4, 0x18

    .line 2667
    invoke-static {v8, v4}, Ld;->a(Landroid/content/Context;I)I

    move-result v4

    neg-int v4, v4

    iput v4, v2, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    const/16 v2, 0x10

    .line 2668
    invoke-static {v8, v2}, Ld;->a(Landroid/content/Context;I)I

    move-result v4

    invoke-static {v8, v2}, Ld;->a(Landroid/content/Context;I)I

    move-result v10

    const/4 v2, 0x0

    invoke-virtual {v6, v4, v2, v10, v2}, Landroid/widget/RelativeLayout;->setPadding(IIII)V

    .line 2670
    new-instance v2, Landroid/widget/FrameLayout;

    invoke-direct {v2, v8}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    .line 2671
    new-instance v4, Landroid/widget/RelativeLayout$LayoutParams;

    const/16 v10, 0x30

    invoke-static {v8, v10}, Ld;->a(Landroid/content/Context;I)I

    move-result v10

    move-object/from16 v47, v9

    const/16 v9, 0x30

    invoke-static {v8, v9}, Ld;->a(Landroid/content/Context;I)I

    move-result v9

    invoke-direct {v4, v10, v9}, Landroid/widget/RelativeLayout$LayoutParams;-><init>(II)V

    const/16 v9, 0x14

    .line 2672
    invoke-virtual {v4, v9}, Landroid/widget/RelativeLayout$LayoutParams;->addRule(I)V

    .line 2673
    invoke-virtual {v2, v4}, Landroid/widget/FrameLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/16 v4, 0x18

    .line 2674
    invoke-static {v8, v4}, Ld;->a(Landroid/content/Context;I)I

    move-result v4

    const/high16 v9, 0x40200000  # 2.5f

    invoke-static {v8, v9}, Ld;->a(Landroid/content/Context;F)I

    move-result v9

    invoke-static {v14}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v10

    move-object/from16 v48, v11

    const/4 v11, -0x1

    invoke-static {v11, v4, v9, v10}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/FrameLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 v9, 0x1

    .line 2676
    invoke-virtual {v2, v9}, Landroid/widget/FrameLayout;->setClipToOutline(Z)V

    .line 2679
    new-instance v4, Landroid/widget/ImageView;

    invoke-direct {v4, v8}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 2682
    :try_start_6cb
    const-string v9, "MiQ="

    invoke-static {v9}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const/4 v11, 0x0

    invoke-virtual {v8, v9, v11}, Landroid/app/Activity;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v9

    if-eqz v9, :cond_6e5

    .line 2683
    const-string v10, "JSYpS1E5MQ=="

    invoke-static {v10}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    const-string v11, ""

    invoke-interface {v9, v10, v11}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    goto :goto_6e7

    :cond_6e5
    const-string v9, ""

    :goto_6e7
    if-eqz v9, :cond_718

    .line 2684
    invoke-virtual {v9}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/String;->isEmpty()Z

    move-result v10

    if-nez v10, :cond_718

    .line 2685
    sget-object v10, Landroid/widget/ImageView$ScaleType;->CENTER_CROP:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v4, v10}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    const/4 v11, 0x0

    .line 2686
    invoke-virtual {v4, v11, v11, v11, v11}, Landroid/widget/ImageView;->setPadding(IIII)V

    .line 2687
    invoke-virtual {v8}, Landroid/app/Activity;->getApplicationContext()Landroid/content/Context;

    move-result-object v10

    invoke-static {v10}, Lcom/bumptech/glide/Glide;->with(Landroid/content/Context;)Lcom/bumptech/glide/RequestManager;

    move-result-object v10

    invoke-virtual {v9}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v9

    invoke-virtual {v10, v9}, Lcom/bumptech/glide/RequestManager;->load(Landroid/net/Uri;)Lcom/bumptech/glide/RequestBuilder;

    move-result-object v9

    invoke-virtual {v9, v4}, Lcom/bumptech/glide/RequestBuilder;->into(Landroid/widget/ImageView;)Lcom/bumptech/glide/request/target/ViewTarget;
    :try_end_713
    .catchall {:try_start_6cb .. :try_end_713} :catchall_718

    move-object/from16 v49, v12

    move-object/from16 v50, v14

    goto :goto_753

    .line 2693
    :catchall_718
    :cond_718
    sget-object v9, Landroid/widget/ImageView$ScaleType;->CENTER_INSIDE:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v4, v9}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    const/16 v10, 0x8

    .line 2694
    invoke-static {v8, v10}, Ld;->a(Landroid/content/Context;I)I

    move-result v9

    invoke-static {v8, v10}, Ld;->a(Landroid/content/Context;I)I

    move-result v11

    move-object/from16 v49, v12

    invoke-static {v8, v10}, Ld;->a(Landroid/content/Context;I)I

    move-result v12

    move-object/from16 v50, v14

    invoke-static {v8, v10}, Ld;->a(Landroid/content/Context;I)I

    move-result v14

    invoke-virtual {v4, v9, v11, v12, v14}, Landroid/widget/ImageView;->setPadding(IIII)V

    .line 2695
    const-string v9, "dhJzFH1lFg=="

    invoke-static {v9}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v9

    const-string v10, "dhIDawhtFQ=="

    invoke-static {v10}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v10

    const/16 v11, 0x1c

    invoke-static {v8, v11, v9, v10}, Ld;->a(Landroid/content/Context;III)Landroid/graphics/drawable/Drawable;

    move-result-object v9

    invoke-virtual {v4, v9}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 2697
    :goto_753
    new-instance v9, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v14, -0x1

    invoke-direct {v9, v14, v14}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v4, v9}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2698
    invoke-virtual {v6, v2}, Landroid/widget/RelativeLayout;->addView(Landroid/view/View;)V

    .line 2699
    invoke-static {v2}, Ld;->applyTactileTouch(Landroid/view/View;)V

    .line 2701
    new-instance v9, Landroid/widget/LinearLayout;

    invoke-direct {v9, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v11, 0x0

    .line 2702
    invoke-virtual {v9, v11}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v11, 0x10

    .line 2703
    invoke-virtual {v9, v11}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/16 v10, 0x8

    .line 2704
    invoke-static {v8, v10}, Ld;->a(Landroid/content/Context;I)I

    move-result v11

    const/4 v10, 0x4

    invoke-static {v8, v10}, Ld;->a(Landroid/content/Context;I)I

    move-result v12

    move-object/from16 v51, v2

    const/16 v14, 0xa

    invoke-static {v8, v14}, Ld;->a(Landroid/content/Context;I)I

    move-result v2

    invoke-static {v8, v10}, Ld;->a(Landroid/content/Context;I)I

    move-result v14

    invoke-virtual {v9, v11, v12, v2, v14}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 2705
    const-string v2, "dhJ+a3kTFw=="

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    const/16 v11, 0xc

    invoke-static {v8, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v10

    const/4 v14, 0x1

    invoke-static {v8, v14}, Ld;->a(Landroid/content/Context;I)I

    move-result v11

    invoke-static/range {v26 .. v26}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-static {v12}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v12

    invoke-static {v2, v10, v11, v12}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    invoke-virtual {v9, v2}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2706
    new-instance v2, Landroid/widget/RelativeLayout$LayoutParams;

    const/4 v10, -0x2

    invoke-direct {v2, v10, v10}, Landroid/widget/RelativeLayout$LayoutParams;-><init>(II)V

    const/16 v10, 0x15

    .line 2707
    invoke-virtual {v2, v10}, Landroid/widget/RelativeLayout$LayoutParams;->addRule(I)V

    const/16 v10, 0xf

    .line 2708
    invoke-virtual {v2, v10}, Landroid/widget/RelativeLayout$LayoutParams;->addRule(I)V

    .line 2709
    invoke-virtual {v6, v9, v2}, Landroid/widget/RelativeLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2711
    new-instance v2, Landroid/view/View;

    invoke-direct {v2, v8}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 2712
    new-instance v10, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v11, 0x6

    invoke-static {v8, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v12

    invoke-static {v8, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v14

    invoke-direct {v10, v12, v14}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v10}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 2713
    new-instance v10, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v10}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const/4 v14, 0x1

    .line 2714
    invoke-virtual {v10, v14}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    .line 2715
    invoke-static {v15}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-static {v11}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v11

    invoke-virtual {v10, v11}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 2716
    invoke-virtual {v2, v10}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2717
    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v10

    check-cast v10, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v11, 0x5

    .line 2718
    invoke-static {v8, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v12

    iput v12, v10, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    .line 2719
    invoke-virtual {v9, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2721
    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 2722
    const-string v10, "bWFjBhgZPTBI"

    invoke-static {v10}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v2, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2723
    invoke-static {v15}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v10

    invoke-virtual {v2, v10}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v10, 0x41200000  # 10.0f

    .line 2724
    invoke-virtual {v2, v10}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v10, 0x0

    const/4 v14, 0x1

    .line 2725
    invoke-virtual {v2, v10, v14}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 2726
    invoke-virtual {v9, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2728
    invoke-virtual {v1, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2730
    new-instance v6, Landroid/widget/LinearLayout;

    invoke-direct {v6, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 2731
    invoke-virtual {v6, v14}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v11, 0x10

    .line 2732
    invoke-static {v8, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v9

    const/16 v10, 0x8

    invoke-static {v8, v10}, Ld;->a(Landroid/content/Context;I)I

    move-result v12

    invoke-static {v8, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v10

    const/4 v14, 0x0

    invoke-virtual {v6, v9, v12, v10, v14}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 2733
    invoke-virtual {v1, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2735
    new-instance v9, Landroid/widget/LinearLayout;

    invoke-direct {v9, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 2736
    invoke-virtual {v9, v14}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 2737
    invoke-virtual {v9, v11}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 2739
    new-instance v14, Landroid/widget/TextView;

    invoke-direct {v14, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 2740
    const-string v10, "BSYpDW4cBA=="

    invoke-static {v10}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v14, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2741
    const-string v10, "dmQAHA9nFQ=="

    invoke-static {v10}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v10

    invoke-virtual {v14, v10}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v10, 0x41880000  # 17.0f

    .line 2742
    invoke-virtual {v14, v10}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v10, 0x1

    const/4 v11, 0x0

    .line 2743
    invoke-virtual {v14, v11, v10}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 2744
    invoke-virtual {v9, v14}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2746
    new-instance v10, Landroid/widget/ImageView;

    invoke-direct {v10, v8}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 2747
    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v52, v1

    const/16 v12, 0x10

    invoke-static {v8, v12}, Ld;->a(Landroid/content/Context;I)I

    move-result v1

    move-object/from16 v53, v2

    invoke-static {v8, v12}, Ld;->a(Landroid/content/Context;I)I

    move-result v2

    invoke-direct {v11, v1, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/4 v1, 0x6

    .line 2748
    invoke-static {v8, v1}, Ld;->a(Landroid/content/Context;I)I

    move-result v2

    iput v2, v11, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    .line 2749
    iput v12, v11, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    .line 2750
    invoke-virtual {v10, v11}, Landroid/widget/ImageView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 2751
    sget-object v1, Landroid/widget/ImageView$ScaleType;->CENTER_INSIDE:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v10, v1}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    .line 2752
    invoke-static/range {v50 .. v50}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    const/4 v11, -0x1

    invoke-static {v8, v12, v1, v11}, Ld;->b(Landroid/content/Context;III)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    invoke-virtual {v10, v1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 2753
    invoke-virtual {v9, v10}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2755
    new-instance v1, Landroid/view/View;

    invoke-direct {v1, v8}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 2756
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v54, v4

    const/4 v4, 0x0

    const/high16 v11, 0x3f800000  # 1.0f

    const/4 v12, 0x1

    invoke-direct {v2, v4, v12, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v9, v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2758
    new-instance v1, Landroid/widget/TextView;

    invoke-direct {v1, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 2759
    const-string v2, "ABoKYnseEQI="

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2760
    invoke-static/range {v50 .. v50}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v2, 0x41200000  # 10.0f

    .line 2761
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v2, 0x0

    .line 2762
    invoke-virtual {v1, v2, v12}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    const/16 v2, 0x9

    .line 2763
    invoke-static {v8, v2}, Ld;->a(Landroid/content/Context;I)I

    move-result v2

    const/4 v4, 0x3

    invoke-static {v8, v4}, Ld;->a(Landroid/content/Context;I)I

    move-result v4

    const/16 v11, 0x9

    invoke-static {v8, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v11

    const/4 v12, 0x3

    invoke-static {v8, v12}, Ld;->a(Landroid/content/Context;I)I

    move-result v12

    invoke-virtual {v1, v2, v4, v11, v12}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 2764
    const-string v2, "dhECaAETEQ=="

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    const/16 v4, 0x8

    invoke-static {v8, v4}, Ld;->a(Landroid/content/Context;I)I

    move-result v11

    const/4 v4, 0x0

    invoke-static {v2, v11, v4, v4}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2765
    invoke-virtual {v9, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2766
    invoke-virtual {v6, v9}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    move-object v2, v15

    .line 2768
    new-instance v15, Landroid/widget/TextView;

    invoke-direct {v15, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 2769
    const-string v4, "FDgqDV07My9DXSZ4ZkVRMjxmWlE7JidZXXVyZktUOjUyRFYydA54fA=="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v15, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2770
    invoke-static/range {v38 .. v38}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v15, v4}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v4, 0x41400000  # 12.0f

    .line 2771
    invoke-virtual {v15, v4}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v4, 0x2

    .line 2772
    invoke-static {v8, v4}, Ld;->a(Landroid/content/Context;I)I

    move-result v9

    const/16 v4, 0xa

    invoke-static {v8, v4}, Ld;->a(Landroid/content/Context;I)I

    move-result v11

    const/4 v12, 0x0

    invoke-virtual {v15, v12, v9, v12, v11}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 2773
    invoke-virtual {v6, v15}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2775
    new-instance v9, Landroid/widget/LinearLayout;

    invoke-direct {v9, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 2776
    invoke-virtual {v9, v12}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v11, 0x10

    .line 2777
    invoke-virtual {v9, v11}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 2778
    invoke-static {v8, v4}, Ld;->a(Landroid/content/Context;I)I

    move-result v11

    invoke-static {v8, v4}, Ld;->a(Landroid/content/Context;I)I

    move-result v12

    move-object/from16 v55, v1

    invoke-static {v8, v4}, Ld;->a(Landroid/content/Context;I)I

    move-result v1

    move-object/from16 v56, v2

    invoke-static {v8, v4}, Ld;->a(Landroid/content/Context;I)I

    move-result v2

    invoke-virtual {v9, v11, v12, v1, v2}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 2779
    const-string v1, "dhJ+a3kTFw=="

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    const/16 v2, 0xe

    invoke-static {v8, v2}, Ld;->a(Landroid/content/Context;I)I

    move-result v4

    const/4 v12, 0x1

    invoke-static {v8, v12}, Ld;->a(Landroid/content/Context;I)I

    move-result v2

    invoke-static/range {v26 .. v26}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-static {v11}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v11

    invoke-static {v1, v4, v2, v11}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v1

    invoke-virtual {v9, v1}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2780
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, -0x2

    const/4 v11, -0x1

    invoke-direct {v1, v11, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v11, 0xc

    .line 2781
    invoke-static {v8, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v4

    iput v4, v1, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 2782
    invoke-virtual {v6, v9, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2783
    invoke-static {v9}, Ld;->applyTactileTouch(Landroid/view/View;)V

    .line 2785
    new-instance v1, Landroid/widget/LinearLayout;

    invoke-direct {v1, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 2786
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v11, 0x3f800000  # 1.0f

    const/4 v12, 0x0

    invoke-direct {v4, v12, v2, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v1, v4}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v4, 0x1

    .line 2787
    invoke-virtual {v1, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v2, 0x11

    .line 2788
    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 2789
    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 2790
    const-string v4, "bWFjBg=="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2791
    const-string v4, "dmQAHA9nFQ=="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v4, 0x41500000  # 13.0f

    .line 2792
    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v4, 0x1

    const/4 v11, 0x0

    .line 2793
    invoke-virtual {v2, v11, v4}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 2794
    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2795
    new-instance v4, Landroid/widget/TextView;

    invoke-direct {v4, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 2796
    const-string v11, "NDclWEo0Nz8="

    invoke-static {v11}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v4, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2797
    const-string v11, "dm1ybAsXbA=="

    invoke-static {v11}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-static {v11}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v11

    invoke-virtual {v4, v11}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v11, 0x41200000  # 10.0f

    .line 2798
    invoke-virtual {v4, v11}, Landroid/widget/TextView;->setTextSize(F)V

    .line 2799
    invoke-virtual {v1, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2800
    invoke-virtual {v9, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2802
    new-instance v1, Landroid/view/View;

    invoke-direct {v1, v8}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 2803
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v12, 0x1

    invoke-static {v8, v12}, Ld;->a(Landroid/content/Context;I)I

    move-result v11

    const/16 v12, 0x18

    invoke-static {v8, v12}, Ld;->a(Landroid/content/Context;I)I

    move-result v12

    invoke-direct {v4, v11, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v4}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 2804
    invoke-static/range {v26 .. v26}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v1, v4}, Landroid/view/View;->setBackgroundColor(I)V

    .line 2805
    invoke-virtual {v9, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2807
    new-instance v1, Landroid/widget/LinearLayout;

    invoke-direct {v1, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 2808
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v57, v2

    const/4 v2, -0x2

    const/high16 v11, 0x3f800000  # 1.0f

    const/4 v12, 0x0

    invoke-direct {v4, v12, v2, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v1, v4}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v4, 0x1

    .line 2809
    invoke-virtual {v1, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v2, 0x11

    .line 2810
    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 2811
    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 2812
    const-string v4, "t9b/Hw56MCdU"

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2813
    const-string v4, "dmQAHA9nFQ=="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v4, 0x41500000  # 13.0f

    .line 2814
    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v4, 0x1

    const/4 v11, 0x0

    .line 2815
    invoke-virtual {v2, v11, v4}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 2816
    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2817
    new-instance v4, Landroid/widget/TextView;

    invoke-direct {v4, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 2818
    const-string v11, "MTUvQUF1NyleTA=="

    invoke-static {v11}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v4, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2819
    const-string v11, "dm1ybAsXbA=="

    invoke-static {v11}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-static {v11}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v11

    invoke-virtual {v4, v11}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v11, 0x41200000  # 10.0f

    .line 2820
    invoke-virtual {v4, v11}, Landroid/widget/TextView;->setTextSize(F)V

    .line 2821
    invoke-virtual {v1, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2822
    invoke-virtual {v9, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2824
    new-instance v1, Landroid/view/View;

    invoke-direct {v1, v8}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 2825
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v12, 0x1

    invoke-static {v8, v12}, Ld;->a(Landroid/content/Context;I)I

    move-result v11

    const/16 v12, 0x18

    invoke-static {v8, v12}, Ld;->a(Landroid/content/Context;I)I

    move-result v12

    invoke-direct {v4, v11, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v4}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 2826
    invoke-static/range {v26 .. v26}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v1, v4}, Landroid/view/View;->setBackgroundColor(I)V

    .line 2827
    invoke-virtual {v9, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2829
    new-instance v1, Landroid/widget/LinearLayout;

    invoke-direct {v1, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 2830
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v58, v2

    const/4 v2, -0x2

    const/high16 v11, 0x3f800000  # 1.0f

    const/4 v12, 0x0

    invoke-direct {v4, v12, v2, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v1, v4}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v4, 0x1

    .line 2831
    invoke-virtual {v1, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v2, 0x11

    .line 2832
    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 2833
    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 2834
    const-string v4, "YGRjDXcTEg=="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2835
    invoke-static/range {v56 .. v56}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v4, 0x41500000  # 13.0f

    .line 2836
    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v4, 0x1

    const/4 v11, 0x0

    .line 2837
    invoke-virtual {v2, v11, v4}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 2838
    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2839
    new-instance v4, Landroid/widget/TextView;

    invoke-direct {v4, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 2840
    const-string v11, "JjUwRFYyJw=="

    invoke-static {v11}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v4, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2841
    const-string v11, "dm1ybAsXbA=="

    invoke-static {v11}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-static {v11}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v11

    invoke-virtual {v4, v11}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v11, 0x41200000  # 10.0f

    .line 2842
    invoke-virtual {v4, v11}, Landroid/widget/TextView;->setTextSize(F)V

    .line 2843
    invoke-virtual {v1, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2844
    invoke-virtual {v9, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2846
    new-instance v1, Landroid/widget/LinearLayout;

    invoke-direct {v1, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v4, 0x1

    .line 2847
    invoke-virtual {v1, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 2848
    invoke-virtual {v6, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const/4 v11, 0x5

    .line 2850
    new-array v4, v11, [Landroid/widget/TextView;

    .line 2851
    new-array v6, v11, [Landroid/widget/LinearLayout;

    .line 2852
    new-array v9, v11, [Landroid/widget/ImageView;

    const/4 v12, 0x0

    :goto_b48
    if-lt v12, v11, :cond_18af

    .line 2882
    new-instance v1, Landroid/widget/LinearLayout;

    invoke-direct {v1, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v11, 0x0

    .line 2883
    invoke-virtual {v1, v11}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v11, 0x10

    .line 2884
    invoke-virtual {v1, v11}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 2885
    const-string v11, "dhJ+a3kTFw=="

    invoke-static {v11}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-static {v11}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v11

    move-object/from16 v59, v2

    const/16 v12, 0xc

    invoke-static {v8, v12}, Ld;->a(Landroid/content/Context;I)I

    move-result v2

    move-object/from16 v60, v4

    const/4 v12, 0x1

    invoke-static {v8, v12}, Ld;->a(Landroid/content/Context;I)I

    move-result v4

    invoke-static/range {v26 .. v26}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-static {v12}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v12

    invoke-static {v11, v2, v4, v12}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/16 v2, 0xe

    .line 2886
    invoke-static {v8, v2}, Ld;->a(Landroid/content/Context;I)I

    move-result v4

    const/16 v11, 0xb

    invoke-static {v8, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v11

    invoke-static {v8, v2}, Ld;->a(Landroid/content/Context;I)I

    move-result v12

    const/16 v2, 0xb

    invoke-static {v8, v2}, Ld;->a(Landroid/content/Context;I)I

    move-result v2

    invoke-virtual {v1, v4, v11, v12, v2}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 2887
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v4, -0x2

    const/4 v11, -0x1

    invoke-direct {v2, v11, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v11, 0xe

    .line 2888
    invoke-static {v8, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v12

    iput v12, v2, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 2889
    invoke-virtual {v13, v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2890
    invoke-static {v1}, Ld;->applyTactileTouch(Landroid/view/View;)V

    .line 2892
    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 2893
    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v61, v6

    const/4 v6, 0x0

    const/high16 v12, 0x3f800000  # 1.0f

    invoke-direct {v11, v6, v4, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v2, v11}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 2894
    const-string v4, "FjsrXVknMWZ9VDQ6NQ=="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2895
    const-string v4, "dmBxGA1jbQ=="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v4, 0x41480000  # 12.5f

    .line 2896
    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v4, 0x1

    const/4 v11, 0x0

    .line 2897
    invoke-virtual {v2, v11, v4}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 2898
    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2900
    new-instance v4, Landroid/widget/TextView;

    invoke-direct {v4, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 2901
    const-string v6, "t8L6"

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2902
    invoke-static/range {v50 .. v50}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v11, 0x41200000  # 10.0f

    .line 2903
    invoke-virtual {v4, v11}, Landroid/widget/TextView;->setTextSize(F)V

    .line 2904
    invoke-virtual {v1, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2906
    new-instance v6, Landroid/widget/LinearLayout;

    invoke-direct {v6, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v12, 0x1

    .line 2907
    invoke-virtual {v6, v12}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v11, 0x8

    .line 2908
    invoke-virtual {v6, v11}, Landroid/widget/LinearLayout;->setVisibility(I)V

    move-object/from16 v62, v1

    const/16 v11, 0x10

    .line 2909
    invoke-static {v8, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v1

    invoke-static {v8, v12}, Ld;->a(Landroid/content/Context;I)I

    move-result v11

    invoke-static/range {v26 .. v26}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-static {v12}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v12

    move-object/from16 v63, v2

    const/4 v2, -0x1

    invoke-static {v2, v1, v11, v12}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v1

    invoke-virtual {v6, v1}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/16 v11, 0xc

    .line 2910
    invoke-static {v8, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v1

    invoke-static {v8, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v12

    invoke-static {v8, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v2

    move-object/from16 v64, v4

    invoke-static {v8, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v4

    invoke-virtual {v6, v1, v12, v2, v4}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 2911
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, -0x2

    const/4 v11, -0x1

    invoke-direct {v1, v11, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v2, 0xe

    .line 2912
    invoke-static {v8, v2}, Ld;->a(Landroid/content/Context;I)I

    move-result v4

    iput v4, v1, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 2913
    invoke-virtual {v13, v6, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2915
    new-instance v1, Landroid/widget/LinearLayout;

    invoke-direct {v1, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v11, 0x0

    .line 2916
    invoke-virtual {v1, v11}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v2, 0x10

    .line 2917
    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/16 v4, 0x8

    .line 2918
    invoke-static {v8, v4}, Ld;->a(Landroid/content/Context;I)I

    move-result v2

    invoke-virtual {v1, v11, v11, v11, v2}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 2920
    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 2921
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v65, v9

    const/4 v9, -0x2

    const/high16 v12, 0x3f800000  # 1.0f

    invoke-direct {v4, v11, v9, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 2922
    const-string v4, "EzEnWU0nMTU="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2923
    invoke-static/range {v38 .. v38}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v4, 0x41380000  # 11.5f

    .line 2924
    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v4, 0x1

    const/4 v11, 0x0

    .line 2925
    invoke-virtual {v2, v11, v4}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 2926
    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2928
    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 2929
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v9, 0x24

    invoke-static {v8, v9}, Ld;->a(Landroid/content/Context;I)I

    move-result v9

    const/4 v11, -0x2

    invoke-direct {v4, v9, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/4 v9, 0x4

    .line 2930
    invoke-static {v8, v9}, Ld;->a(Landroid/content/Context;I)I

    move-result v11

    iput v11, v4, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    .line 2931
    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/16 v4, 0x11

    .line 2932
    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setGravity(I)V

    .line 2933
    const-string v4, "EyYjSA=="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2934
    invoke-static/range {v38 .. v38}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v4, 0x41300000  # 11.0f

    .line 2935
    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v4, 0x1

    const/4 v11, 0x0

    .line 2936
    invoke-virtual {v2, v11, v4}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 2937
    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2939
    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 2940
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v9, 0x30

    invoke-static {v8, v9}, Ld;->a(Landroid/content/Context;I)I

    move-result v9

    const/4 v11, -0x2

    invoke-direct {v4, v9, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/4 v9, 0x4

    .line 2941
    invoke-static {v8, v9}, Ld;->a(Landroid/content/Context;I)I

    move-result v11

    iput v11, v4, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    .line 2942
    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/16 v4, 0x11

    .line 2943
    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setGravity(I)V

    .line 2944
    const-string v4, "FzU1RFs="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2945
    const-string v4, "dmR+FAkXZg=="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v4, 0x41300000  # 11.0f

    .line 2946
    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v4, 0x1

    const/4 v11, 0x0

    .line 2947
    invoke-virtual {v2, v11, v4}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 2948
    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2950
    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 2951
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v9, 0x36

    invoke-static {v8, v9}, Ld;->a(Landroid/content/Context;I)I

    move-result v9

    const/4 v11, -0x2

    invoke-direct {v4, v9, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/16 v4, 0x11

    .line 2952
    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setGravity(I)V

    .line 2953
    const-string v4, "BSYpDW4cBA=="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 2954
    const-string v4, "dmRwGH5hYg=="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v4, 0x41280000  # 10.5f

    .line 2955
    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v4, 0x1

    const/4 v11, 0x0

    .line 2956
    invoke-virtual {v2, v11, v4}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    const/4 v11, 0x5

    .line 2957
    invoke-static {v8, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v4

    const/4 v9, 0x3

    invoke-static {v8, v9}, Ld;->a(Landroid/content/Context;I)I

    move-result v9

    invoke-static {v8, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v12

    const/4 v11, 0x3

    invoke-static {v8, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v11

    invoke-virtual {v2, v4, v9, v12, v11}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 2958
    const-string v4, "dhB3a3kQYQ=="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    const/16 v9, 0xa

    invoke-static {v8, v9}, Ld;->a(Landroid/content/Context;I)I

    move-result v11

    const/4 v12, 0x0

    invoke-static {v4, v11, v12, v12}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2959
    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2961
    invoke-virtual {v6, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2963
    new-instance v1, Landroid/view/View;

    invoke-direct {v1, v8}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 2964
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v4, 0x1

    invoke-static {v8, v4}, Ld;->a(Landroid/content/Context;I)I

    move-result v9

    const/4 v11, -0x1

    invoke-direct {v2, v11, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v2}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 2965
    invoke-static/range {v26 .. v26}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/view/View;->setBackgroundColor(I)V

    .line 2966
    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    check-cast v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v9, 0x4

    .line 2967
    invoke-static {v8, v9}, Ld;->a(Landroid/content/Context;I)I

    move-result v4

    iput v4, v2, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 2968
    invoke-virtual {v6, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2971
    const-string v1, "ETUvQUF1BDRIXDw3MkRXOyc="

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v66

    .line 2972
    const-string v1, "BQYJDXs6OjVIViYhNQ15HA=="

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v67

    .line 2973
    const-string v1, "EzgpTEw8OiENcAAQ"

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v68

    .line 2974
    const-string v1, "FB1mfkwnNTJIXyx0BUVZIQ=="

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v69

    .line 2975
    const-string v1, "BjE0W10ndBVdXTAw"

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v70

    .line 2976
    const-string v1, "GjIgRFs8NSoNeTY3I15L"

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v71

    filled-new-array/range {v66 .. v71}, [Ljava/lang/String;

    move-result-object v2

    .line 2979
    const-string v1, "ZmQ1DR51ZSsNXCc1MV4="

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v66

    .line 2980
    const-string v1, "bWFjBhg0NyVYSjQ3Pw=="

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v67

    .line 2981
    const-string v1, "EjUrSBg6IiNfVDQt"

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v68

    .line 2982
    const-string v1, "Z2BpGhg0JzVESyE1KFk="

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v69

    .line 2983
    const-string v1, "Ax0WDUo6ITJEVjI="

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v70

    .line 2984
    const-string v1, "Ax0WDVs9NShDXTkn"

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v71

    filled-new-array/range {v66 .. v71}, [Ljava/lang/String;

    move-result-object v4

    const/4 v11, 0x6

    .line 2986
    new-array v9, v11, [Landroid/graphics/drawable/Drawable;

    .line 2987
    const-string v1, "dmBxGA1jbQ=="

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    const/16 v11, 0x16

    invoke-static {v8, v11, v1}, Ld;->e(Landroid/content/Context;II)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    const/4 v11, 0x0

    aput-object v1, v9, v11

    .line 2988
    invoke-static/range {v50 .. v50}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    const/16 v11, 0x16

    invoke-static {v8, v11, v1}, Ld;->a(Landroid/content/Context;II)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    const/4 v12, 0x1

    aput-object v1, v9, v12

    .line 2989
    const-string v1, "dmR+FAkXZg=="

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    invoke-static {v8, v11, v1}, Ld;->f(Landroid/content/Context;II)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    const/16 v19, 0x2

    aput-object v1, v9, v19

    .line 2990
    const-string v1, "dmJ1Gw4TZQ=="

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    invoke-static {v8, v11, v1}, Ld;->g(Landroid/content/Context;II)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    const/4 v11, 0x3

    aput-object v1, v9, v11

    .line 2991
    const-string v1, "dhJzFH1lFg=="

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    const/16 v11, 0x16

    invoke-static {v8, v11, v1}, Ld;->h(Landroid/content/Context;II)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    const/16 v21, 0x4

    aput-object v1, v9, v21

    .line 2992
    invoke-static/range {v56 .. v56}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    invoke-static {v8, v11, v1}, Ld;->i(Landroid/content/Context;II)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    const/16 v31, 0x5

    aput-object v1, v9, v31

    const/4 v11, 0x6

    .line 2995
    new-array v1, v11, [Landroid/widget/TextView;

    .line 2996
    invoke-static {v8}, Ld;->q(Landroid/content/Context;)I

    move-result v11

    .line 2997
    invoke-static {v8}, Ld;->r(Landroid/content/Context;)I

    move-result v12

    .line 2999
    invoke-static {v11}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v11

    const-string v66, "ADoqRFU8ICNJ"

    move-object/from16 v67, v1

    invoke-static/range {v66 .. v66}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v66, "ADoqRFU8ICNJ"

    move-object/from16 v68, v2

    invoke-static/range {v66 .. v66}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    filled-new-array {v11, v1, v2}, [Ljava/lang/String;

    move-result-object v1

    .line 3000
    const-string v2, "t8jT"

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v11, "t8jT"

    invoke-static {v11}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const-string v66, "t8jS"

    move-object/from16 v69, v1

    invoke-static/range {v66 .. v66}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    filled-new-array {v2, v11, v1}, [Ljava/lang/String;

    move-result-object v1

    .line 3001
    const-string v2, "t8jT"

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v11, "t8jT"

    invoke-static {v11}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const-string v66, "t8jS"

    move-object/from16 v70, v1

    invoke-static/range {v66 .. v66}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    filled-new-array {v2, v11, v1}, [Ljava/lang/String;

    move-result-object v1

    .line 3002
    invoke-static {v12}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    const-string v11, "ADoqRFU8ICNJ"

    invoke-static {v11}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const-string v12, "ADoqRFU8ICNJ"

    invoke-static {v12}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    filled-new-array {v2, v11, v12}, [Ljava/lang/String;

    move-result-object v2

    .line 3003
    const-string v11, "Gzs0QFk5"

    invoke-static {v11}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const-string v12, "EzU1WQ=="

    invoke-static {v12}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    const-string v66, "ZTk1DW4cBA=="

    move-object/from16 v71, v1

    invoke-static/range {v66 .. v66}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    filled-new-array {v11, v12, v1}, [Ljava/lang/String;

    move-result-object v1

    .line 3004
    const-string v11, "t8jS"

    invoke-static {v11}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const-string v12, "t8jS"

    invoke-static {v12}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    const-string v66, "t8jSDW4cBA=="

    move-object/from16 v72, v1

    invoke-static/range {v66 .. v66}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    filled-new-array {v11, v12, v1}, [Ljava/lang/String;

    move-result-object v1

    const/4 v11, 0x6

    new-array v12, v11, [[Ljava/lang/String;

    const/16 v18, 0x0

    aput-object v69, v12, v18

    const/4 v11, 0x1

    aput-object v70, v12, v11

    const/4 v11, 0x2

    aput-object v71, v12, v11

    const/16 v18, 0x3

    aput-object v2, v12, v18

    const/16 v21, 0x4

    aput-object v72, v12, v21

    const/16 v31, 0x5

    aput-object v1, v12, v31

    const/4 v1, 0x0

    :goto_f31
    const/4 v2, 0x6

    if-lt v1, v2, :cond_15ad

    .line 3105
    new-instance v1, Landroid/widget/LinearLayout;

    invoke-direct {v1, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v4, 0x1

    .line 3106
    invoke-virtual {v1, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 3107
    invoke-virtual {v1, v4}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 3108
    invoke-static {v8, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v2

    const/16 v9, 0xa

    invoke-static {v8, v9}, Ld;->a(Landroid/content/Context;I)I

    move-result v4

    const/4 v11, 0x0

    invoke-virtual {v1, v11, v2, v11, v4}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 3110
    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 3111
    const-string v4, "BjEqSFshdAJYSjQgL0JW"

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3112
    const-string v4, "dmUDHHphFg=="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v4, 0x41500000  # 13.0f

    .line 3113
    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v4, 0x1

    const/4 v11, 0x0

    .line 3114
    invoke-virtual {v2, v11, v4}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 3115
    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 3117
    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 3118
    const-string v4, "BjUwSBggJGZZV3VhdggYOjpmYFc7IC5BQQ=="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3119
    invoke-static/range {v50 .. v50}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v4, 0x41300000  # 11.0f

    .line 3120
    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v4, 0x1

    const/4 v11, 0x0

    .line 3121
    invoke-virtual {v2, v11, v4}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 3122
    invoke-static {v8, v4}, Ld;->a(Landroid/content/Context;I)I

    move-result v9

    const/4 v11, 0x0

    invoke-virtual {v2, v11, v9, v11, v11}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 3123
    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 3124
    invoke-virtual {v13, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 3126
    new-instance v1, Landroid/widget/LinearLayout;

    invoke-direct {v1, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 3127
    invoke-virtual {v1, v11}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 3128
    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v9, -0x1

    const/4 v12, -0x2

    invoke-direct {v4, v9, v12}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v9, 0xe

    .line 3129
    invoke-static {v8, v9}, Ld;->a(Landroid/content/Context;I)I

    move-result v11

    iput v11, v4, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 3130
    invoke-virtual {v13, v1, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 3132
    new-instance v4, Landroid/widget/LinearLayout;

    invoke-direct {v4, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 3133
    new-instance v11, Landroid/widget/LinearLayout$LayoutParams;

    move-object/from16 v31, v2

    const/4 v2, 0x0

    const/high16 v9, 0x3f800000  # 1.0f

    invoke-direct {v11, v2, v12, v9}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v4, v11}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v12, 0x1

    .line 3134
    invoke-virtual {v4, v12}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v2, 0x11

    .line 3135
    invoke-virtual {v4, v2}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/16 v9, 0xa

    .line 3136
    invoke-static {v8, v9}, Ld;->a(Landroid/content/Context;I)I

    move-result v2

    const/16 v11, 0xe

    invoke-static {v8, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v12

    invoke-static {v8, v9}, Ld;->a(Landroid/content/Context;I)I

    move-result v11

    move-object/from16 v66, v6

    const/16 v9, 0xc

    invoke-static {v8, v9}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    invoke-virtual {v4, v2, v12, v11, v6}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 3137
    const-string v2, "dhJ+a3kTFw=="

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    const/16 v11, 0xe

    invoke-static {v8, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    const/4 v12, 0x1

    invoke-static {v8, v12}, Ld;->a(Landroid/content/Context;I)I

    move-result v9

    invoke-static/range {v26 .. v26}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-static {v11}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v11

    invoke-static {v2, v6, v9, v11}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    invoke-virtual {v4, v2}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 3139
    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 3140
    const-string v6, "AjEjRlQs"

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3141
    invoke-static/range {v38 .. v38}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    invoke-virtual {v2, v6}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v6, 0x41400000  # 12.0f

    .line 3142
    invoke-virtual {v2, v6}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v11, 0x0

    const/4 v12, 0x1

    .line 3143
    invoke-virtual {v2, v11, v12}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 3144
    invoke-virtual {v4, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 3146
    new-instance v6, Landroid/widget/TextView;

    invoke-direct {v6, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 3147
    invoke-virtual {v6, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3148
    const-string v9, "dmUDHHphFg=="

    invoke-static {v9}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v9

    invoke-virtual {v6, v9}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v9, 0x41a00000  # 20.0f

    .line 3149
    invoke-virtual {v6, v9}, Landroid/widget/TextView;->setTextSize(F)V

    .line 3150
    invoke-virtual {v6, v11, v12}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    const/4 v9, 0x4

    .line 3151
    invoke-static {v8, v9}, Ld;->a(Landroid/content/Context;I)I

    move-result v11

    invoke-static {v8, v9}, Ld;->a(Landroid/content/Context;I)I

    move-result v12

    const/4 v9, 0x0

    invoke-virtual {v6, v9, v11, v9, v12}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 3152
    invoke-virtual {v4, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 3154
    new-instance v9, Landroid/widget/TextView;

    invoke-direct {v9, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    const/4 v11, 0x7

    const/16 v12, 0x2a

    .line 3155
    invoke-static {v3, v11, v12}, Ld;->a(Ljava/lang/String;II)I

    move-result v11

    .line 3156
    new-instance v12, Ljava/lang/StringBuilder;

    invoke-static {v3}, Ld;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v56

    move-object/from16 v68, v2

    invoke-static/range {v56 .. v56}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    invoke-direct {v12, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v12, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, "dXtmSVks"

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v12, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v9, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3157
    invoke-static/range {v38 .. v38}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v9, v2}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v11, 0x41200000  # 10.0f

    .line 3158
    invoke-virtual {v9, v11}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v11, 0x6

    .line 3159
    invoke-static {v8, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v2

    move-object/from16 v69, v3

    const/4 v12, 0x4

    invoke-static {v8, v12}, Ld;->a(Landroid/content/Context;I)I

    move-result v3

    move-object/from16 v56, v6

    invoke-static {v8, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    invoke-static {v8, v12}, Ld;->a(Landroid/content/Context;I)I

    move-result v11

    invoke-virtual {v9, v2, v3, v6, v11}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 3160
    const-string v2, "dhJ3aw0TbQ=="

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    const/4 v11, 0x6

    invoke-static {v8, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v3

    const/4 v11, 0x0

    invoke-static {v2, v3, v11, v11}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    invoke-virtual {v9, v2}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 3161
    invoke-virtual {v4, v9}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 3163
    invoke-virtual {v1, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 3165
    new-instance v2, Landroid/view/View;

    invoke-direct {v2, v8}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 3166
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v6, 0xa

    invoke-static {v8, v6}, Ld;->a(Landroid/content/Context;I)I

    move-result v11

    const/4 v6, -0x1

    invoke-direct {v3, v11, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v1, v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 3168
    new-instance v2, Landroid/widget/RelativeLayout;

    invoke-direct {v2, v8}, Landroid/widget/RelativeLayout;-><init>(Landroid/content/Context;)V

    .line 3169
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v6, -0x2

    const/high16 v11, 0x3f800000  # 1.0f

    const/4 v12, 0x0

    invoke-direct {v3, v12, v6, v11}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v2, v3}, Landroid/widget/RelativeLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 3171
    new-instance v3, Landroid/widget/LinearLayout;

    invoke-direct {v3, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 3172
    new-instance v11, Landroid/widget/RelativeLayout$LayoutParams;

    const/4 v12, -0x1

    invoke-direct {v11, v12, v6}, Landroid/widget/RelativeLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v3, v11}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v12, 0x1

    .line 3173
    invoke-virtual {v3, v12}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v6, 0x11

    .line 3174
    invoke-virtual {v3, v6}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/16 v6, 0xa

    .line 3175
    invoke-static {v8, v6}, Ld;->a(Landroid/content/Context;I)I

    move-result v11

    move-object/from16 v37, v4

    const/16 v12, 0xe

    invoke-static {v8, v12}, Ld;->a(Landroid/content/Context;I)I

    move-result v4

    invoke-static {v8, v6}, Ld;->a(Landroid/content/Context;I)I

    move-result v12

    move-object/from16 v70, v9

    const/16 v6, 0xc

    invoke-static {v8, v6}, Ld;->a(Landroid/content/Context;I)I

    move-result v9

    invoke-virtual {v3, v11, v4, v12, v9}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    const/16 v11, 0xe

    .line 3176
    invoke-static {v8, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v4

    const/4 v11, 0x2

    invoke-static {v8, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    const-string v9, "dmwCGgETZg=="

    invoke-static {v9}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v9

    const/4 v11, -0x1

    invoke-static {v11, v4, v6, v9}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 3178
    new-instance v4, Landroid/widget/TextView;

    invoke-direct {v4, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 3179
    const-string v6, "GDsoWVA5LQ=="

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3180
    const-string v6, "dmUDHHphFg=="

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v6, 0x41400000  # 12.0f

    .line 3181
    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v11, 0x0

    const/4 v12, 0x1

    .line 3182
    invoke-virtual {v4, v11, v12}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 3183
    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 3185
    new-instance v6, Landroid/widget/TextView;

    invoke-direct {v6, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 3186
    invoke-virtual {v6, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3187
    const-string v9, "dmUDHHphFg=="

    invoke-static {v9}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v9

    invoke-virtual {v6, v9}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v9, 0x41a00000  # 20.0f

    .line 3188
    invoke-virtual {v6, v9}, Landroid/widget/TextView;->setTextSize(F)V

    .line 3189
    invoke-virtual {v6, v11, v12}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    const/4 v9, 0x4

    .line 3190
    invoke-static {v8, v9}, Ld;->a(Landroid/content/Context;I)I

    move-result v11

    invoke-static {v8, v9}, Ld;->a(Landroid/content/Context;I)I

    move-result v12

    const/4 v9, 0x0

    invoke-virtual {v6, v9, v11, v9, v12}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 3191
    invoke-virtual {v3, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 3193
    new-instance v9, Landroid/widget/TextView;

    invoke-direct {v9, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    const/16 v11, 0x1e

    const/16 v12, 0x1a

    .line 3194
    invoke-static {v5, v11, v12}, Ld;->a(Ljava/lang/String;II)I

    move-result v11

    .line 3195
    const-string v12, "JSYpclU6OjJFVCwLNl9RNjEZQko8Mw=="

    invoke-static {v12}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    const-string v71, "JSYpckgnPSVIZzomL0o="

    move-object/from16 v72, v4

    invoke-static/range {v71 .. v71}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const-string v71, "t9b/HAxsbQ=="

    move-object/from16 v73, v6

    invoke-static/range {v71 .. v71}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-interface {v7, v4, v6}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-interface {v7, v12, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 3196
    const-string v6, "JSYpclU6OjJFVCwLIkRLNjszQ0wKICdK"

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const-string v12, "JSYpclw8JyVCTTsgGVlZMg=="

    invoke-static {v12}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    const-string v71, "YGRjDXcTEg=="

    move-object/from16 v74, v10

    invoke-static/range {v71 .. v71}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-interface {v7, v12, v10}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-interface {v7, v6, v10}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 3197
    const-string v10, "BjUwSBhgZGM="

    invoke-static {v10}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-static {v4, v5, v6, v10}, Ld;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 3198
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-static {v5}, Ld;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    invoke-direct {v4, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v6, "dXtmSVks"

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v9, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3199
    invoke-static/range {v50 .. v50}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v9, v4}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v11, 0x41200000  # 10.0f

    .line 3200
    invoke-virtual {v9, v11}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v4, 0x1

    const/4 v11, 0x0

    .line 3201
    invoke-virtual {v9, v11, v4}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    const/4 v11, 0x6

    .line 3202
    invoke-static {v8, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v4

    const/4 v10, 0x4

    invoke-static {v8, v10}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    invoke-static {v8, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v12

    invoke-static {v8, v10}, Ld;->a(Landroid/content/Context;I)I

    move-result v11

    invoke-virtual {v9, v4, v6, v12, v11}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 3203
    const-string v4, "dhJ1awgTEg=="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    const/4 v11, 0x6

    invoke-static {v8, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    const/4 v11, 0x0

    invoke-static {v4, v6, v11, v11}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v4

    invoke-virtual {v9, v4}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 3204
    invoke-virtual {v3, v9}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 3206
    invoke-virtual {v2, v3}, Landroid/widget/RelativeLayout;->addView(Landroid/view/View;)V

    .line 3208
    new-instance v4, Landroid/widget/TextView;

    invoke-direct {v4, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 3209
    const-string v6, "BhUQaBhgZGM="

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v11, -0x1

    .line 3210
    invoke-virtual {v4, v11}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v6, 0x41100000  # 9.0f

    .line 3211
    invoke-virtual {v4, v6}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v11, 0x0

    const/4 v12, 0x1

    .line 3212
    invoke-virtual {v4, v11, v12}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    const/16 v10, 0x8

    .line 3213
    invoke-static {v8, v10}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    const/4 v11, 0x2

    invoke-static {v8, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v12

    move-object/from16 v18, v3

    invoke-static {v8, v10}, Ld;->a(Landroid/content/Context;I)I

    move-result v3

    invoke-static {v8, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v10

    invoke-virtual {v4, v6, v12, v3, v10}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 3214
    invoke-static/range {v50 .. v50}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    const-string v6, "dm11HgsQFQ=="

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    const/16 v10, 0xa

    invoke-static {v8, v10}, Ld;->a(Landroid/content/Context;I)I

    move-result v11

    const/4 v12, 0x0

    invoke-static {v3, v6, v11, v12, v12}, Ld;->a(IIIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v3

    invoke-virtual {v4, v3}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 3215
    new-instance v3, Landroid/widget/RelativeLayout$LayoutParams;

    const/4 v11, -0x2

    invoke-direct {v3, v11, v11}, Landroid/widget/RelativeLayout$LayoutParams;-><init>(II)V

    .line 3216
    invoke-virtual {v3, v10}, Landroid/widget/RelativeLayout$LayoutParams;->addRule(I)V

    const/16 v11, 0xe

    .line 3217
    invoke-virtual {v3, v11}, Landroid/widget/RelativeLayout$LayoutParams;->addRule(I)V

    .line 3218
    invoke-virtual {v2, v4, v3}, Landroid/widget/RelativeLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 3220
    invoke-virtual {v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 3222
    invoke-static/range {v37 .. v37}, Ld;->applyTactileTouch(Landroid/view/View;)V

    .line 3223
    invoke-static/range {v18 .. v18}, Ld;->applyTactileTouch(Landroid/view/View;)V

    .line 3225
    new-instance v1, Landroid/widget/Button;

    invoke-direct {v1, v8}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    .line 3226
    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "ACQhX1kxMWZZV3UENEIYAx0WDRA="

    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "fA=="

    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    const/4 v11, -0x1

    .line 3227
    invoke-virtual {v1, v11}, Landroid/widget/Button;->setTextColor(I)V

    const/high16 v2, 0x41700000  # 15.0f

    .line 3228
    invoke-virtual {v1, v2}, Landroid/widget/Button;->setTextSize(F)V

    const/4 v11, 0x0

    const/4 v12, 0x1

    .line 3229
    invoke-virtual {v1, v11, v12}, Landroid/widget/Button;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 3230
    invoke-static/range {v50 .. v50}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    const-string v3, "dmAAGQ4QYQ=="

    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    const/16 v12, 0x10

    invoke-static {v8, v12}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    const/4 v12, 0x0

    invoke-static {v2, v3, v6, v12, v12}, Ld;->a(IIIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/widget/Button;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 3231
    invoke-virtual {v1, v11, v11, v11, v11}, Landroid/widget/Button;->setCompoundDrawablesWithIntrinsicBounds(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 3232
    invoke-virtual {v1, v12}, Landroid/widget/Button;->setCompoundDrawablePadding(I)V

    .line 3233
    invoke-static {v1}, Ld;->removeElevation(Landroid/view/View;)V

    .line 3234
    invoke-static {v1}, Ld;->applyTactileTouch(Landroid/view/View;)V

    .line 3235
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v3, 0x34

    invoke-static {v8, v3}, Ld;->a(Landroid/content/Context;I)I

    move-result v3

    const/4 v11, -0x1

    invoke-direct {v2, v11, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v6, 0xa

    .line 3236
    invoke-static {v8, v6}, Ld;->a(Landroid/content/Context;I)I

    move-result v3

    iput v3, v2, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 3237
    invoke-virtual {v13, v1, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 3239
    new-instance v2, Landroid/widget/Button;

    invoke-direct {v2, v8}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    .line 3240
    const-string v3, "FjsoWVE7ISMNficxIw=="

    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 3241
    const-string v3, "dmBxGA1jbQ=="

    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setTextColor(I)V

    const/high16 v6, 0x41400000  # 12.0f

    .line 3242
    invoke-virtual {v2, v6}, Landroid/widget/Button;->setTextSize(F)V

    const/4 v11, 0x0

    const/4 v12, 0x1

    .line 3243
    invoke-virtual {v2, v11, v12}, Landroid/widget/Button;->setTypeface(Landroid/graphics/Typeface;I)V

    const/16 v11, 0xe

    .line 3244
    invoke-static {v8, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v3

    invoke-static {v8, v12}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    invoke-static/range {v26 .. v26}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v10

    const/4 v11, -0x1

    invoke-static {v11, v3, v6, v10}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 3245
    invoke-static {v2}, Ld;->removeElevation(Landroid/view/View;)V

    .line 3246
    invoke-static {v2}, Ld;->applyTactileTouch(Landroid/view/View;)V

    .line 3247
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v6, 0x2c

    invoke-static {v8, v6}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    invoke-direct {v3, v11, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v11, 0xe

    .line 3248
    invoke-static {v8, v11}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    iput v6, v3, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 3249
    invoke-virtual {v13, v2, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 3250
    sget-object v3, Ld;->c:Ljava/lang/String;

    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_13ba

    sget-object v3, Ld;->b:Ljava/lang/String;

    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_13b5

    const/16 v10, 0x8

    const/4 v11, 0x0

    goto :goto_13bd

    :cond_13b5
    const/4 v11, 0x0

    .line 3253
    invoke-virtual {v2, v11}, Landroid/widget/Button;->setVisibility(I)V

    goto :goto_13c0

    :cond_13ba
    const/4 v11, 0x0

    const/16 v10, 0x8

    .line 3251
    :goto_13bd
    invoke-virtual {v2, v10}, Landroid/widget/Button;->setVisibility(I)V

    .line 3256
    :goto_13c0
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, v8}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 3257
    invoke-virtual {v0, v11}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v6, 0x11

    .line 3258
    invoke-virtual {v0, v6}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/16 v6, 0xa

    .line 3259
    invoke-static {v8, v6}, Ld;->a(Landroid/content/Context;I)I

    move-result v3

    invoke-virtual {v0, v11, v11, v11, v3}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 3261
    new-instance v3, Landroid/widget/TextView;

    invoke-direct {v3, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 3262
    const-string v6, "BjElWEow"

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3263
    invoke-static/range {v38 .. v38}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    invoke-virtual {v3, v6}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v11, 0x41200000  # 10.0f

    .line 3264
    invoke-virtual {v3, v11}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v11, 0x0

    const/4 v12, 0x1

    .line 3265
    invoke-virtual {v3, v11, v12}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 3266
    invoke-static/range {v38 .. v38}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    const/16 v12, 0xc

    invoke-static {v8, v12, v6}, Ld;->c(Landroid/content/Context;II)Landroid/graphics/drawable/Drawable;

    move-result-object v6

    invoke-virtual {v3, v6, v11, v11, v11}, Landroid/widget/TextView;->setCompoundDrawablesWithIntrinsicBounds(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    const/4 v10, 0x4

    .line 3267
    invoke-static {v8, v10}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    invoke-virtual {v3, v6}, Landroid/widget/TextView;->setCompoundDrawablePadding(I)V

    const/16 v6, 0xa

    .line 3268
    invoke-static {v8, v6}, Ld;->a(Landroid/content/Context;I)I

    move-result v10

    const/4 v11, 0x0

    invoke-virtual {v3, v11, v11, v10, v11}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 3269
    invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 3271
    new-instance v3, Landroid/widget/TextView;

    invoke-direct {v3, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 3272
    const-string v6, "HDo1WVk7IGZsWzYxNV4="

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3273
    invoke-static/range {v38 .. v38}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    invoke-virtual {v3, v6}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v11, 0x41200000  # 10.0f

    .line 3274
    invoke-virtual {v3, v11}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v11, 0x0

    const/4 v12, 0x1

    .line 3275
    invoke-virtual {v3, v11, v12}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 3276
    invoke-static/range {v38 .. v38}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    const/16 v12, 0xc

    invoke-static {v8, v12, v6}, Ld;->a(Landroid/content/Context;II)Landroid/graphics/drawable/Drawable;

    move-result-object v6

    invoke-virtual {v3, v6, v11, v11, v11}, Landroid/widget/TextView;->setCompoundDrawablesWithIntrinsicBounds(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    const/4 v10, 0x4

    .line 3277
    invoke-static {v8, v10}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    invoke-virtual {v3, v6}, Landroid/widget/TextView;->setCompoundDrawablePadding(I)V

    const/16 v6, 0xa

    .line 3278
    invoke-static {v8, v6}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    const/4 v11, 0x0

    invoke-virtual {v3, v11, v11, v6, v11}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 3279
    invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 3281
    new-instance v3, Landroid/widget/TextView;

    invoke-direct {v3, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 3282
    const-string v6, "Z2BpGhgGITZdVycg"

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v3, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3283
    invoke-static/range {v38 .. v38}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    invoke-virtual {v3, v6}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v11, 0x41200000  # 10.0f

    .line 3284
    invoke-virtual {v3, v11}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v11, 0x0

    const/4 v12, 0x1

    .line 3285
    invoke-virtual {v3, v11, v12}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 3286
    invoke-static/range {v38 .. v38}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    const/16 v10, 0xc

    invoke-static {v8, v10, v6}, Ld;->d(Landroid/content/Context;II)Landroid/graphics/drawable/Drawable;

    move-result-object v6

    invoke-virtual {v3, v6, v11, v11, v11}, Landroid/widget/TextView;->setCompoundDrawablesWithIntrinsicBounds(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    const/4 v10, 0x4

    .line 3287
    invoke-static {v8, v10}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    invoke-virtual {v3, v6}, Landroid/widget/TextView;->setCompoundDrawablePadding(I)V

    .line 3288
    invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 3290
    invoke-virtual {v13, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 3292
    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, v8}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 3293
    const-string v3, "FjUoTl05dCdDQSE9K0gYt9TkDXE7JzJMViF0J05MPCInWVE6Og=="

    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3294
    const-string v3, "dm1ybAsXbA=="

    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v3, 0x41300000  # 11.0f

    .line 3295
    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setTextSize(F)V

    const/16 v6, 0x11

    .line 3296
    invoke-virtual {v0, v6}, Landroid/widget/TextView;->setGravity(I)V

    .line 3297
    invoke-virtual {v13, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 3299
    new-instance v0, Ld$13;

    move-object/from16 v38, v1

    move-object/from16 v81, v2

    move-object/from16 v32, v4

    move-object/from16 v2, v20

    move-object/from16 v4, v27

    move-object/from16 v6, v28

    move-object/from16 v1, v29

    move-object/from16 v76, v33

    move-object/from16 v43, v34

    move-object/from16 v34, v37

    move-object/from16 v75, v44

    move-object/from16 v10, v45

    move-object/from16 v20, v46

    move-object/from16 v11, v48

    move-object/from16 v12, v49

    move-object/from16 v21, v51

    move-object/from16 v13, v52

    move-object/from16 v24, v53

    move-object/from16 v22, v54

    move-object/from16 v16, v55

    move-object/from16 v28, v56

    move-object/from16 v25, v57

    move-object/from16 v26, v58

    move-object/from16 v27, v59

    move-object/from16 v17, v60

    move-object/from16 v19, v61

    move-object/from16 v77, v62

    move-object/from16 v78, v63

    move-object/from16 v79, v64

    move-object/from16 v80, v66

    move-object/from16 v3, v69

    move-object/from16 v30, v70

    move-object/from16 v37, v72

    move-object/from16 v29, v73

    move-object/from16 v23, v74

    move-object/from16 v33, v31

    move-object/from16 v44, v35

    move-object/from16 v45, v42

    move-object/from16 v31, v9

    move-object/from16 v35, v18

    move-object/from16 v42, v36

    move-object/from16 v9, v47

    move-object/from16 v18, v65

    move-object/from16 v36, v68

    invoke-direct/range {v0 .. v38}, Ld$13;-><init>([Z[ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/content/SharedPreferences;Landroid/app/Activity;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/LinearLayout;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;[Landroid/widget/TextView;[Landroid/widget/ImageView;[Landroid/widget/LinearLayout;Landroid/view/View;Landroid/widget/FrameLayout;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/LinearLayout;Landroid/widget/LinearLayout;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/Button;)V

    move-object v7, v2

    move-object v14, v9

    move-object v8, v10

    move-object v15, v13

    move-object/from16 v9, v34

    move-object/from16 v11, v35

    move-object/from16 v12, v38

    move-object v13, v0

    move-object v10, v1

    .line 3476
    new-instance v0, Ld$14;

    move-object/from16 v1, p1

    invoke-direct {v0, v1}, Ld$14;-><init>(Landroid/app/Dialog;)V

    move-object/from16 v2, v75

    invoke-virtual {v2, v0}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 3483
    new-instance v0, Ld$15;

    invoke-direct {v0, v1}, Ld$15;-><init>(Landroid/app/Dialog;)V

    move-object/from16 v5, v81

    invoke-virtual {v5, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 3490
    new-instance v0, Ld$16;

    move-object/from16 v1, p0

    move-object/from16 v3, v43

    move-object/from16 v2, v44

    move-object/from16 v4, v45

    move-object/from16 v6, v67

    invoke-direct/range {v0 .. v6}, Ld$16;-><init>(Landroid/app/Activity;Landroid/widget/TextView;Landroid/view/View;Landroid/widget/TextView;Landroid/widget/Button;[Landroid/widget/TextView;)V

    move-object/from16 v3, v76

    invoke-virtual {v3, v0}, Landroid/widget/TextView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 3536
    new-instance v0, Ld$17;

    invoke-direct {v0, v10, v15, v13}, Ld$17;-><init>([ZLandroid/widget/LinearLayout;Ljava/lang/Runnable;)V

    invoke-virtual {v8, v0}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 3544
    new-instance v0, Ld$18;

    invoke-direct {v0, v10, v15, v13}, Ld$18;-><init>([ZLandroid/widget/LinearLayout;Ljava/lang/Runnable;)V

    invoke-virtual {v14, v0}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 3552
    new-instance v0, Ld$19;

    move-object/from16 v5, v78

    move-object/from16 v6, v79

    move-object/from16 v1, v80

    invoke-direct {v0, v1, v6, v5}, Ld$19;-><init>(Landroid/widget/LinearLayout;Landroid/widget/TextView;Landroid/widget/TextView;)V

    move-object/from16 v1, v77

    invoke-virtual {v1, v0}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 3570
    new-instance v0, Ld$20;

    invoke-direct {v0, v7, v13}, Ld$20;-><init>([ZLjava/lang/Runnable;)V

    invoke-virtual {v9, v0}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 3578
    new-instance v0, Ld$21;

    invoke-direct {v0, v7, v13}, Ld$21;-><init>([ZLjava/lang/Runnable;)V

    invoke-virtual {v11, v0}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 3586
    new-instance v0, Ld$23;

    move-object/from16 v6, p0

    move-object v2, v7

    move-object v1, v10

    move-object/from16 v5, v39

    move-object/from16 v4, v40

    move-object/from16 v3, v41

    move-object/from16 v7, p1

    invoke-direct/range {v0 .. v7}, Ld$23;-><init>([Z[ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/app/Activity;Landroid/app/Dialog;)V

    invoke-virtual {v12, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 3613
    invoke-interface {v13}, Ljava/lang/Runnable;->run()V

    return-object v42

    :cond_15ad
    move-object/from16 v69, v3

    move-object/from16 v16, v5

    move-object v7, v8

    move-object/from16 v74, v10

    move-object/from16 v3, v33

    move-object/from16 v33, v41

    move-object/from16 v2, v44

    move-object/from16 v8, v45

    move-object/from16 v77, v62

    move-object/from16 v5, v63

    move-object v10, v6

    move-object/from16 v44, v35

    move-object/from16 v45, v42

    move-object/from16 v6, v64

    move-object/from16 v35, v20

    move-object/from16 v42, v36

    move-object/from16 v20, v39

    move-object/from16 v39, v14

    move-object/from16 v36, v34

    move-object/from16 v14, v47

    move-object/from16 v34, v29

    move-object/from16 v29, v40

    move-object/from16 v40, v15

    move-object/from16 v15, v52

    .line 3008
    new-instance v11, Landroid/widget/LinearLayout;

    invoke-direct {v11, v7}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v0, 0x0

    .line 3009
    invoke-virtual {v11, v0}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v0, 0x10

    .line 3010
    invoke-virtual {v11, v0}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/4 v0, 0x7

    .line 3011
    invoke-static {v7, v0}, Ld;->a(Landroid/content/Context;I)I

    move-result v0

    move-object/from16 v75, v2

    const/4 v2, 0x7

    invoke-static {v7, v2}, Ld;->a(Landroid/content/Context;I)I

    move-result v2

    move-object/from16 v76, v3

    const/4 v3, 0x0

    invoke-virtual {v11, v3, v0, v3, v2}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 3013
    new-instance v0, Landroid/widget/ImageView;

    invoke-direct {v0, v7}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 3014
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v3, 0x16

    invoke-static {v7, v3}, Ld;->a(Landroid/content/Context;I)I

    move-result v3

    move-object/from16 v47, v4

    const/16 v4, 0x16

    invoke-static {v7, v4}, Ld;->a(Landroid/content/Context;I)I

    move-result v4

    invoke-direct {v2, v3, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/16 v4, 0x8

    .line 3015
    invoke-static {v7, v4}, Ld;->a(Landroid/content/Context;I)I

    move-result v3

    iput v3, v2, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    .line 3016
    invoke-virtual {v0, v2}, Landroid/widget/ImageView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 3017
    sget-object v2, Landroid/widget/ImageView$ScaleType;->CENTER_INSIDE:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v0, v2}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    .line 3018
    aget-object v2, v9, v1

    invoke-virtual {v0, v2}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 3019
    invoke-virtual {v11, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 3021
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, v7}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 3022
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v3, 0x3f800000  # 1.0f

    const/4 v4, 0x0

    const/4 v5, -0x2

    invoke-direct {v2, v4, v5, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v4, 0x1

    .line 3023
    invoke-virtual {v0, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 3025
    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, v7}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 3026
    aget-object v5, v68, v1

    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3027
    const-string v5, "dmQAHA9nFQ=="

    invoke-static {v5}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v5, 0x41400000  # 12.0f

    .line 3028
    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v5, 0x0

    .line 3029
    invoke-virtual {v2, v5, v4}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 3030
    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 3032
    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, v7}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 3033
    aget-object v5, v47, v1

    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3034
    invoke-static/range {v38 .. v38}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v5, 0x41180000  # 9.5f

    .line 3035
    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setTextSize(F)V

    .line 3036
    invoke-static {v7, v4}, Ld;->a(Landroid/content/Context;I)I

    move-result v5

    const/4 v4, 0x0

    invoke-virtual {v2, v4, v5, v4, v4}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 3037
    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 3038
    invoke-virtual {v11, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 3040
    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, v7}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 3041
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v4, 0x24

    invoke-static {v7, v4}, Ld;->a(Landroid/content/Context;I)I

    move-result v4

    const/4 v5, -0x2

    invoke-direct {v2, v4, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/4 v4, 0x4

    .line 3042
    invoke-static {v7, v4}, Ld;->a(Landroid/content/Context;I)I

    move-result v5

    iput v5, v2, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    .line 3043
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/16 v2, 0x11

    .line 3044
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setGravity(I)V

    .line 3045
    aget-object v2, v12, v1

    const/4 v4, 0x0

    aget-object v2, v2, v4

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/high16 v2, 0x41200000  # 10.0f

    .line 3046
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v4, 0x5

    if-ne v1, v4, :cond_16e3

    .line 3048
    invoke-static/range {v56 .. v56}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v0, v4}, Landroid/widget/TextView;->setTextColor(I)V

    const/4 v4, 0x1

    const/4 v5, 0x0

    .line 3049
    invoke-virtual {v0, v5, v4}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 3050
    const-string v5, "dhB3a3kQYQ=="

    invoke-static {v5}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    const/4 v2, 0x6

    invoke-static {v7, v2}, Ld;->a(Landroid/content/Context;I)I

    move-result v3

    const/4 v2, 0x0

    invoke-static {v5, v3, v2, v2}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    goto :goto_1735

    :cond_16e3
    const/4 v4, 0x1

    if-eq v1, v4, :cond_1711

    const/4 v2, 0x2

    if-ne v1, v2, :cond_16ea

    goto :goto_1711

    .line 3055
    :cond_16ea
    invoke-static/range {v38 .. v38}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    const/4 v2, 0x0

    .line 3056
    invoke-virtual {v0, v2, v4}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 3057
    const-string v2, "dhJ3aw0TbQ=="

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    const/4 v3, 0x6

    invoke-static {v7, v3}, Ld;->a(Landroid/content/Context;I)I

    move-result v4

    const/4 v3, 0x0

    invoke-static {v2, v4, v3, v3}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    goto :goto_1735

    .line 3052
    :cond_1711
    :goto_1711
    const-string v2, "dm1ybAsXbA=="

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    .line 3053
    const-string v2, "dhJ3aw0TbQ=="

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    const/4 v3, 0x6

    invoke-static {v7, v3}, Ld;->a(Landroid/content/Context;I)I

    move-result v4

    const/4 v3, 0x0

    invoke-static {v2, v4, v3, v3}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 3059
    :goto_1735
    invoke-virtual {v11, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 3060
    aput-object v0, v67, v1

    .line 3062
    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, v7}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 3063
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v3, 0x30

    invoke-static {v7, v3}, Ld;->a(Landroid/content/Context;I)I

    move-result v3

    const/4 v5, -0x2

    invoke-direct {v2, v3, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/4 v4, 0x4

    .line 3064
    invoke-static {v7, v4}, Ld;->a(Landroid/content/Context;I)I

    move-result v3

    iput v3, v2, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    .line 3065
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/16 v2, 0x11

    .line 3066
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setGravity(I)V

    .line 3067
    aget-object v2, v12, v1

    const/4 v3, 0x1

    aget-object v2, v2, v3

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/high16 v2, 0x41100000  # 9.0f

    .line 3068
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextSize(F)V

    if-eq v1, v3, :cond_17c6

    const/4 v2, 0x2

    if-ne v1, v2, :cond_176d

    goto :goto_17c6

    :cond_176d
    const/4 v2, 0x5

    if-ne v1, v2, :cond_179c

    .line 3074
    invoke-static/range {v56 .. v56}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v2, 0x41280000  # 10.5f

    .line 3075
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v2, 0x0

    .line 3076
    invoke-virtual {v0, v2, v3}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 3077
    const-string v2, "dhB3a3kQYQ=="

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    const/4 v3, 0x6

    invoke-static {v7, v3}, Ld;->a(Landroid/content/Context;I)I

    move-result v5

    const/4 v3, 0x0

    invoke-static {v2, v5, v3, v3}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    goto :goto_17ef

    .line 3079
    :cond_179c
    const-string v2, "dmR+FAkXZg=="

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    const/4 v2, 0x1

    const/4 v5, 0x0

    .line 3080
    invoke-virtual {v0, v5, v2}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 3081
    const-string v2, "dhF2awoTEQ=="

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    const/4 v3, 0x6

    invoke-static {v7, v3}, Ld;->a(Landroid/content/Context;I)I

    move-result v5

    const/4 v3, 0x0

    invoke-static {v2, v5, v3, v3}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    goto :goto_17ef

    .line 3070
    :cond_17c6
    :goto_17c6
    const-string v2, "dm1ybAsXbA=="

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v2, 0x41300000  # 11.0f

    .line 3071
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextSize(F)V

    .line 3072
    const-string v2, "dhJ3aw0TbQ=="

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    const/4 v3, 0x6

    invoke-static {v7, v3}, Ld;->a(Landroid/content/Context;I)I

    move-result v5

    const/4 v3, 0x0

    invoke-static {v2, v5, v3, v3}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 3083
    :goto_17ef
    invoke-virtual {v11, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 3085
    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, v7}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 3086
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v3, 0x36

    invoke-static {v7, v3}, Ld;->a(Landroid/content/Context;I)I

    move-result v3

    const/4 v5, -0x2

    invoke-direct {v2, v3, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/16 v2, 0x11

    .line 3087
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setGravity(I)V

    .line 3088
    aget-object v3, v12, v1

    const/4 v5, 0x2

    aget-object v3, v3, v5

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 3089
    invoke-static/range {v56 .. v56}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setTextColor(I)V

    const/4 v3, 0x1

    if-eq v1, v3, :cond_1829

    if-ne v1, v5, :cond_1824

    goto :goto_1829

    :cond_1824
    const/16 v19, 0x9

    const/16 v2, 0x9

    goto :goto_182d

    :cond_1829
    :goto_1829
    const/16 v19, 0xb

    const/16 v2, 0xb

    :goto_182d
    int-to-float v2, v2

    .line 3090
    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v2, 0x0

    .line 3091
    invoke-virtual {v0, v2, v3}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 3092
    const-string v2, "dhB3a3kQYQ=="

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    const/4 v3, 0x6

    invoke-static {v7, v3}, Ld;->a(Landroid/content/Context;I)I

    move-result v4

    const/4 v3, 0x0

    invoke-static {v2, v4, v3, v3}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 3093
    invoke-virtual {v11, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 3095
    invoke-virtual {v10, v11}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const/4 v11, 0x5

    if-ge v1, v11, :cond_1878

    .line 3098
    new-instance v0, Landroid/view/View;

    invoke-direct {v0, v7}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 3099
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v4, 0x1

    invoke-static {v7, v4}, Ld;->a(Landroid/content/Context;I)I

    move-result v3

    const/4 v4, -0x1

    invoke-direct {v2, v4, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v2}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 3100
    const-string v2, "dhJ3aw0TbQ=="

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/view/View;->setBackgroundColor(I)V

    .line 3101
    invoke-virtual {v10, v0}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    :cond_1878
    add-int/lit8 v1, v1, 0x1

    move-object/from16 v0, p2

    move-object/from16 v64, v6

    move-object v6, v10

    move-object/from16 v52, v15

    move-object/from16 v5, v16

    move-object/from16 v41, v33

    move-object/from16 v15, v40

    move-object/from16 v4, v47

    move-object/from16 v3, v69

    move-object/from16 v10, v74

    move-object/from16 v33, v76

    move-object/from16 v62, v77

    const/4 v11, 0x2

    move-object/from16 v47, v14

    move-object/from16 v40, v29

    move-object/from16 v29, v34

    move-object/from16 v34, v36

    move-object/from16 v14, v39

    move-object/from16 v36, v42

    move-object/from16 v42, v45

    move-object/from16 v45, v8

    move-object/from16 v39, v20

    move-object/from16 v20, v35

    move-object/from16 v35, v44

    move-object/from16 v44, v75

    move-object v8, v7

    move-object/from16 v7, p7

    goto/16 :goto_f31

    :cond_18af
    move-object/from16 v59, v2

    move-object/from16 v69, v3

    move-object/from16 v60, v4

    move-object/from16 v16, v5

    move-object/from16 v61, v6

    move-object v7, v8

    move-object/from16 v65, v9

    move-object/from16 v74, v10

    move-object/from16 v76, v33

    move-object/from16 v33, v41

    move-object/from16 v75, v44

    move-object/from16 v8, v45

    const/4 v5, 0x2

    move-object/from16 v44, v35

    move-object/from16 v45, v42

    move-object/from16 v35, v20

    move-object/from16 v42, v36

    move-object/from16 v20, v39

    move-object/from16 v39, v14

    move-object/from16 v36, v34

    move-object/from16 v14, v47

    move-object/from16 v34, v29

    move-object/from16 v29, v40

    move-object/from16 v40, v15

    move-object/from16 v15, v52

    .line 2854
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, v7}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x0

    .line 2855
    invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/16 v2, 0x10

    .line 2856
    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setGravity(I)V

    const/16 v6, 0xa

    .line 2857
    invoke-static {v7, v6}, Ld;->a(Landroid/content/Context;I)I

    move-result v4

    const/16 v10, 0x8

    invoke-static {v7, v10}, Ld;->a(Landroid/content/Context;I)I

    move-result v9

    invoke-static {v7, v6}, Ld;->a(Landroid/content/Context;I)I

    move-result v2

    invoke-static {v7, v10}, Ld;->a(Landroid/content/Context;I)I

    move-result v3

    invoke-virtual {v0, v4, v9, v2, v3}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 2858
    invoke-static {v7, v6}, Ld;->a(Landroid/content/Context;I)I

    move-result v2

    const/4 v4, 0x1

    invoke-static {v7, v4}, Ld;->a(Landroid/content/Context;I)I

    move-result v3

    const-string v4, "dhECaAETEQ=="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    const/4 v9, -0x1

    invoke-static {v9, v2, v3, v4}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 2859
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v10, -0x2

    invoke-direct {v2, v9, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/4 v3, 0x6

    .line 2860
    invoke-static {v7, v3}, Ld;->a(Landroid/content/Context;I)I

    move-result v4

    iput v4, v2, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    .line 2861
    aput-object v0, v61, v12

    .line 2863
    new-instance v4, Landroid/widget/ImageView;

    invoke-direct {v4, v7}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 2864
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v5, 0x14

    invoke-static {v7, v5}, Ld;->a(Landroid/content/Context;I)I

    move-result v5

    const/16 v6, 0x14

    invoke-static {v7, v6}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    invoke-direct {v3, v5, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v4, v3}, Landroid/widget/ImageView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 2865
    sget-object v3, Landroid/widget/ImageView$ScaleType;->CENTER_INSIDE:Landroid/widget/ImageView$ScaleType;

    invoke-virtual {v4, v3}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    .line 2866
    invoke-virtual {v4}, Landroid/widget/ImageView;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v3

    check-cast v3, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v6, 0x8

    .line 2867
    invoke-static {v7, v6}, Ld;->a(Landroid/content/Context;I)I

    move-result v5

    iput v5, v3, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    .line 2868
    const-string v3, "dhECaAETEQ=="

    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v3

    invoke-static/range {v50 .. v50}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v5

    const/16 v6, 0x14

    invoke-static {v7, v6, v3, v5}, Ld;->c(Landroid/content/Context;III)Landroid/graphics/drawable/Drawable;

    move-result-object v3

    invoke-virtual {v4, v3}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 2869
    invoke-virtual {v0, v4}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2870
    aput-object v4, v65, v12

    .line 2872
    new-instance v3, Landroid/widget/TextView;

    invoke-direct {v3, v7}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 2873
    const-string v4, "dmQAHA9nFQ=="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-virtual {v3, v4}, Landroid/widget/TextView;->setTextColor(I)V

    const/high16 v6, 0x41400000  # 12.0f

    .line 2874
    invoke-virtual {v3, v6}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v4, 0x1

    const/4 v5, 0x0

    .line 2875
    invoke-virtual {v3, v5, v4}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    .line 2876
    aput-object v3, v60, v12

    .line 2877
    invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 2878
    invoke-virtual {v1, v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 2879
    invoke-static {v0}, Ld;->applyTactileTouch(Landroid/view/View;)V

    add-int/lit8 v12, v12, 0x1

    move-object/from16 v0, p2

    move-object/from16 v5, v16

    move-object/from16 v14, v39

    move-object/from16 v15, v40

    move-object/from16 v2, v59

    move-object/from16 v4, v60

    move-object/from16 v6, v61

    move-object/from16 v9, v65

    move-object/from16 v3, v69

    move-object/from16 v10, v74

    move-object/from16 v33, v76

    move-object/from16 v39, v20

    move-object/from16 v40, v29

    move-object/from16 v29, v34

    move-object/from16 v20, v35

    move-object/from16 v34, v36

    move-object/from16 v36, v42

    move-object/from16 v35, v44

    move-object/from16 v42, v45

    move-object/from16 v44, v75

    move-object/from16 v45, v8

    move-object v8, v7

    move-object/from16 v7, p7

    goto/16 :goto_b48
.end method

.method public static b()Ljava/lang/String;
    .registers 1

    .line 81
    invoke-static {}, Le;->i()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static b(Landroid/app/Activity;)V
    .registers 11

    if-eqz p0, :cond_79

    .line 400
    invoke-static {p0}, Ld;->e(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_9

    goto :goto_79

    .line 402
    :cond_9
    sget-object v0, Ld;->d:Ljava/lang/String;

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/app/Activity;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    .line 403
    sget-object v2, Ld;->g:Ljava/lang/String;

    const/16 v3, 0xa

    invoke-interface {v0, v2, v3}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v3

    add-int/lit8 v3, v3, -0x1

    .line 404
    invoke-static {v1, v3}, Ljava/lang/Math;->max(II)I

    move-result v1

    .line 405
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    invoke-interface {v3, v2, v1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 407
    new-instance v2, Ld$25;

    invoke-direct {v2, v0, p0, v1}, Ld$25;-><init>(Landroid/content/SharedPreferences;Landroid/app/Activity;I)V

    invoke-virtual {p0, v2}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 429
    invoke-static {}, Le;->v()Ljava/lang/String;

    move-result-object v1

    const-string v2, "ICYtSEE="

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v3, ""

    invoke-interface {v0, v2, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 430
    invoke-static {}, Le;->D()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    .line 431
    invoke-static {}, Le;->E()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    .line 432
    invoke-static {p0}, Le;->c(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v8

    .line 434
    invoke-virtual {v5}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_6b

    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_6b

    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_79

    .line 435
    :cond_6b
    new-instance v0, Ljava/lang/Thread;

    new-instance v4, Ld$26;

    move-object v9, p0

    invoke-direct/range {v4 .. v9}, Ld$26;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/app/Activity;)V

    invoke-direct {v0, v4}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 454
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    :cond_79
    :goto_79
    return-void
.end method

.method private static b(Landroid/app/Activity;Landroid/app/Dialog;Landroid/view/View;Ljava/lang/String;IIIILandroid/content/SharedPreferences;)V
    .registers 108

    move-object/from16 v1, p0

    move-object/from16 v0, p2

    move-object/from16 v2, p3

    .line 1651
    :try_start_6
    const-string v3, "NyAocls5OzVIZyU4J0NL"

    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v1, v0, v3}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v3

    .line 1652
    const-string v4, "NyAockowJzJCSjALNkFZOyc="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v1, v0, v4}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v10

    .line 1653
    const-string v4, "PDoiRFs0IClfZzImJ09nNzU0"

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v1, v0, v4}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v4

    .line 1654
    const-string v5, "MTsyckshNTJYSwo9KElRNjUyQko="

    invoke-static {v5}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v1, v0, v5}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v5

    .line 1655
    const-string v6, "ISIZTk0nJiNDTAokKkxWCjYnSV8w"

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v1, v0, v6}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/TextView;

    .line 1656
    const-string v7, "ISIZTk0nJiNDTAogKUZdOycZXkw0IDNe"

    invoke-static {v7}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-static {v1, v0, v7}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v7

    check-cast v7, Landroid/widget/TextView;

    .line 1657
    const-string v11, "NjU0SWc2ITRfXTsgGV5MNCAzXg=="

    invoke-static {v11}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-static {v1, v0, v11}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v11

    .line 1659
    const-string v12, "OT0oSFknCzZEVDkLNV1dNj0nQWc6MiBISg=="

    invoke-static {v12}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-static {v1, v0, v12}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v12

    .line 1660
    const-string v13, "ISIZXkgwNy9MVAo7IEtdJwsyTF8="

    invoke-static {v13}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-static {v1, v0, v13}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v13

    check-cast v13, Landroid/widget/TextView;

    .line 1661
    const-string v14, "ISIZT0o0OiJyVjQ5Iw=="

    invoke-static {v14}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-static {v1, v0, v14}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v14

    check-cast v14, Landroid/widget/TextView;

    .line 1662
    const-string v14, "ISIZT0o0OiJyTDQzKkRWMA=="

    invoke-static {v14}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-static {v1, v0, v14}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v14

    check-cast v14, Landroid/widget/TextView;

    .line 1664
    const-string v14, "NjsoWVk8OiNfZyYxIUBdOyAjSWc2OyhZSjo4"

    invoke-static {v14}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-static {v1, v0, v14}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v14

    .line 1665
    const-string v15, "JjEhQF07IBlPWSY9JQ=="

    invoke-static {v15}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v1, v0, v15}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v15

    .line 1666
    const-string v16, "JjEhQF07IBldSjo="

    move-object/from16 p5, v15

    invoke-static/range {v16 .. v16}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v1, v0, v15}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v15

    .line 1667
    const-string v16, "ISIZXl0yOSNDTAo2J15RNg=="

    move-object/from16 p6, v15

    invoke-static/range {v16 .. v16}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v1, v0, v15}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v15

    check-cast v15, Landroid/widget/TextView;

    .line 1668
    const-string v16, "ISIZXl0yOSNDTAokNEI="

    move-object/from16 p7, v15

    invoke-static/range {v16 .. v16}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v1, v0, v15}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v15

    check-cast v15, Landroid/widget/TextView;

    .line 1670
    const-string v16, "NjsoWVk8OiNfZyU4J0NnPDogQg=="

    move-object/from16 v17, v15

    invoke-static/range {v16 .. v16}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v1, v0, v15}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v15

    .line 1671
    const-string v16, "ISIZRFYzOxlZUTAmGVlRITgj"

    move-object/from16 v18, v15

    invoke-static/range {v16 .. v16}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v1, v0, v15}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v15

    check-cast v15, Landroid/widget/TextView;

    .line 1672
    const-string v16, "ISIZRFYzOxlZUTAmGVlZMjgvQ10="

    move-object/from16 v19, v15

    invoke-static/range {v16 .. v16}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v1, v0, v15}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v15

    move-object/from16 v16, v15

    check-cast v16, Landroid/widget/TextView;

    .line 1673
    const-string v15, "NzUiSl0KPShLVwokL0FU"

    invoke-static {v15}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v1, v0, v15}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v15

    check-cast v15, Landroid/widget/TextView;

    .line 1675
    const-string v20, "NzUoQ10nCy5IWTExNHJOPCczTFQ="

    move-object/from16 v21, v15

    invoke-static/range {v20 .. v20}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v1, v0, v15}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v15

    .line 1676
    const-string v20, "OTU/Qk0hCydbWSE1NHJaNDAhSA=="

    move-object/from16 v22, v15

    invoke-static/range {v20 .. v20}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v1, v0, v15}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v15

    .line 1677
    const-string v20, "PCIZWVEwJhlMTjQgJ18="

    move-object/from16 v23, v15

    invoke-static/range {v20 .. v20}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v1, v0, v15}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v15

    .line 1678
    const-string v20, "PCIZW10nPSBEXTELJExcMjE="

    move-object/from16 v24, v15

    invoke-static/range {v20 .. v20}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v1, v0, v15}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v15

    .line 1679
    const-string v20, "ISIZQVEjMRlEVjE9JUxMOiY="

    move-object/from16 v25, v15

    invoke-static/range {v20 .. v20}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v1, v0, v15}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v15

    check-cast v15, Landroid/widget/TextView;

    .line 1680
    const-string v20, "MTsyclc7OC9DXQo9KElRNjUyQko="

    move-object/from16 v26, v15

    invoke-static/range {v20 .. v20}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v1, v0, v15}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v15

    .line 1681
    const-string v20, "NjsoWVk8OiNfZzgxMl9RNicZT107ICk="

    move-object/from16 v27, v15

    invoke-static/range {v20 .. v20}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v1, v0, v15}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v15

    .line 1682
    const-string v20, "ISIZQF0hJi9OCQoiJ0E="

    move-object/from16 v28, v15

    invoke-static/range {v20 .. v20}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v1, v0, v15}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v15

    check-cast v15, Landroid/widget/TextView;

    .line 1683
    const-string v20, "ISIZQF0hJi9OCQo4JEE="

    move-object/from16 v29, v15

    invoke-static/range {v20 .. v20}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v1, v0, v15}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v15

    move-object/from16 v20, v15

    check-cast v20, Landroid/widget/TextView;

    .line 1684
    const-string v15, "ISIZQF0hJi9OCgoiJ0E="

    invoke-static {v15}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v1, v0, v15}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v15

    check-cast v15, Landroid/widget/TextView;

    .line 1685
    const-string v30, "ISIZQF0hJi9OCgo4JEE="

    move-object/from16 v31, v15

    invoke-static/range {v30 .. v30}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v1, v0, v15}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v15

    check-cast v15, Landroid/widget/TextView;

    .line 1686
    const-string v30, "ISIZQF0hJi9OCwoiJ0E="

    move-object/from16 v32, v15

    invoke-static/range {v30 .. v30}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v1, v0, v15}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v15

    check-cast v15, Landroid/widget/TextView;

    .line 1687
    const-string v30, "ISIZQF0hJi9OCwo4JEE="

    move-object/from16 v33, v15

    invoke-static/range {v30 .. v30}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v1, v0, v15}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v15

    check-cast v15, Landroid/widget/TextView;

    .line 1689
    const-string v30, "JzsxckgwJi1yCQ=="

    move-object/from16 v34, v15

    invoke-static/range {v30 .. v30}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v1, v0, v15}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v15

    .line 1690
    const-string v30, "JzsxckgwJi1yCg=="

    move-object/from16 v35, v15

    invoke-static/range {v30 .. v30}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v1, v0, v15}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v15

    .line 1691
    const-string v30, "JzsxckgwJi1yCw=="

    move-object/from16 v36, v15

    invoke-static/range {v30 .. v30}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v1, v0, v15}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v15

    .line 1692
    const-string v30, "JzsxckgwJi1yDA=="

    move-object/from16 v37, v15

    invoke-static/range {v30 .. v30}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v1, v0, v15}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v15

    .line 1693
    const-string v30, "JzsxckgwJi1yDQ=="

    move-object/from16 v38, v15

    invoke-static/range {v30 .. v30}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v1, v0, v15}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v15

    .line 1695
    const-string v30, "PCIZXV0nPxlEWzo6GRw="

    move-object/from16 v39, v15

    invoke-static/range {v30 .. v30}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v1, v0, v15}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v15

    check-cast v15, Landroid/widget/ImageView;

    .line 1696
    const-string v30, "PCIZXV0nPxlEWzo6GR8="

    move-object/from16 v40, v15

    invoke-static/range {v30 .. v30}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v1, v0, v15}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v15

    check-cast v15, Landroid/widget/ImageView;

    .line 1697
    const-string v30, "PCIZXV0nPxlEWzo6GR4="

    move-object/from16 v41, v15

    invoke-static/range {v30 .. v30}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v1, v0, v15}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v15

    check-cast v15, Landroid/widget/ImageView;

    .line 1698
    const-string v30, "PCIZXV0nPxlEWzo6GRk="

    move-object/from16 v42, v15

    invoke-static/range {v30 .. v30}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v1, v0, v15}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v15

    check-cast v15, Landroid/widget/ImageView;

    .line 1699
    const-string v30, "PCIZXV0nPxlEWzo6GRg="

    move-object/from16 v43, v15

    invoke-static/range {v30 .. v30}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v1, v0, v15}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v15

    move-object/from16 v30, v15

    check-cast v30, Landroid/widget/ImageView;

    .line 1701
    const-string v15, "ISIZXV0nPxkc"

    invoke-static {v15}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v1, v0, v15}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v15

    check-cast v15, Landroid/widget/TextView;

    .line 1702
    const-string v44, "ISIZXV0nPxkf"

    move-object/from16 v45, v15

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v1, v0, v15}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v15

    check-cast v15, Landroid/widget/TextView;

    .line 1703
    const-string v44, "ISIZXV0nPxke"

    move-object/from16 v46, v15

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v1, v0, v15}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v15

    check-cast v15, Landroid/widget/TextView;

    .line 1704
    const-string v44, "ISIZXV0nPxkZ"

    move-object/from16 v47, v15

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v1, v0, v15}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v15

    check-cast v15, Landroid/widget/TextView;

    .line 1705
    const-string v44, "ISIZXV0nPxkY"

    move-object/from16 v48, v15

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v1, v0, v15}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v15

    check-cast v15, Landroid/widget/TextView;

    .line 1707
    const-string v44, "ISIZWUogJzJySzA3M19d"

    move-object/from16 v49, v15

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v1, v0, v15}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v15

    check-cast v15, Landroid/widget/TextView;

    .line 1708
    const-string v44, "ISIZWUogJzJyWTY3I15L"

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-static {v1, v0, v9}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v9

    check-cast v9, Landroid/widget/TextView;

    .line 1709
    const-string v44, "ISIZWUogJzJySyAkNkJKIQ=="

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v1, v0, v8}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v8

    check-cast v8, Landroid/widget/TextView;

    .line 1711
    const-string v44, "NyAockw6MyFBXQo3KUBINCYvXlc7"

    move-object/from16 v50, v7

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-static {v1, v0, v7}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v7

    .line 1712
    const-string v44, "ISIZWVcyMypIZzY7K11ZJz01QlYKICNVTA=="

    move-object/from16 v51, v6

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v1, v0, v6}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/TextView;

    .line 1713
    const-string v44, "PCIZWVcyMypIZzY7K11ZJz01QlYKNTRfVyI="

    move-object/from16 v52, v6

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v1, v0, v6}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/TextView;

    .line 1714
    const-string v44, "NjsoWVk8OiNfZzMxJ1lNJzEZWVk3OCM="

    move-object/from16 v53, v6

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v1, v0, v6}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v6

    .line 1715
    const-string v44, "ISIZTlc5CzZfVw=="

    move-object/from16 v54, v6

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v1, v0, v6}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/TextView;

    .line 1717
    const-string v44, "PCIZTlc4JBlEWzo6GRw="

    move-object/from16 v55, v6

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v1, v0, v6}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/ImageView;

    .line 1718
    const-string v44, "PCIZTlc4JBlEWzo6GR8="

    move-object/from16 v56, v6

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v1, v0, v6}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/ImageView;

    .line 1719
    const-string v44, "PCIZTlc4JBlEWzo6GR4="

    move-object/from16 v57, v6

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v1, v0, v6}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/ImageView;

    .line 1720
    const-string v44, "PCIZTlc4JBlEWzo6GRk="

    move-object/from16 v58, v6

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v1, v0, v6}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/ImageView;

    .line 1721
    const-string v44, "PCIZTlc4JBlEWzo6GRg="

    move-object/from16 v59, v6

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v1, v0, v6}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/ImageView;

    .line 1722
    const-string v44, "PCIZTlc4JBlEWzo6GRs="

    move-object/from16 v60, v6

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v1, v0, v6}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/ImageView;

    .line 1724
    const-string v44, "NzUiSl0KNy5IWz4LNBxnNzU1RFs="

    move-object/from16 v61, v6

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v1, v0, v6}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/TextView;

    .line 1725
    const-string v44, "NzUiSl0KNy5IWz4LNBxnJSYp"

    move-object/from16 v62, v6

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v1, v0, v6}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/TextView;

    .line 1726
    const-string v44, "NzUiSl0KNzRCSyYLNB9nMyYjSA=="

    move-object/from16 v63, v6

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v1, v0, v6}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/TextView;

    .line 1727
    const-string v44, "NzUiSl0KNzRCSyYLNB9nNzU1RFs="

    move-object/from16 v64, v6

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v1, v0, v6}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/TextView;

    .line 1728
    const-string v44, "NzUiSl0KNy5IWz4LNB9nJSYp"

    move-object/from16 v65, v6

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v1, v0, v6}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/TextView;

    .line 1729
    const-string v44, "NzUiSl0KNzRCSyYLNB5nMyYjSA=="

    move-object/from16 v66, v6

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v1, v0, v6}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/TextView;

    .line 1730
    const-string v44, "NzUiSl0KNzRCSyYLNB5nNzU1RFs="

    move-object/from16 v67, v6

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v1, v0, v6}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/TextView;

    .line 1731
    const-string v44, "NzUiSl0KNy5IWz4LNB5nJSYp"

    move-object/from16 v68, v6

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v1, v0, v6}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/TextView;

    .line 1732
    const-string v44, "NzUiSl0KNy5IWz4LNBlnNzU1RFs="

    move-object/from16 v69, v6

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v1, v0, v6}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/TextView;

    .line 1733
    const-string v44, "NzUiSl0KNy5IWz4LNBlnJSYp"

    move-object/from16 v70, v6

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v1, v0, v6}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/TextView;

    .line 1734
    const-string v44, "NzUiSl0KNzRCSyYLNBhnMyYjSA=="

    move-object/from16 v71, v6

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v1, v0, v6}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/TextView;

    .line 1735
    const-string v44, "NzUiSl0KNzRCSyYLNBhnNzU1RFs="

    move-object/from16 v72, v6

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v1, v0, v6}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/TextView;

    .line 1736
    const-string v44, "NzUiSl0KNy5IWz4LNBhnJSYp"

    move-object/from16 v73, v6

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v1, v0, v6}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/TextView;

    .line 1737
    const-string v44, "NzUiSl0KNy5IWz4LNBtnMyYjSA=="

    move-object/from16 v74, v6

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v1, v0, v6}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/TextView;

    .line 1738
    const-string v44, "NzUiSl0KNy5IWz4LNBtnNzU1RFs="

    move-object/from16 v75, v6

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v1, v0, v6}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/TextView;

    .line 1739
    const-string v44, "NzUiSl0KNy5IWz4LNBtnJSYp"

    move-object/from16 v76, v6

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v1, v0, v6}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/TextView;

    .line 1741
    const-string v44, "ISIZTlc4JBlLSjAxGV1KMDA1"

    move-object/from16 v77, v6

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v1, v0, v6}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/TextView;

    .line 1742
    const-string v44, "ISIZTlc4JBlLSjAxGU5QNCA1"

    move-object/from16 v78, v7

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-static {v1, v0, v7}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v7

    check-cast v7, Landroid/widget/TextView;

    .line 1743
    invoke-static {v1}, Ld;->q(Landroid/content/Context;)I

    move-result v44

    .line 1744
    invoke-static {v1}, Ld;->r(Landroid/content/Context;)I

    move-result v79

    if-eqz v6, :cond_42e

    move-object/from16 v80, v14

    .line 1746
    invoke-static/range {v44 .. v44}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v6, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_430

    :cond_42e
    move-object/from16 v80, v14

    :goto_430
    if-eqz v7, :cond_439

    .line 1749
    invoke-static/range {v79 .. v79}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v7, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1752
    :cond_439
    const-string v14, "ITUkclwgJidZUTo6GVpdMD8qVA=="

    invoke-static {v14}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-static {v1, v0, v14}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v14

    .line 1753
    const-string v44, "ITUkclwgJidZUTo6GUBXOyAuQUE="

    move-object/from16 v79, v14

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-static {v1, v0, v14}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v14

    .line 1754
    const-string v44, "ISIZWVk3CzFIXT44Pw=="

    move-object/from16 v81, v14

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-static {v1, v0, v14}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v14

    check-cast v14, Landroid/widget/TextView;

    .line 1755
    const-string v44, "ISIZWVk3CytCViE8KlQ="

    move-object/from16 v82, v14

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-static {v1, v0, v14}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v14

    check-cast v14, Landroid/widget/TextView;

    .line 1756
    const-string v44, "ISIZXUo8NyNyTzAxLUFBCiInQQ=="

    move-object/from16 v83, v14

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-static {v1, v0, v14}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v14

    check-cast v14, Landroid/widget/TextView;

    .line 1757
    const-string v44, "ISIZXUo8NyNyTzAxLUFBCiczTw=="

    move-object/from16 v84, v14

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-static {v1, v0, v14}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v14

    check-cast v14, Landroid/widget/TextView;

    .line 1758
    const-string v44, "ISIZVF00JipUZyUmL05d"

    move-object/from16 v85, v14

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-static {v1, v0, v14}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v14

    check-cast v14, Landroid/widget/TextView;

    .line 1759
    const-string v44, "ISIZXUo8NyNyVTo6MkVULAs1WFo="

    move-object/from16 v86, v14

    invoke-static/range {v44 .. v44}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-static {v1, v0, v14}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v14

    move-object/from16 v44, v14

    check-cast v44, Landroid/widget/TextView;

    .line 1760
    const-string v14, "NzUiSl0KNiNeTAoiJ0FNMA=="

    invoke-static {v14}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-static {v1, v0, v14}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v14

    check-cast v14, Landroid/widget/TextView;

    .line 1761
    const-string v87, "ISIZVF00JipUZzE9NU5XIDoy"

    move-object/from16 v88, v14

    invoke-static/range {v87 .. v87}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-static {v1, v0, v14}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v14

    check-cast v14, Landroid/widget/TextView;

    .line 1763
    const-string v87, "NyAoclshNRlMWyE9KUM="

    move-object/from16 v89, v14

    invoke-static/range {v87 .. v87}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-static {v1, v0, v14}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v14

    check-cast v14, Landroid/widget/Button;

    .line 1764
    const-string v87, "NyAocls6OjJEViAxGUtKMDE="

    move-object/from16 v90, v14

    invoke-static/range {v87 .. v87}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-static {v1, v0, v14}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v14

    check-cast v14, Landroid/widget/Button;

    move-object/from16 v87, v14

    if-eqz v4, :cond_4fb

    .line 1767
    const-string v91, "dhcEaQ0QZQ=="

    invoke-static/range {v91 .. v91}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v91

    invoke-static/range {v91 .. v91}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v14

    move-object/from16 v91, v7

    const/4 v7, 0x2

    invoke-static {v1, v7}, Ld;->a(Landroid/content/Context;I)I

    move-result v7

    move-object/from16 v93, v6

    const/4 v6, 0x0

    invoke-static {v14, v7, v6, v6}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v7

    invoke-virtual {v4, v7}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    goto :goto_4ff

    :cond_4fb
    move-object/from16 v93, v6

    move-object/from16 v91, v7

    .line 1769
    :goto_4ff
    const-string v4, "MT0nQVcyCzZBWTsnGV9XOiA="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v1, v0, v4}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v4

    if-eqz v4, :cond_50f

    const/4 v6, 0x0

    .line 1771
    invoke-virtual {v4, v6}, Landroid/view/View;->setBackgroundColor(I)V

    .line 1773
    :cond_50f
    const-string v4, "MT0nQVcyCzZBWTsnGV5bJzsqQQ=="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v1, v0, v4}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v4

    if-eqz v4, :cond_51f

    const/4 v6, 0x0

    .line 1775
    invoke-virtual {v4, v6}, Landroid/view/View;->setBackgroundColor(I)V

    .line 1778
    :cond_51f
    const-string v4, "Iz0jWmchOzZyTz09MkhnJjwnSVci"

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v1, v0, v4}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v4

    const/4 v6, -0x1

    if-eqz v4, :cond_553

    .line 1780
    invoke-static {}, Ld;->d()Landroid/graphics/drawable/Drawable;

    move-result-object v7

    invoke-virtual {v4, v7}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 v7, 0x0

    .line 1781
    invoke-virtual {v4, v7}, Landroid/view/View;->setClickable(Z)V

    .line 1782
    invoke-virtual {v4, v7}, Landroid/view/View;->setFocusable(Z)V

    .line 1783
    new-instance v7, Landroid/widget/FrameLayout$LayoutParams;

    const/16 v14, 0x24

    .line 1785
    invoke-static {v1, v14}, Ld;->a(Landroid/content/Context;I)I

    move-result v14

    .line 1783
    invoke-direct {v7, v6, v14}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    const/16 v14, 0x30

    .line 1787
    iput v14, v7, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 1788
    invoke-virtual {v4, v7}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v7, 0x0

    .line 1789
    invoke-virtual {v4, v7}, Landroid/view/View;->setVisibility(I)V

    .line 1790
    invoke-virtual {v4}, Landroid/view/View;->bringToFront()V

    .line 1793
    :cond_553
    const-string v4, "Iz0jWmc3OzJZVzgLMUVRITEZXlA0MCla"

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v1, v0, v4}, Ld;->a(Landroid/app/Activity;Landroid/view/View;Ljava/lang/String;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_586

    .line 1795
    invoke-static {}, Ld;->e()Landroid/graphics/drawable/Drawable;

    move-result-object v4

    invoke-virtual {v0, v4}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 v7, 0x0

    .line 1796
    invoke-virtual {v0, v7}, Landroid/view/View;->setClickable(Z)V

    .line 1797
    invoke-virtual {v0, v7}, Landroid/view/View;->setFocusable(Z)V

    .line 1798
    new-instance v4, Landroid/widget/FrameLayout$LayoutParams;

    const/16 v7, 0x2a

    .line 1800
    invoke-static {v1, v7}, Ld;->a(Landroid/content/Context;I)I

    move-result v7

    .line 1798
    invoke-direct {v4, v6, v7}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    const/16 v7, 0x50

    .line 1802
    iput v7, v4, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 1803
    invoke-virtual {v0, v4}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v7, 0x0

    .line 1804
    invoke-virtual {v0, v7}, Landroid/view/View;->setVisibility(I)V

    .line 1805
    invoke-virtual {v0}, Landroid/view/View;->bringToFront()V

    :cond_586
    if-eqz v3, :cond_58b

    .line 1809
    invoke-virtual {v3}, Landroid/view/View;->bringToFront()V

    :cond_58b
    if-eqz v10, :cond_590

    .line 1812
    invoke-virtual {v10}, Landroid/view/View;->bringToFront()V

    .line 1815
    :cond_590
    invoke-static/range {v90 .. v90}, Ld;->removeElevation(Landroid/view/View;)V

    .line 1816
    invoke-static/range {v87 .. v87}, Ld;->removeElevation(Landroid/view/View;)V

    .line 1817
    invoke-static {v3}, Ld;->removeElevation(Landroid/view/View;)V

    .line 1818
    invoke-static {v10}, Ld;->removeElevation(Landroid/view/View;)V

    .line 1819
    invoke-static/range {v78 .. v78}, Ld;->removeElevation(Landroid/view/View;)V

    .line 1820
    invoke-static {v11}, Ld;->removeElevation(Landroid/view/View;)V

    .line 1821
    invoke-static/range {v80 .. v80}, Ld;->removeElevation(Landroid/view/View;)V

    .line 1822
    invoke-static/range {v18 .. v18}, Ld;->removeElevation(Landroid/view/View;)V

    .line 1823
    invoke-static/range {v23 .. v23}, Ld;->removeElevation(Landroid/view/View;)V

    .line 1824
    invoke-static/range {v28 .. v28}, Ld;->removeElevation(Landroid/view/View;)V

    .line 1825
    invoke-static/range {v79 .. v79}, Ld;->removeElevation(Landroid/view/View;)V

    .line 1826
    invoke-static/range {v81 .. v81}, Ld;->removeElevation(Landroid/view/View;)V

    .line 1827
    invoke-static/range {v35 .. v35}, Ld;->removeElevation(Landroid/view/View;)V

    .line 1828
    invoke-static/range {v36 .. v36}, Ld;->removeElevation(Landroid/view/View;)V

    .line 1829
    invoke-static/range {v37 .. v37}, Ld;->removeElevation(Landroid/view/View;)V

    .line 1830
    invoke-static/range {v38 .. v38}, Ld;->removeElevation(Landroid/view/View;)V

    .line 1831
    invoke-static/range {v39 .. v39}, Ld;->removeElevation(Landroid/view/View;)V

    .line 1833
    invoke-static {v3}, Ld;->applyTactileTouch(Landroid/view/View;)V

    .line 1834
    invoke-static {v10}, Ld;->applyTactileTouch(Landroid/view/View;)V

    .line 1835
    invoke-static/range {p5 .. p5}, Ld;->applyTactileTouch(Landroid/view/View;)V

    .line 1836
    invoke-static/range {p6 .. p6}, Ld;->applyTactileTouch(Landroid/view/View;)V

    .line 1837
    invoke-static/range {v23 .. v23}, Ld;->applyTactileTouch(Landroid/view/View;)V

    .line 1838
    invoke-static/range {v78 .. v78}, Ld;->applyTactileTouch(Landroid/view/View;)V

    .line 1839
    invoke-static/range {v79 .. v79}, Ld;->applyTactileTouch(Landroid/view/View;)V

    .line 1840
    invoke-static/range {v81 .. v81}, Ld;->applyTactileTouch(Landroid/view/View;)V

    .line 1841
    invoke-static/range {v90 .. v90}, Ld;->applyTactileTouch(Landroid/view/View;)V

    .line 1842
    invoke-static/range {v87 .. v87}, Ld;->applyTactileTouch(Landroid/view/View;)V

    .line 1843
    invoke-static/range {v35 .. v35}, Ld;->applyTactileTouch(Landroid/view/View;)V

    .line 1844
    invoke-static/range {v36 .. v36}, Ld;->applyTactileTouch(Landroid/view/View;)V

    .line 1845
    invoke-static/range {v37 .. v37}, Ld;->applyTactileTouch(Landroid/view/View;)V

    .line 1846
    invoke-static/range {v38 .. v38}, Ld;->applyTactileTouch(Landroid/view/View;)V

    .line 1847
    invoke-static/range {v39 .. v39}, Ld;->applyTactileTouch(Landroid/view/View;)V
    :try_end_5f0
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_5f0} :catch_b9b

    .line 1849
    const-string v0, "dhJ3aw0TbQ=="

    const-string v4, "dhF0aAATZA=="

    const/4 v14, 0x1

    if-eqz v3, :cond_61c

    .line 1850
    :try_start_5f7
    new-instance v7, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v7}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 1851
    invoke-virtual {v7, v14}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    .line 1852
    invoke-static {v0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v94

    invoke-static/range {v94 .. v94}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    invoke-virtual {v7, v6}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 1853
    invoke-static {v1, v14}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v94

    invoke-static/range {v94 .. v94}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v14

    invoke-virtual {v7, v6, v14}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    .line 1854
    invoke-virtual {v3, v7}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V
    :try_end_61c
    .catch Ljava/lang/Exception; {:try_start_5f7 .. :try_end_61c} :catch_b9b

    .line 1856
    :cond_61c
    const-string v6, "dhACaQ4TEQ=="

    const/16 v7, 0xa

    const-string v14, "dhJzawsTEg=="

    if-eqz v10, :cond_64b

    .line 1857
    :try_start_624
    invoke-static {v14}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v94

    move-object/from16 v95, v0

    invoke-static/range {v94 .. v94}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    move-object/from16 v94, v4

    invoke-static {v1, v7}, Ld;->a(Landroid/content/Context;I)I

    move-result v4

    move-object/from16 v96, v6

    const/4 v7, 0x1

    invoke-static {v1, v7}, Ld;->a(Landroid/content/Context;I)I

    move-result v6

    invoke-static/range {v96 .. v96}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v7

    invoke-static {v0, v4, v6, v7}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v0

    invoke-virtual {v10, v0}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V
    :try_end_64a
    .catch Ljava/lang/Exception; {:try_start_624 .. :try_end_64a} :catch_b9b

    goto :goto_651

    :cond_64b
    move-object/from16 v95, v0

    move-object/from16 v94, v4

    move-object/from16 v96, v6

    .line 1859
    :goto_651
    const-string v0, "dhJ+a3kTFw=="

    const/16 v4, 0xe

    if-eqz v11, :cond_67a

    .line 1860
    :try_start_657
    invoke-static {v0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    invoke-static {v1, v4}, Ld;->a(Landroid/content/Context;I)I

    move-result v7

    move-object/from16 v97, v0

    const/4 v4, 0x1

    invoke-static {v1, v4}, Ld;->a(Landroid/content/Context;I)I

    move-result v0

    invoke-static/range {v94 .. v94}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    invoke-static {v6, v7, v0, v4}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v0

    invoke-virtual {v11, v0}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V
    :try_end_679
    .catch Ljava/lang/Exception; {:try_start_657 .. :try_end_679} :catch_b9b

    goto :goto_67c

    :cond_67a
    move-object/from16 v97, v0

    .line 1862
    :goto_67c
    const-string v0, "dmR+FAkXZg=="

    const-string v4, "dmV2bwFtZQ=="

    const-string v6, "dmN+GwgQFQ=="

    if-eqz v5, :cond_6c3

    .line 1863
    :try_start_684
    new-instance v7, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v7}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const/4 v11, 0x1

    .line 1864
    invoke-virtual {v7, v11}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    .line 1865
    sget-object v11, Ld;->c:Ljava/lang/String;

    invoke-virtual {v11, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_6a1

    .line 1866
    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-static {v11}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v11

    invoke-virtual {v7, v11}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    goto :goto_6c0

    .line 1867
    :cond_6a1
    sget-object v11, Ld;->b:Ljava/lang/String;

    invoke-virtual {v11, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_6b5

    .line 1868
    invoke-static {v0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-static {v11}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v11

    invoke-virtual {v7, v11}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    goto :goto_6c0

    .line 1870
    :cond_6b5
    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-static {v11}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v11

    invoke-virtual {v7, v11}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 1872
    :goto_6c0
    invoke-virtual {v5, v7}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_6c3
    const/16 v7, 0xc

    if-eqz v12, :cond_6ea

    .line 1875
    invoke-static {v14}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    invoke-static {v11}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v11

    invoke-static {v1, v7}, Ld;->a(Landroid/content/Context;I)I

    move-result v14

    move-object/from16 v98, v0

    const/4 v7, 0x1

    invoke-static {v1, v7}, Ld;->a(Landroid/content/Context;I)I

    move-result v0

    invoke-static/range {v96 .. v96}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v7

    invoke-static {v11, v14, v0, v7}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v0

    invoke-virtual {v12, v0}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    goto :goto_6ec

    :cond_6ea
    move-object/from16 v98, v0

    :goto_6ec
    const/4 v0, 0x0

    if-eqz v13, :cond_711

    .line 1878
    const-string v7, "Ax0WDWgUBxU="

    invoke-static {v7}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v13, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1879
    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    invoke-static {v7}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v7

    const/16 v11, 0xc

    invoke-static {v1, v11, v7}, Ld;->b(Landroid/content/Context;II)Landroid/graphics/drawable/Drawable;

    move-result-object v7

    .line 1880
    invoke-virtual {v13, v7, v0, v0, v0}, Landroid/widget/TextView;->setCompoundDrawablesWithIntrinsicBounds(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    const/4 v7, 0x5

    .line 1881
    invoke-static {v1, v7}, Ld;->a(Landroid/content/Context;I)I

    move-result v7

    invoke-virtual {v13, v7}, Landroid/widget/TextView;->setCompoundDrawablePadding(I)V
    :try_end_711
    .catch Ljava/lang/Exception; {:try_start_684 .. :try_end_711} :catch_b9b

    :cond_711
    const/4 v7, 0x4

    .line 1883
    const-string v11, "dmJyGgxtFg=="

    if-eqz v15, :cond_737

    .line 1884
    :try_start_716
    const-string v12, "BjElWEow"

    invoke-static {v12}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v15, v12}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1885
    invoke-static {v11}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-static {v12}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v12

    const/16 v13, 0xc

    invoke-static {v1, v13, v12}, Ld;->c(Landroid/content/Context;II)Landroid/graphics/drawable/Drawable;

    move-result-object v12

    .line 1886
    invoke-virtual {v15, v12, v0, v0, v0}, Landroid/widget/TextView;->setCompoundDrawablesWithIntrinsicBounds(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 1887
    invoke-static {v1, v7}, Ld;->a(Landroid/content/Context;I)I

    move-result v12

    invoke-virtual {v15, v12}, Landroid/widget/TextView;->setCompoundDrawablePadding(I)V

    :cond_737
    if-eqz v9, :cond_75a

    .line 1890
    const-string v12, "HDo1WVk7IGZsWzYxNV4="

    invoke-static {v12}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v9, v12}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1891
    invoke-static {v11}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-static {v12}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v12

    const/16 v13, 0xc

    invoke-static {v1, v13, v12}, Ld;->a(Landroid/content/Context;II)Landroid/graphics/drawable/Drawable;

    move-result-object v12

    .line 1892
    invoke-virtual {v9, v12, v0, v0, v0}, Landroid/widget/TextView;->setCompoundDrawablesWithIntrinsicBounds(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 1893
    invoke-static {v1, v7}, Ld;->a(Landroid/content/Context;I)I

    move-result v12

    invoke-virtual {v9, v12}, Landroid/widget/TextView;->setCompoundDrawablePadding(I)V

    :cond_75a
    if-eqz v8, :cond_77d

    .line 1896
    const-string v9, "Z2BpGhgGITZdVycg"

    invoke-static {v9}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1897
    invoke-static {v11}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v9

    const/16 v13, 0xc

    invoke-static {v1, v13, v9}, Ld;->d(Landroid/content/Context;II)Landroid/graphics/drawable/Drawable;

    move-result-object v9

    .line 1898
    invoke-virtual {v8, v9, v0, v0, v0}, Landroid/widget/TextView;->setCompoundDrawablesWithIntrinsicBounds(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    .line 1899
    invoke-static {v1, v7}, Ld;->a(Landroid/content/Context;I)I

    move-result v0

    invoke-virtual {v8, v0}, Landroid/widget/TextView;->setCompoundDrawablePadding(I)V

    :cond_77d
    if-eqz v80, :cond_797

    .line 1902
    invoke-static/range {v95 .. v95}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    const/16 v7, 0xe

    invoke-static {v1, v7}, Ld;->a(Landroid/content/Context;I)I

    move-result v8

    const/4 v7, 0x0

    invoke-static {v0, v8, v7, v7}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v0

    move-object/from16 v7, v80

    invoke-virtual {v7, v0}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_797
    if-eqz v78, :cond_7be

    .line 1905
    invoke-static/range {v97 .. v97}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    const/16 v13, 0xc

    invoke-static {v1, v13}, Ld;->a(Landroid/content/Context;I)I

    move-result v7

    const/4 v8, 0x1

    invoke-static {v1, v8}, Ld;->a(Landroid/content/Context;I)I

    move-result v9

    invoke-static/range {v94 .. v94}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v8

    invoke-static {v0, v7, v9, v8}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v0

    move-object/from16 v7, v78

    invoke-virtual {v7, v0}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    goto :goto_7c0

    :cond_7be
    move-object/from16 v7, v78

    :goto_7c0
    if-eqz v54, :cond_7e0

    const/16 v0, 0x10

    .line 1908
    invoke-static {v1, v0}, Ld;->a(Landroid/content/Context;I)I

    move-result v0

    const/4 v8, 0x1

    invoke-static {v1, v8}, Ld;->a(Landroid/content/Context;I)I

    move-result v9

    invoke-static/range {v94 .. v94}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v8

    const/4 v12, -0x1

    invoke-static {v12, v0, v9, v8}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v0

    move-object/from16 v8, v54

    invoke-virtual {v8, v0}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V
    :try_end_7df
    .catch Ljava/lang/Exception; {:try_start_716 .. :try_end_7df} :catch_b9b

    goto :goto_7e2

    :cond_7e0
    move-object/from16 v8, v54

    .line 1910
    :goto_7e2
    const-string v0, "dhB3a3kQYQ=="

    const/4 v9, 0x6

    if-eqz v55, :cond_823

    .line 1911
    :try_start_7e7
    invoke-static {v0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-static {v12}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v12

    const/16 v13, 0xa

    invoke-static {v1, v13}, Ld;->a(Landroid/content/Context;I)I

    move-result v13

    const/4 v14, 0x0

    invoke-static {v12, v13, v14, v14}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v12

    move-object/from16 v13, v55

    invoke-virtual {v13, v12}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 1912
    const-string v12, "dmRwGH5hYg=="

    invoke-static {v12}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-static {v12}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v12

    invoke-virtual {v13, v12}, Landroid/widget/TextView;->setTextColor(I)V

    .line 1913
    invoke-static {v1, v9}, Ld;->a(Landroid/content/Context;I)I

    move-result v12

    const/4 v14, 0x3

    invoke-static {v1, v14}, Ld;->a(Landroid/content/Context;I)I

    move-result v15

    move-object/from16 v54, v0

    invoke-static {v1, v9}, Ld;->a(Landroid/content/Context;I)I

    move-result v0

    invoke-static {v1, v14}, Ld;->a(Landroid/content/Context;I)I

    move-result v14

    invoke-virtual {v13, v12, v15, v0, v14}, Landroid/widget/TextView;->setPadding(IIII)V

    goto :goto_825

    :cond_823
    move-object/from16 v54, v0

    :goto_825
    const/16 v0, 0x16

    if-eqz v56, :cond_83c

    .line 1915
    const-string v12, "dmBxGA1jbQ=="

    invoke-static {v12}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-static {v12}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v12

    invoke-static {v1, v0, v12}, Ld;->e(Landroid/content/Context;II)Landroid/graphics/drawable/Drawable;

    move-result-object v12

    move-object/from16 v13, v56

    invoke-virtual {v13, v12}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    :cond_83c
    if-eqz v57, :cond_84f

    .line 1916
    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-static {v12}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v12

    invoke-static {v1, v0, v12}, Ld;->a(Landroid/content/Context;II)Landroid/graphics/drawable/Drawable;

    move-result-object v12

    move-object/from16 v13, v57

    invoke-virtual {v13, v12}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    :cond_84f
    if-eqz v58, :cond_862

    .line 1917
    invoke-static/range {v98 .. v98}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-static {v12}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v12

    invoke-static {v1, v0, v12}, Ld;->f(Landroid/content/Context;II)Landroid/graphics/drawable/Drawable;

    move-result-object v12

    move-object/from16 v13, v58

    invoke-virtual {v13, v12}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    :cond_862
    if-eqz v59, :cond_877

    .line 1918
    const-string v12, "dmJ1Gw4TZQ=="

    invoke-static {v12}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-static {v12}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v12

    invoke-static {v1, v0, v12}, Ld;->g(Landroid/content/Context;II)Landroid/graphics/drawable/Drawable;

    move-result-object v12

    move-object/from16 v13, v59

    invoke-virtual {v13, v12}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    :cond_877
    if-eqz v60, :cond_88c

    .line 1919
    const-string v12, "dhJzFH1lFg=="

    invoke-static {v12}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-static {v12}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v12

    invoke-static {v1, v0, v12}, Ld;->h(Landroid/content/Context;II)Landroid/graphics/drawable/Drawable;

    move-result-object v12

    move-object/from16 v13, v60

    invoke-virtual {v13, v12}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    :cond_88c
    if-eqz v61, :cond_89f

    .line 1920
    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-static {v12}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v12

    invoke-static {v1, v0, v12}, Ld;->i(Landroid/content/Context;II)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    move-object/from16 v12, v61

    invoke-virtual {v12, v0}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 1922
    :cond_89f
    invoke-static/range {v54 .. v54}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    invoke-static {v1, v9}, Ld;->a(Landroid/content/Context;I)I

    move-result v12

    const/4 v14, 0x0

    invoke-static {v0, v12, v14, v14}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v0

    .line 1923
    const-string v12, "dhF2awoTEQ=="

    invoke-static {v12}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-static {v12}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v12

    invoke-static {v1, v9}, Ld;->a(Landroid/content/Context;I)I

    move-result v13

    invoke-static {v12, v13, v14, v14}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v12

    .line 1924
    invoke-static/range {v95 .. v95}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-static {v13}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v13

    invoke-static {v1, v9}, Ld;->a(Landroid/content/Context;I)I

    move-result v9

    invoke-static {v13, v9, v14, v14}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v9

    if-eqz v93, :cond_8da

    move-object/from16 v13, v93

    .line 1926
    invoke-virtual {v13, v9}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    goto :goto_8dc

    :cond_8da
    move-object/from16 v13, v93

    :goto_8dc
    if-eqz v62, :cond_8e3

    move-object/from16 v14, v62

    .line 1927
    invoke-virtual {v14, v12}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_8e3
    if-eqz v63, :cond_8ea

    move-object/from16 v14, v63

    .line 1928
    invoke-virtual {v14, v0}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_8ea
    if-eqz v64, :cond_8f1

    move-object/from16 v14, v64

    .line 1930
    invoke-virtual {v14, v9}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_8f1
    if-eqz v65, :cond_8f8

    move-object/from16 v14, v65

    .line 1931
    invoke-virtual {v14, v9}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_8f8
    if-eqz v66, :cond_8ff

    move-object/from16 v14, v66

    .line 1932
    invoke-virtual {v14, v0}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_8ff
    if-eqz v67, :cond_906

    move-object/from16 v14, v67

    .line 1934
    invoke-virtual {v14, v9}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_906
    if-eqz v68, :cond_90d

    move-object/from16 v14, v68

    .line 1935
    invoke-virtual {v14, v9}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_90d
    if-eqz v69, :cond_914

    move-object/from16 v14, v69

    .line 1936
    invoke-virtual {v14, v0}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_914
    if-eqz v91, :cond_91c

    move-object/from16 v14, v91

    .line 1938
    invoke-virtual {v14, v9}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    goto :goto_91e

    :cond_91c
    move-object/from16 v14, v91

    :goto_91e
    if-eqz v70, :cond_925

    move-object/from16 v15, v70

    .line 1939
    invoke-virtual {v15, v12}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_925
    if-eqz v71, :cond_92c

    move-object/from16 v15, v71

    .line 1940
    invoke-virtual {v15, v0}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_92c
    if-eqz v72, :cond_933

    move-object/from16 v15, v72

    .line 1942
    invoke-virtual {v15, v9}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_933
    if-eqz v73, :cond_93a

    move-object/from16 v9, v73

    .line 1943
    invoke-virtual {v9, v12}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_93a
    if-eqz v74, :cond_941

    move-object/from16 v9, v74

    .line 1944
    invoke-virtual {v9, v0}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_941
    if-eqz v75, :cond_948

    move-object/from16 v9, v75

    .line 1946
    invoke-virtual {v9, v0}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_948
    if-eqz v76, :cond_94f

    move-object/from16 v9, v76

    .line 1947
    invoke-virtual {v9, v0}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_94f
    if-eqz v77, :cond_956

    move-object/from16 v9, v77

    .line 1948
    invoke-virtual {v9, v0}, Landroid/widget/TextView;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_956
    if-eqz v87, :cond_993

    .line 1951
    sget-object v9, Ld;->c:Ljava/lang/String;

    invoke-virtual {v9, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_98b

    sget-object v9, Ld;->b:Ljava/lang/String;

    invoke-virtual {v9, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_969

    goto :goto_98b

    :cond_969
    move-object/from16 v9, v87

    const/4 v12, 0x0

    .line 1954
    invoke-virtual {v9, v12}, Landroid/widget/Button;->setVisibility(I)V

    const/16 v12, 0xe

    .line 1955
    invoke-static {v1, v12}, Ld;->a(Landroid/content/Context;I)I

    move-result v12

    const/4 v15, 0x1

    invoke-static {v1, v15}, Ld;->a(Landroid/content/Context;I)I

    move-result v0

    invoke-static/range {v94 .. v94}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-static {v15}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v15

    const/4 v1, -0x1

    invoke-static {v1, v12, v0, v15}, Ld;->a(IIII)Landroid/graphics/drawable/GradientDrawable;

    move-result-object v0

    invoke-virtual {v9, v0}, Landroid/widget/Button;->setBackground(Landroid/graphics/drawable/Drawable;)V

    goto :goto_995

    :cond_98b
    :goto_98b
    move-object/from16 v9, v87

    const/16 v0, 0x8

    .line 1952
    invoke-virtual {v9, v0}, Landroid/widget/Button;->setVisibility(I)V

    goto :goto_995

    :cond_993
    move-object/from16 v9, v87

    :goto_995
    if-eqz v51, :cond_9ec

    .line 1960
    sget-object v0, Ld;->c:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_9b6

    .line 1961
    const-string v0, "BSYpDW4cBA=="

    invoke-static {v0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    move-object/from16 v1, v51

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1962
    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setTextColor(I)V

    goto :goto_9ee

    :cond_9b6
    move-object/from16 v1, v51

    .line 1963
    sget-object v0, Ld;->b:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_9d5

    .line 1964
    const-string v0, "FzU1RFt1Ag99"

    invoke-static {v0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1965
    invoke-static/range {v98 .. v98}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setTextColor(I)V

    goto :goto_9ee

    .line 1967
    :cond_9d5
    const-string v0, "EyYjSBgFOCdD"

    invoke-static {v0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1968
    const-string v0, "dmUDHHphFg=="

    invoke-static {v0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setTextColor(I)V

    goto :goto_9ee

    :cond_9ec
    move-object/from16 v1, v51

    :goto_9ee
    if-eqz v50, :cond_a46

    .line 1972
    sget-object v0, Ld;->c:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_a2f

    sget-object v0, Ld;->b:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_a01

    goto :goto_a2f

    .line 1976
    :cond_a01
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v4, "t9TkDQ=="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-direct {v0, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    move/from16 v4, p4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v4, "dRgjS0w="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    move-object/from16 v6, v50

    invoke-virtual {v6, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1977
    invoke-static {v11}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {v6, v0}, Landroid/widget/TextView;->setTextColor(I)V

    goto :goto_a48

    :cond_a2f
    :goto_a2f
    move-object/from16 v6, v50

    .line 1973
    const-string v0, "t9TkDW07OC9AUSExIg=="

    invoke-static {v0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v6, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 1974
    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {v6, v0}, Landroid/widget/TextView;->setTextColor(I)V

    goto :goto_a48

    :cond_a46
    move-object/from16 v6, v50

    :goto_a48
    if-eqz v3, :cond_a55

    .line 1982
    new-instance v0, Ld$2;

    move-object/from16 v11, p1

    invoke-direct {v0, v11}, Ld$2;-><init>(Landroid/app/Dialog;)V

    invoke-virtual {v3, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    goto :goto_a57

    :cond_a55
    move-object/from16 v11, p1

    :goto_a57
    if-eqz v9, :cond_a85

    .line 1991
    sget-object v0, Ld;->c:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_a80

    sget-object v0, Ld;->b:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_a6a

    goto :goto_a80

    :cond_a6a
    const/4 v12, 0x0

    .line 1994
    invoke-virtual {v9, v12}, Landroid/widget/Button;->setVisibility(I)V

    .line 1995
    const-string v0, "FjsoWVE7ISMNficxIw=="

    invoke-static {v0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v9, v0}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 1996
    new-instance v0, Ld$3;

    invoke-direct {v0, v11}, Ld$3;-><init>(Landroid/app/Dialog;)V

    invoke-virtual {v9, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    goto :goto_a85

    :cond_a80
    :goto_a80
    const/16 v0, 0x8

    .line 1992
    invoke-virtual {v9, v0}, Landroid/widget/Button;->setVisibility(I)V

    :cond_a85
    :goto_a85
    if-eqz v10, :cond_a9e

    .line 2006
    new-instance v0, Ld$4;

    move-object v2, v1

    move-object v3, v5

    move-object v4, v6

    move-object v5, v9

    move-object v6, v13

    move-object/from16 v9, v52

    move-object/from16 v12, v53

    move-object/from16 v1, p0

    move-object v13, v8

    move-object v8, v7

    move-object v7, v14

    invoke-direct/range {v0 .. v7}, Ld$4;-><init>(Landroid/app/Activity;Landroid/widget/TextView;Landroid/view/View;Landroid/widget/TextView;Landroid/widget/Button;Landroid/widget/TextView;Landroid/widget/TextView;)V

    invoke-virtual {v10, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    goto :goto_aa4

    :cond_a9e
    move-object v13, v8

    move-object/from16 v9, v52

    move-object/from16 v12, v53

    move-object v8, v7

    :goto_aa4
    if-eqz v8, :cond_ab0

    if-eqz v13, :cond_ab0

    .line 2065
    new-instance v0, Ld$5;

    invoke-direct {v0, v13, v12, v9}, Ld$5;-><init>(Landroid/view/View;Landroid/widget/TextView;Landroid/widget/TextView;)V

    invoke-virtual {v8, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    :cond_ab0
    const/4 v7, 0x1

    .line 2088
    new-array v1, v7, [Z

    const/16 v92, 0x0

    aput-boolean v7, v1, v92

    .line 2089
    new-array v2, v7, [Z

    .line 2091
    const-string v0, "NjsoWVk2IBlBUTs/"

    invoke-static {v0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    sget-object v3, Ld;->j:Ljava/lang/String;

    invoke-static {}, Le;->n()Ljava/lang/String;

    move-result-object v4

    move-object/from16 v9, p8

    invoke-interface {v9, v3, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v9, v0, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v52

    .line 2092
    const-string v0, "ICcjX2cwOSdEVA=="

    invoke-static {v0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v3, ""

    invoke-interface {v9, v0, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v53

    .line 2093
    const-string v0, "ICcjX2cgPSI="

    invoke-static {v0}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v3, "ICYtSEE="

    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v4, ""

    invoke-interface {v9, v3, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v9, v0, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v54

    .line 2095
    new-instance v0, Ld$6;

    move-object/from16 v5, p0

    move-object/from16 v3, p5

    move-object/from16 v4, p6

    move-object/from16 v7, p7

    move-object/from16 v6, v17

    move-object/from16 v8, v18

    move-object/from16 v15, v19

    move-object/from16 v17, v21

    move-object/from16 v10, v23

    move-object/from16 v11, v24

    move-object/from16 v12, v25

    move-object/from16 v13, v26

    move-object/from16 v14, v27

    move-object/from16 v18, v28

    move-object/from16 v19, v29

    move-object/from16 v23, v32

    move-object/from16 v24, v33

    move-object/from16 v25, v34

    move-object/from16 v32, v36

    move-object/from16 v33, v37

    move-object/from16 v34, v38

    move-object/from16 v26, v40

    move-object/from16 v27, v41

    move-object/from16 v28, v42

    move-object/from16 v29, v43

    move-object/from16 v36, v45

    move-object/from16 v37, v46

    move-object/from16 v38, v47

    move-object/from16 v40, v49

    move-object/from16 v47, v79

    move-object/from16 v49, v82

    move-object/from16 v50, v83

    move-object/from16 v41, v84

    move-object/from16 v43, v85

    move-object/from16 v42, v86

    move-object/from16 v45, v88

    move-object/from16 v46, v89

    move-object/from16 v51, v90

    move-object/from16 v21, v9

    move-object/from16 v9, v22

    move-object/from16 v22, v31

    move-object/from16 v31, v35

    move-object/from16 v35, v39

    move-object/from16 v39, v48

    move-object/from16 v48, v81

    invoke-direct/range {v0 .. v51}, Ld$6;-><init>([Z[ZLandroid/view/View;Landroid/view/View;Landroid/app/Activity;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/view/View;Landroid/view/View;Landroid/view/View;Landroid/view/View;Landroid/view/View;Landroid/widget/TextView;Landroid/view/View;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/view/View;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/content/SharedPreferences;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/widget/ImageView;Landroid/view/View;Landroid/view/View;Landroid/view/View;Landroid/view/View;Landroid/view/View;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/view/View;Landroid/view/View;Landroid/widget/TextView;Landroid/widget/TextView;Landroid/widget/Button;)V

    move-object v6, v0

    move-object v5, v2

    move-object/from16 v0, v47

    move-object/from16 v14, v51

    move-object v2, v1

    move-object/from16 v1, v48

    if-eqz v3, :cond_b63

    .line 2364
    new-instance v7, Ld$7;

    invoke-direct {v7, v2, v8, v6}, Ld$7;-><init>([ZLandroid/view/View;Ljava/lang/Runnable;)V

    invoke-virtual {v3, v7}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    :cond_b63
    if-eqz v4, :cond_b6d

    .line 2373
    new-instance v3, Ld$8;

    invoke-direct {v3, v2, v8, v6}, Ld$8;-><init>([ZLandroid/view/View;Ljava/lang/Runnable;)V

    invoke-virtual {v4, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    :cond_b6d
    if-eqz v0, :cond_b77

    .line 2383
    new-instance v3, Ld$9;

    invoke-direct {v3, v5, v6}, Ld$9;-><init>([ZLjava/lang/Runnable;)V

    invoke-virtual {v0, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    :cond_b77
    if-eqz v1, :cond_b81

    .line 2392
    new-instance v0, Ld$10;

    invoke-direct {v0, v5, v6}, Ld$10;-><init>([ZLjava/lang/Runnable;)V

    invoke-virtual {v1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 2401
    :cond_b81
    invoke-interface {v6}, Ljava/lang/Runnable;->run()V

    if-eqz v14, :cond_b9a

    .line 2404
    new-instance v0, Ld$12;

    move-object/from16 v6, p0

    move-object/from16 v7, p1

    move-object v1, v2

    move-object v2, v5

    move-object/from16 v5, v52

    move-object/from16 v3, v53

    move-object/from16 v4, v54

    invoke-direct/range {v0 .. v7}, Ld$12;-><init>([Z[ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/app/Activity;Landroid/app/Dialog;)V

    invoke-virtual {v14, v0}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    :try_end_b9a
    .catch Ljava/lang/Exception; {:try_start_7e7 .. :try_end_b9a} :catch_b9b

    :cond_b9a
    return-void

    :catch_b9b
    move-exception v0

    .line 2433
    const-string v1, "Ezs+fVQ0OgtMVjQzI18="

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Nz0oSWA4OBBEXSInZkhKJzs0Fxg="

    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/Exception;->getMessage()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    return-void
.end method

.method public static b(Landroid/content/Context;)V
    .registers 6

    if-nez p0, :cond_3

    goto :goto_6b

    .line 175
    :cond_3
    invoke-static {p0}, Ld;->a(Landroid/content/Context;)V

    .line 176
    sget-object v0, Ld;->d:Ljava/lang/String;

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    .line 177
    new-instance v0, Ljava/text/SimpleDateFormat;

    const-string v1, "LC0/VBUYGWtJXA=="

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    sget-object v2, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-direct {v0, v1, v2}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    new-instance v1, Ljava/util/Date;

    invoke-direct {v1}, Ljava/util/Date;-><init>()V

    invoke-virtual {v0, v1}, Ljava/text/SimpleDateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v0

    .line 178
    sget-object v1, Ld;->h:Ljava/lang/String;

    const-string v2, ""

    invoke-interface {p0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 180
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_6b

    .line 181
    sget-object v2, Ld;->e:Ljava/lang/String;

    sget-object v3, Ld;->a:Ljava/lang/String;

    invoke-interface {p0, v2, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    sget-object v4, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-virtual {v2, v4}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v2

    .line 182
    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    .line 183
    invoke-interface {p0, v1, v0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 185
    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5b

    .line 186
    sget-object v0, Ld;->f:Ljava/lang/String;

    const/16 v1, 0x32

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    .line 187
    sget-object v0, Ld;->g:Ljava/lang/String;

    const/16 v1, 0xa

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    goto :goto_68

    .line 189
    :cond_5b
    sget-object v0, Ld;->f:Ljava/lang/String;

    const v1, 0xf423f

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    .line 190
    sget-object v0, Ld;->g:Ljava/lang/String;

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    .line 192
    :goto_68
    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_6b
    :goto_6b
    return-void
.end method

.method public static c(Landroid/content/Context;II)Landroid/graphics/drawable/Drawable;
    .registers 14

    const/4 v0, 0x0

    if-nez p0, :cond_4

    return-object v0

    .line 1193
    :cond_4
    invoke-static {p0, p1}, Ld;->a(Landroid/content/Context;I)I

    move-result p1

    if-gtz p1, :cond_c

    const/16 p1, 0x20

    .line 1196
    :cond_c
    :try_start_c
    sget-object v1, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {p1, p1, v1}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v1

    .line 1197
    new-instance v2, Landroid/graphics/Canvas;

    invoke-direct {v2, v1}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    int-to-float p1, p1

    .line 1202
    new-instance v8, Landroid/graphics/Paint;

    const/4 v9, 0x1

    invoke-direct {v8, v9}, Landroid/graphics/Paint;-><init>(I)V

    .line 1203
    sget-object v3, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v8, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1204
    invoke-virtual {v8, p2}, Landroid/graphics/Paint;->setColor(I)V

    .line 1206
    new-instance v7, Landroid/graphics/Paint;

    invoke-direct {v7, v9}, Landroid/graphics/Paint;-><init>(I)V

    .line 1207
    sget-object v3, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v7, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1208
    invoke-virtual {v7, p2}, Landroid/graphics/Paint;->setColor(I)V

    const p2, 0x3df5c28f  # 0.12f

    mul-float p2, p2, p1

    const v3, 0x3fe66666  # 1.8f

    .line 1209
    invoke-static {v3, p2}, Ljava/lang/Math;->max(FF)F

    move-result p2

    invoke-virtual {v7, p2}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 1210
    sget-object p2, Landroid/graphics/Paint$Cap;->ROUND:Landroid/graphics/Paint$Cap;

    invoke-virtual {v7, p2}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    .line 1212
    new-instance v3, Landroid/graphics/RectF;

    const p2, 0x3e8f5c29  # 0.28f

    mul-float p2, p2, p1

    const v4, 0x3e23d70a  # 0.16f

    mul-float v4, v4, p1

    const v5, 0x3f3851ec  # 0.72f

    mul-float v10, p1, v5

    const v5, 0x3f0f5c29  # 0.56f

    mul-float v5, v5, p1

    invoke-direct {v3, p2, v4, v10, v5}, Landroid/graphics/RectF;-><init>(FFFF)V

    const/high16 v5, 0x43340000  # 180.0f

    const/4 v6, 0x0

    const/high16 v4, 0x43340000  # 180.0f

    .line 1213
    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawArc(Landroid/graphics/RectF;FFZLandroid/graphics/Paint;)V

    .line 1215
    new-instance p2, Landroid/graphics/RectF;

    const v3, 0x3e4ccccd  # 0.2f

    mul-float v3, v3, p1

    const v4, 0x3ee147ae  # 0.44f

    mul-float v4, v4, p1

    const v5, 0x3f4ccccd  # 0.8f

    mul-float v5, v5, p1

    const v6, 0x3f570a3d  # 0.84f

    mul-float v6, v6, p1

    invoke-direct {p2, v3, v4, v5, v6}, Landroid/graphics/RectF;-><init>(FFFF)V

    const/high16 v3, 0x40200000  # 2.5f

    .line 1216
    invoke-static {p0, v3}, Ld;->a(Landroid/content/Context;F)I

    move-result v4

    int-to-float v4, v4

    invoke-static {p0, v3}, Ld;->a(Landroid/content/Context;F)I

    move-result v3

    int-to-float v3, v3

    invoke-virtual {v2, p2, v4, v3, v8}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 1218
    new-instance p2, Landroid/graphics/Paint;

    invoke-direct {p2, v9}, Landroid/graphics/Paint;-><init>(I)V

    .line 1219
    sget-object v3, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {p2, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/4 v3, -0x1

    .line 1220
    invoke-virtual {p2, v3}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v4, 0x3f000000  # 0.5f

    mul-float v4, v4, p1

    const v5, 0x3f19999a  # 0.6f

    mul-float v5, v5, p1

    const v6, 0x3d75c28f  # 0.06f

    mul-float v6, v6, p1

    .line 1221
    invoke-virtual {v2, v4, v5, v6, p2}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1223
    new-instance v7, Landroid/graphics/Paint;

    invoke-direct {v7, v9}, Landroid/graphics/Paint;-><init>(I)V

    .line 1224
    sget-object p2, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v7, p2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1225
    invoke-virtual {v7, v3}, Landroid/graphics/Paint;->setColor(I)V

    const p2, 0x3d4ccccd  # 0.05f

    mul-float p1, p1, p2

    const/high16 p2, 0x3fc00000  # 1.5f

    .line 1226
    invoke-static {p2, p1}, Ljava/lang/Math;->max(FF)F

    move-result p1

    invoke-virtual {v7, p1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 1227
    sget-object p1, Landroid/graphics/Paint$Cap;->ROUND:Landroid/graphics/Paint$Cap;

    invoke-virtual {v7, p1}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    move p1, v5

    move v5, v4

    move v3, v4

    move v6, v10

    move v4, p1

    .line 1228
    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 1230
    new-instance p1, Landroid/graphics/drawable/BitmapDrawable;

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-direct {p1, p0, v1}, Landroid/graphics/drawable/BitmapDrawable;-><init>(Landroid/content/res/Resources;Landroid/graphics/Bitmap;)V
    :try_end_e0
    .catchall {:try_start_c .. :try_end_e0} :catchall_e1

    return-object p1

    :catchall_e1
    return-object v0
.end method

.method public static c(Landroid/content/Context;III)Landroid/graphics/drawable/Drawable;
    .registers 10

    const/4 v0, 0x0

    if-nez p0, :cond_4

    return-object v0

    .line 1309
    :cond_4
    invoke-static {p0, p1}, Ld;->a(Landroid/content/Context;I)I

    move-result p1

    if-gtz p1, :cond_c

    const/16 p1, 0x20

    .line 1312
    :cond_c
    :try_start_c
    sget-object v1, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {p1, p1, v1}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v1

    .line 1313
    new-instance v2, Landroid/graphics/Canvas;

    invoke-direct {v2, v1}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    int-to-float p1, p1

    .line 1318
    new-instance v3, Landroid/graphics/Paint;

    const/4 v4, 0x1

    invoke-direct {v3, v4}, Landroid/graphics/Paint;-><init>(I)V

    .line 1319
    sget-object v5, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v3, v5}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1320
    invoke-virtual {v3, p2}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 p2, 0x40000000  # 2.0f

    div-float p2, p1, p2

    const v5, 0x3eeb851f  # 0.46f

    mul-float v5, v5, p1

    .line 1321
    invoke-virtual {v2, p2, p2, v5, v3}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1323
    new-instance p2, Landroid/graphics/Paint;

    invoke-direct {p2, v4}, Landroid/graphics/Paint;-><init>(I)V

    .line 1324
    sget-object v3, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {p2, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1325
    invoke-virtual {p2, p3}, Landroid/graphics/Paint;->setColor(I)V

    const p3, 0x3de147ae  # 0.11f

    mul-float p3, p3, p1

    const v3, 0x3fe66666  # 1.8f

    .line 1326
    invoke-static {v3, p3}, Ljava/lang/Math;->max(FF)F

    move-result p3

    invoke-virtual {p2, p3}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 1327
    sget-object p3, Landroid/graphics/Paint$Cap;->ROUND:Landroid/graphics/Paint$Cap;

    invoke-virtual {p2, p3}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    .line 1328
    sget-object p3, Landroid/graphics/Paint$Join;->ROUND:Landroid/graphics/Paint$Join;

    invoke-virtual {p2, p3}, Landroid/graphics/Paint;->setStrokeJoin(Landroid/graphics/Paint$Join;)V

    .line 1330
    new-instance p3, Landroid/graphics/Path;

    invoke-direct {p3}, Landroid/graphics/Path;-><init>()V

    const v3, 0x3e99999a  # 0.3f

    mul-float v3, v3, p1

    const v4, 0x3f028f5c  # 0.51f

    mul-float v4, v4, p1

    .line 1331
    invoke-virtual {p3, v3, v4}, Landroid/graphics/Path;->moveTo(FF)V

    const v3, 0x3ee66666  # 0.45f

    mul-float v3, v3, p1

    const v4, 0x3f28f5c3  # 0.66f

    mul-float v4, v4, p1

    .line 1332
    invoke-virtual {p3, v3, v4}, Landroid/graphics/Path;->lineTo(FF)V

    const v3, 0x3f333333  # 0.7f

    mul-float v3, v3, p1

    const v4, 0x3eb851ec  # 0.36f

    mul-float p1, p1, v4

    .line 1333
    invoke-virtual {p3, v3, p1}, Landroid/graphics/Path;->lineTo(FF)V

    .line 1334
    invoke-virtual {v2, p3, p2}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 1336
    new-instance p1, Landroid/graphics/drawable/BitmapDrawable;

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-direct {p1, p0, v1}, Landroid/graphics/drawable/BitmapDrawable;-><init>(Landroid/content/res/Resources;Landroid/graphics/Bitmap;)V
    :try_end_90
    .catchall {:try_start_c .. :try_end_90} :catchall_91

    return-object p1

    :catchall_91
    return-object v0
.end method

.method public static c()Ljava/lang/String;
    .registers 1

    .line 89
    invoke-static {}, Le;->j()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static c(Landroid/content/Context;)Ljava/lang/String;
    .registers 1

    invoke-static {}, Le;->L()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static c(Landroid/app/Activity;)V
    .registers 1

    return-void
.end method

.method public static getLocalPrediction(I)Ljava/lang/String;
    .registers 15

    :try_start_0
    const-string v0, "Asia/Kolkata"

    invoke-static {v0}, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;

    move-result-object v0

    invoke-static {v0}, Ljava/util/Calendar;->getInstance(Ljava/util/TimeZone;)Ljava/util/Calendar;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/Calendar;->getTimeInMillis()J

    move-result-wide v2

    new-instance v4, Ljava/text/SimpleDateFormat;

    const-string v5, "yyyyMMdd"

    sget-object v6, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-direct {v4, v5, v6}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    invoke-virtual {v4, v0}, Ljava/text/SimpleDateFormat;->setTimeZone(Ljava/util/TimeZone;)V

    invoke-virtual {v1}, Ljava/util/Calendar;->getTime()Ljava/util/Date;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/text/SimpleDateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v0

    const/16 v4, 0xb

    invoke-virtual {v1, v4}, Ljava/util/Calendar;->get(I)I

    move-result v4

    const/16 v5, 0xc

    invoke-virtual {v1, v5}, Ljava/util/Calendar;->get(I)I

    move-result v5

    const/16 v6, 0xd

    invoke-virtual {v1, v6}, Ljava/util/Calendar;->get(I)I

    move-result v1

    mul-int/lit16 v4, v4, 0xe10

    mul-int/lit8 v5, v5, 0x3c

    add-int/2addr v4, v5

    add-int/2addr v4, v1

    if-nez p0, :cond_41

    div-int/lit8 v4, v4, 0x1e

    goto :goto_43

    :cond_41
    div-int/lit8 v4, v4, 0x3c

    :goto_43
    add-int/lit8 v4, v4, 0x1

    sget-object v1, Ljava/util/Locale;->US:Ljava/util/Locale;

    const-string v5, "%04d"

    const/4 v6, 0x1

    new-array v7, v6, [Ljava/lang/Object;

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    const/4 v9, 0x0

    aput-object v8, v7, v9

    invoke-static {v1, v5, v7}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {v5, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-wide/16 v7, 0x2710

    div-long/2addr v2, v7

    long-to-int v1, v2

    xor-int/2addr v1, v4

    if-gez v1, :cond_71

    neg-int v1, v1

    :cond_71
    rem-int/lit8 v2, v1, 0xa

    const/4 v3, 0x5

    if-lt v2, v3, :cond_7a

    const-string v4, "BIG"

    goto :goto_7c

    :cond_7a
    const-string v4, "SMALL"

    :goto_7c
    rem-int/lit8 v5, v1, 0x12

    add-int/lit8 v5, v5, 0x4e

    const/16 v7, 0x56

    if-lt v5, v7, :cond_87

    const-string v7, "OPTIMAL PATTERN"

    goto :goto_89

    :cond_87
    const-string v7, "BALANCED CONSENSUS"

    :goto_89
    if-nez v2, :cond_8e

    const-string v1, "RED/VIOLET"

    goto :goto_9d

    :cond_8e
    if-ne v2, v3, :cond_93

    const-string v1, "GREEN/VIOLET"

    goto :goto_9d

    :cond_93
    rem-int/lit8 v1, v2, 0x2

    if-nez v1, :cond_9a

    const-string v1, "RED"

    goto :goto_9d

    :cond_9a
    const-string v1, "GREEN"

    :goto_9d
    new-instance v3, Lorg/json/JSONObject;

    invoke-direct {v3}, Lorg/json/JSONObject;-><init>()V

    const-string v8, "status"

    const-string v9, "SUCCESS"

    invoke-virtual {v3, v8, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v8, "prediction"

    invoke-virtual {v3, v8, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v4, "number"

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v4, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v2, "period"

    invoke-virtual {v3, v2, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v0, "probability"

    invoke-virtual {v3, v0, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const-string v0, "bet_suggestion"

    invoke-virtual {v3, v0, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v0, "color"

    invoke-virtual {v3, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v0, "signal_tier"

    const-string v1, "PRO VIP CONSENSUS"

    invoke-virtual {v3, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-virtual {v3}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0
    :try_end_d6
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_d6} :catch_d7

    return-object v0

    :catch_d7
    const-string v0, "{\"status\":\"SUCCESS\",\"prediction\":\"BIG\",\"number\":\"7\",\"period\":\"202611180123\",\"probability\":88,\"bet_suggestion\":\"OPTIMAL PATTERN\",\"color\":\"GREEN\",\"signal_tier\":\"PRO VIP CONSENSUS\"}"

    return-object v0
.end method


.method public static d()Landroid/graphics/drawable/Drawable;
    .registers 8

    .line 959
    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    .line 960
    sget-object v1, Landroid/graphics/drawable/GradientDrawable$Orientation;->TOP_BOTTOM:Landroid/graphics/drawable/GradientDrawable$Orientation;

    const/16 v2, 0xf5

    const/16 v3, 0xff

    .line 962
    invoke-static {v2, v3, v3, v3}, Landroid/graphics/Color;->argb(IIII)I

    move-result v2

    const/16 v4, 0xbe

    .line 963
    invoke-static {v4, v3, v3, v3}, Landroid/graphics/Color;->argb(IIII)I

    move-result v4

    const/16 v5, 0x78

    .line 964
    invoke-static {v5, v3, v3, v3}, Landroid/graphics/Color;->argb(IIII)I

    move-result v5

    const/16 v6, 0x28

    .line 965
    invoke-static {v6, v3, v3, v3}, Landroid/graphics/Color;->argb(IIII)I

    move-result v6

    const/4 v7, 0x0

    .line 966
    invoke-static {v7, v3, v3, v3}, Landroid/graphics/Color;->argb(IIII)I

    move-result v3

    filled-new-array {v2, v4, v5, v6, v3}, [I

    move-result-object v2

    .line 959
    invoke-direct {v0, v1, v2}, Landroid/graphics/drawable/GradientDrawable;-><init>(Landroid/graphics/drawable/GradientDrawable$Orientation;[I)V

    return-object v0
.end method

.method public static d(Landroid/content/Context;II)Landroid/graphics/drawable/Drawable;
    .registers 12

    const/4 v0, 0x0

    if-nez p0, :cond_4

    return-object v0

    .line 1238
    :cond_4
    invoke-static {p0, p1}, Ld;->a(Landroid/content/Context;I)I

    move-result p1

    if-gtz p1, :cond_c

    const/16 p1, 0x20

    .line 1241
    :cond_c
    :try_start_c
    sget-object v1, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {p1, p1, v1}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v1

    .line 1242
    new-instance v2, Landroid/graphics/Canvas;

    invoke-direct {v2, v1}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    int-to-float p1, p1

    .line 1247
    new-instance v3, Landroid/graphics/Paint;

    const/4 v4, 0x1

    invoke-direct {v3, v4}, Landroid/graphics/Paint;-><init>(I)V

    .line 1248
    sget-object v5, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v3, v5}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1249
    invoke-virtual {v3, p2}, Landroid/graphics/Paint;->setColor(I)V

    .line 1251
    new-instance p2, Landroid/graphics/RectF;

    const v5, 0x3e0f5c29  # 0.14f

    mul-float v5, v5, p1

    const v6, 0x3e3851ec  # 0.18f

    mul-float v6, v6, p1

    const v7, 0x3f5c28f6  # 0.86f

    mul-float v7, v7, p1

    const v8, 0x3f2e147b  # 0.68f

    mul-float v8, v8, p1

    invoke-direct {p2, v5, v6, v7, v8}, Landroid/graphics/RectF;-><init>(FFFF)V

    const/4 v5, 0x3

    .line 1252
    invoke-static {p0, v5}, Ld;->a(Landroid/content/Context;I)I

    move-result v8

    int-to-float v8, v8

    invoke-static {p0, v5}, Ld;->a(Landroid/content/Context;I)I

    move-result v5

    int-to-float v5, v5

    invoke-virtual {v2, p2, v8, v5, v3}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 1254
    new-instance p2, Landroid/graphics/Path;

    invoke-direct {p2}, Landroid/graphics/Path;-><init>()V

    const v5, 0x3e8f5c29  # 0.28f

    mul-float v5, v5, p1

    const v8, 0x3f28f5c3  # 0.66f

    mul-float v8, v8, p1

    .line 1255
    invoke-virtual {p2, v5, v8}, Landroid/graphics/Path;->moveTo(FF)V

    .line 1256
    invoke-virtual {p2, v6, v7}, Landroid/graphics/Path;->lineTo(FF)V

    const v5, 0x3ee147ae  # 0.44f

    mul-float v5, v5, p1

    .line 1257
    invoke-virtual {p2, v5, v8}, Landroid/graphics/Path;->lineTo(FF)V

    .line 1258
    invoke-virtual {p2}, Landroid/graphics/Path;->close()V

    .line 1259
    invoke-virtual {v2, p2, v3}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 1261
    new-instance p2, Landroid/graphics/Paint;

    invoke-direct {p2, v4}, Landroid/graphics/Paint;-><init>(I)V

    .line 1262
    sget-object v3, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {p2, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/4 v3, -0x1

    .line 1263
    invoke-virtual {p2, v3}, Landroid/graphics/Paint;->setColor(I)V

    const v3, 0x3d3851ec  # 0.045f

    mul-float v3, v3, p1

    const v4, 0x3eb851ec  # 0.36f

    mul-float v4, v4, p1

    const v5, 0x3edc28f6  # 0.43f

    mul-float v5, v5, p1

    .line 1265
    invoke-virtual {v2, v4, v5, v3, p2}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    const/high16 v4, 0x3f000000  # 0.5f

    mul-float v4, v4, p1

    .line 1266
    invoke-virtual {v2, v4, v5, v3, p2}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    const v4, 0x3f23d70a  # 0.64f

    mul-float p1, p1, v4

    .line 1267
    invoke-virtual {v2, p1, v5, v3, p2}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1269
    new-instance p1, Landroid/graphics/drawable/BitmapDrawable;

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-direct {p1, p0, v1}, Landroid/graphics/drawable/BitmapDrawable;-><init>(Landroid/content/res/Resources;Landroid/graphics/Bitmap;)V
    :try_end_a8
    .catchall {:try_start_c .. :try_end_a8} :catchall_a9

    return-object p1

    :catchall_a9
    return-object v0
.end method

.method public static d(Landroid/content/Context;III)Landroid/graphics/drawable/Drawable;
    .registers 14

    const/4 v0, 0x0

    if-nez p0, :cond_4

    return-object v0

    .line 1344
    :cond_4
    invoke-static {p0, p1}, Ld;->a(Landroid/content/Context;I)I

    move-result p1

    if-gtz p1, :cond_c

    const/16 p1, 0x20

    .line 1347
    :cond_c
    :try_start_c
    sget-object v1, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {p1, p1, v1}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v1

    .line 1348
    new-instance v2, Landroid/graphics/Canvas;

    invoke-direct {v2, v1}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    int-to-float p1, p1

    .line 1353
    new-instance v3, Landroid/graphics/Paint;

    const/4 v8, 0x1

    invoke-direct {v3, v8}, Landroid/graphics/Paint;-><init>(I)V

    .line 1354
    sget-object v4, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1355
    invoke-virtual {v3, p2}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 p2, 0x40000000  # 2.0f

    div-float p2, p1, p2

    const v4, 0x3eeb851f  # 0.46f

    mul-float v4, v4, p1

    .line 1356
    invoke-virtual {v2, p2, p2, v4, v3}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1358
    new-instance v7, Landroid/graphics/Paint;

    invoke-direct {v7, v8}, Landroid/graphics/Paint;-><init>(I)V

    .line 1359
    sget-object p2, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v7, p2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1360
    invoke-virtual {v7, p3}, Landroid/graphics/Paint;->setColor(I)V

    const p2, 0x3dcccccd  # 0.1f

    mul-float p2, p2, p1

    const/high16 v9, 0x3fc00000  # 1.5f

    .line 1361
    invoke-static {v9, p2}, Ljava/lang/Math;->max(FF)F

    move-result p2

    invoke-virtual {v7, p2}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 1362
    sget-object p2, Landroid/graphics/Paint$Cap;->ROUND:Landroid/graphics/Paint$Cap;

    invoke-virtual {v7, p2}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    .line 1364
    new-instance v3, Landroid/graphics/RectF;

    const p2, 0x3eb33333  # 0.35f

    mul-float p2, p2, p1

    const v4, 0x3e75c28f  # 0.24f

    mul-float v4, v4, p1

    const v5, 0x3f266666  # 0.65f

    mul-float v5, v5, p1

    const v6, 0x3f0a3d71  # 0.54f

    mul-float v6, v6, p1

    invoke-direct {v3, p2, v4, v5, v6}, Landroid/graphics/RectF;-><init>(FFFF)V

    const/high16 v5, 0x43340000  # 180.0f

    const/4 v6, 0x0

    const/high16 v4, 0x43340000  # 180.0f

    .line 1365
    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawArc(Landroid/graphics/RectF;FFZLandroid/graphics/Paint;)V

    .line 1367
    new-instance p2, Landroid/graphics/Paint;

    invoke-direct {p2, v8}, Landroid/graphics/Paint;-><init>(I)V

    .line 1368
    sget-object v3, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {p2, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1369
    invoke-virtual {p2, p3}, Landroid/graphics/Paint;->setColor(I)V

    .line 1370
    new-instance p3, Landroid/graphics/RectF;

    const v3, 0x3e8f5c29  # 0.28f

    mul-float v3, v3, p1

    const v4, 0x3ee66666  # 0.45f

    mul-float v4, v4, p1

    const v5, 0x3f3851ec  # 0.72f

    mul-float v5, v5, p1

    const/high16 v6, 0x3f400000  # 0.75f

    mul-float p1, p1, v6

    invoke-direct {p3, v3, v4, v5, p1}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 1371
    invoke-static {p0, v9}, Ld;->a(Landroid/content/Context;F)I

    move-result p1

    int-to-float p1, p1

    invoke-static {p0, v9}, Ld;->a(Landroid/content/Context;F)I

    move-result v3

    int-to-float v3, v3

    invoke-virtual {v2, p3, p1, v3, p2}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 1373
    new-instance p1, Landroid/graphics/drawable/BitmapDrawable;

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-direct {p1, p0, v1}, Landroid/graphics/drawable/BitmapDrawable;-><init>(Landroid/content/res/Resources;Landroid/graphics/Bitmap;)V
    :try_end_ae
    .catchall {:try_start_c .. :try_end_ae} :catchall_af

    return-object p1

    :catchall_af
    return-object v0
.end method

.method public static d(Landroid/app/Activity;)V
    .registers 1

    return-void
.end method

.method public static d(Landroid/content/Context;)Z
    .registers 1

    if-eqz p0, :cond_4

    const/4 p0, 0x1

    return p0

    :cond_4
    const/4 p0, 0x0

    return p0
.end method

.method public static e()Landroid/graphics/drawable/Drawable;
    .registers 8

    .line 972
    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    .line 973
    sget-object v1, Landroid/graphics/drawable/GradientDrawable$Orientation;->BOTTOM_TOP:Landroid/graphics/drawable/GradientDrawable$Orientation;

    const/16 v2, 0xff

    .line 975
    invoke-static {v2, v2, v2, v2}, Landroid/graphics/Color;->argb(IIII)I

    move-result v3

    const/16 v4, 0xdc

    .line 976
    invoke-static {v4, v2, v2, v2}, Landroid/graphics/Color;->argb(IIII)I

    move-result v4

    const/16 v5, 0x96

    .line 977
    invoke-static {v5, v2, v2, v2}, Landroid/graphics/Color;->argb(IIII)I

    move-result v5

    const/16 v6, 0x3c

    .line 978
    invoke-static {v6, v2, v2, v2}, Landroid/graphics/Color;->argb(IIII)I

    move-result v6

    const/4 v7, 0x0

    .line 979
    invoke-static {v7, v2, v2, v2}, Landroid/graphics/Color;->argb(IIII)I

    move-result v2

    filled-new-array {v3, v4, v5, v6, v2}, [I

    move-result-object v2

    .line 972
    invoke-direct {v0, v1, v2}, Landroid/graphics/drawable/GradientDrawable;-><init>(Landroid/graphics/drawable/GradientDrawable$Orientation;[I)V

    return-object v0
.end method

.method public static e(Landroid/content/Context;II)Landroid/graphics/drawable/Drawable;
    .registers 13

    const/4 v0, 0x0

    if-nez p0, :cond_4

    return-object v0

    .line 1454
    :cond_4
    invoke-static {p0, p1}, Ld;->a(Landroid/content/Context;I)I

    move-result p1

    if-gtz p1, :cond_c

    const/16 p1, 0x20

    .line 1457
    :cond_c
    :try_start_c
    sget-object v1, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {p1, p1, v1}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v1

    .line 1458
    new-instance v2, Landroid/graphics/Canvas;

    invoke-direct {v2, v1}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    int-to-float p1, p1

    .line 1463
    new-instance v7, Landroid/graphics/Paint;

    const/4 v3, 0x1

    invoke-direct {v7, v3}, Landroid/graphics/Paint;-><init>(I)V

    .line 1464
    sget-object v3, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v7, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1465
    invoke-virtual {v7, p2}, Landroid/graphics/Paint;->setColor(I)V

    const p2, 0x3de147ae  # 0.11f

    mul-float p2, p2, p1

    const v3, 0x3fe66666  # 1.8f

    .line 1466
    invoke-static {v3, p2}, Ljava/lang/Math;->max(FF)F

    move-result p2

    invoke-virtual {v7, p2}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 1467
    sget-object p2, Landroid/graphics/Paint$Cap;->ROUND:Landroid/graphics/Paint$Cap;

    invoke-virtual {v7, p2}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    .line 1469
    new-instance v3, Landroid/graphics/RectF;

    const p2, 0x3dcccccd  # 0.1f

    mul-float p2, p2, p1

    const v4, 0x3e8f5c29  # 0.28f

    mul-float v4, v4, p1

    const v5, 0x3f051eb8  # 0.52f

    mul-float v5, v5, p1

    const v6, 0x3f3851ec  # 0.72f

    mul-float v6, v6, p1

    invoke-direct {v3, p2, v4, v5, v6}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 1470
    new-instance p2, Landroid/graphics/RectF;

    const v5, 0x3ef5c28f  # 0.48f

    mul-float v5, v5, p1

    const v8, 0x3f666666  # 0.9f

    mul-float v8, v8, p1

    invoke-direct {p2, v5, v4, v8, v6}, Landroid/graphics/RectF;-><init>(FFFF)V

    const/high16 v5, 0x43960000  # 300.0f

    const/4 v6, 0x0

    const/high16 v4, 0x41f00000  # 30.0f

    .line 1471
    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawArc(Landroid/graphics/RectF;FFZLandroid/graphics/Paint;)V

    const/high16 v5, 0x43960000  # 300.0f

    const/4 v6, 0x0

    const/high16 v4, 0x43520000  # 210.0f

    move-object v3, p2

    .line 1472
    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawArc(Landroid/graphics/RectF;FFZLandroid/graphics/Paint;)V

    const p2, 0x3eb33333  # 0.35f

    mul-float v3, p1, p2

    const p2, 0x3ec28f5c  # 0.38f

    mul-float v4, p1, p2

    const p2, 0x3f266666  # 0.65f

    mul-float v5, p1, p2

    const p2, 0x3f1eb852  # 0.62f

    mul-float v6, p1, p2

    .line 1473
    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    move v9, v6

    move v6, v4

    move v4, v9

    .line 1474
    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 1476
    new-instance p1, Landroid/graphics/drawable/BitmapDrawable;

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-direct {p1, p0, v1}, Landroid/graphics/drawable/BitmapDrawable;-><init>(Landroid/content/res/Resources;Landroid/graphics/Bitmap;)V
    :try_end_99
    .catchall {:try_start_c .. :try_end_99} :catchall_9a

    return-object p1

    :catchall_9a
    return-object v0
.end method

.method public static e(Landroid/content/Context;)Z
    .registers 1

    if-eqz p0, :cond_4

    const/4 p0, 0x1

    return p0

    :cond_4
    const/4 p0, 0x0

    return p0
.end method

.method public static f(Landroid/content/Context;II)Landroid/graphics/drawable/Drawable;
    .registers 15

    const/4 v0, 0x0

    if-nez p0, :cond_4

    return-object v0

    .line 1484
    :cond_4
    invoke-static {p0, p1}, Ld;->a(Landroid/content/Context;I)I

    move-result p1

    if-gtz p1, :cond_c

    const/16 p1, 0x20

    .line 1487
    :cond_c
    :try_start_c
    sget-object v1, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {p1, p1, v1}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v1

    .line 1488
    new-instance v2, Landroid/graphics/Canvas;

    invoke-direct {v2, v1}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    int-to-float p1, p1

    .line 1493
    new-instance v7, Landroid/graphics/Paint;

    const/4 v8, 0x1

    invoke-direct {v7, v8}, Landroid/graphics/Paint;-><init>(I)V

    .line 1494
    sget-object v3, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v7, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1495
    invoke-virtual {v7, p2}, Landroid/graphics/Paint;->setColor(I)V

    const v3, 0x3dcccccd  # 0.1f

    mul-float v3, v3, p1

    const v4, 0x3fe66666  # 1.8f

    .line 1496
    invoke-static {v4, v3}, Ljava/lang/Math;->max(FF)F

    move-result v3

    invoke-virtual {v7, v3}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 1497
    sget-object v3, Landroid/graphics/Paint$Cap;->ROUND:Landroid/graphics/Paint$Cap;

    invoke-virtual {v7, v3}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    .line 1499
    new-instance v3, Landroid/graphics/RectF;

    const v4, 0x3df5c28f  # 0.12f

    mul-float v4, v4, p1

    const v5, 0x3e23d70a  # 0.16f

    mul-float v5, v5, p1

    const v6, 0x3f6147ae  # 0.88f

    mul-float v6, v6, p1

    const v9, 0x3f3851ec  # 0.72f

    mul-float v9, v9, p1

    invoke-direct {v3, v4, v5, v6, v9}, Landroid/graphics/RectF;-><init>(FFFF)V

    const/4 v5, 0x3

    .line 1500
    invoke-static {p0, v5}, Ld;->a(Landroid/content/Context;I)I

    move-result v10

    int-to-float v10, v10

    invoke-static {p0, v5}, Ld;->a(Landroid/content/Context;I)I

    move-result v5

    int-to-float v5, v5

    invoke-virtual {v2, v3, v10, v5, v7}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    const v3, 0x3eae147b  # 0.34f

    mul-float v3, v3, p1

    move v5, v6

    move v6, v3

    move v11, v4

    move v4, v3

    move v3, v11

    .line 1502
    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    move v3, v4

    const v4, 0x3e851eb8  # 0.26f

    mul-float v5, p1, v4

    const v4, 0x3f5c28f6  # 0.86f

    mul-float v6, p1, v4

    move v4, v9

    .line 1504
    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    move v9, v3

    const v3, 0x3f28f5c3  # 0.66f

    mul-float v3, v3, p1

    const v5, 0x3f3d70a4  # 0.74f

    mul-float v5, v5, p1

    .line 1505
    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    const v3, 0x3e6147ae  # 0.22f

    mul-float v3, v3, p1

    const v4, 0x3f47ae14  # 0.78f

    mul-float v5, p1, v4

    move v4, v6

    .line 1506
    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 1508
    new-instance v3, Landroid/graphics/Paint;

    invoke-direct {v3, v8}, Landroid/graphics/Paint;-><init>(I)V

    .line 1509
    sget-object v4, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1510
    invoke-virtual {v3, p2}, Landroid/graphics/Paint;->setColor(I)V

    const p2, 0x3e75c28f  # 0.24f

    mul-float p2, p2, p1

    const/high16 v4, 0x3e800000  # 0.25f

    mul-float v4, v4, p1

    const v5, 0x3d23d70a  # 0.04f

    mul-float p1, p1, v5

    .line 1511
    invoke-virtual {v2, p2, v4, p1, v3}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1512
    invoke-virtual {v2, v9, v4, p1, v3}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1514
    new-instance p1, Landroid/graphics/drawable/BitmapDrawable;

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-direct {p1, p0, v1}, Landroid/graphics/drawable/BitmapDrawable;-><init>(Landroid/content/res/Resources;Landroid/graphics/Bitmap;)V
    :try_end_c3
    .catchall {:try_start_c .. :try_end_c3} :catchall_c4

    return-object p1

    :catchall_c4
    return-object v0
.end method

.method static synthetic f()Ljava/lang/String;
    .registers 1

    .line 59
    sget-object v0, Ld;->e:Ljava/lang/String;

    return-object v0
.end method

.method public static f(Landroid/content/Context;)Z
    .registers 1

    const/4 p0, 0x0

    return p0
.end method

.method public static g(Landroid/content/Context;)I
    .registers 1

    const p0, 0x7fffffff

    return p0
.end method

.method public static g(Landroid/content/Context;II)Landroid/graphics/drawable/Drawable;
    .registers 3

    .line 1521
    invoke-static {p0, p1, p2}, Ld;->d(Landroid/content/Context;II)Landroid/graphics/drawable/Drawable;

    move-result-object p0

    return-object p0
.end method

.method static synthetic g()Ljava/lang/String;
    .registers 1

    .line 60
    sget-object v0, Ld;->f:Ljava/lang/String;

    return-object v0
.end method

.method public static h(Landroid/content/Context;)I
    .registers 1

    const p0, 0x7fffffff

    return p0
.end method

.method public static h(Landroid/content/Context;II)Landroid/graphics/drawable/Drawable;
    .registers 14

    const/4 v0, 0x0

    if-nez p0, :cond_4

    return-object v0

    .line 1526
    :cond_4
    invoke-static {p0, p1}, Ld;->a(Landroid/content/Context;I)I

    move-result p1

    if-gtz p1, :cond_c

    const/16 p1, 0x20

    .line 1529
    :cond_c
    :try_start_c
    sget-object v1, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {p1, p1, v1}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v1

    .line 1530
    new-instance v2, Landroid/graphics/Canvas;

    invoke-direct {v2, v1}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    int-to-float p1, p1

    .line 1535
    new-instance v7, Landroid/graphics/Paint;

    const/4 v3, 0x1

    invoke-direct {v7, v3}, Landroid/graphics/Paint;-><init>(I)V

    .line 1536
    sget-object v4, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v7, v4}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1537
    invoke-virtual {v7, p2}, Landroid/graphics/Paint;->setColor(I)V

    const v4, 0x3dcccccd  # 0.1f

    mul-float v4, v4, p1

    const v5, 0x3fe66666  # 1.8f

    .line 1538
    invoke-static {v5, v4}, Ljava/lang/Math;->max(FF)F

    move-result v4

    invoke-virtual {v7, v4}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 1539
    sget-object v4, Landroid/graphics/Paint$Cap;->ROUND:Landroid/graphics/Paint$Cap;

    invoke-virtual {v7, v4}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    .line 1541
    new-instance v4, Landroid/graphics/RectF;

    const v5, 0x3e0f5c29  # 0.14f

    mul-float v5, v5, p1

    const v6, 0x3e23d70a  # 0.16f

    mul-float v6, v6, p1

    const v8, 0x3f5c28f6  # 0.86f

    mul-float v8, v8, p1

    const v9, 0x3ee147ae  # 0.44f

    mul-float v9, v9, p1

    invoke-direct {v4, v5, v6, v8, v9}, Landroid/graphics/RectF;-><init>(FFFF)V

    const/high16 v6, 0x40200000  # 2.5f

    .line 1542
    invoke-static {p0, v6}, Ld;->a(Landroid/content/Context;F)I

    move-result v9

    int-to-float v9, v9

    invoke-static {p0, v6}, Ld;->a(Landroid/content/Context;F)I

    move-result v10

    int-to-float v10, v10

    invoke-virtual {v2, v4, v9, v10, v7}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 1544
    new-instance v4, Landroid/graphics/RectF;

    const v9, 0x3f0a3d71  # 0.54f

    mul-float v9, v9, p1

    const v10, 0x3f51eb85  # 0.82f

    mul-float v10, v10, p1

    invoke-direct {v4, v5, v9, v8, v10}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 1545
    invoke-static {p0, v6}, Ld;->a(Landroid/content/Context;F)I

    move-result v5

    int-to-float v5, v5

    invoke-static {p0, v6}, Ld;->a(Landroid/content/Context;F)I

    move-result v6

    int-to-float v6, v6

    invoke-virtual {v2, v4, v5, v6, v7}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    .line 1547
    new-instance v4, Landroid/graphics/Paint;

    invoke-direct {v4, v3}, Landroid/graphics/Paint;-><init>(I)V

    .line 1548
    sget-object v3, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v4, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1549
    invoke-virtual {v4, p2}, Landroid/graphics/Paint;->setColor(I)V

    const p2, 0x3f3d70a4  # 0.74f

    mul-float p2, p2, p1

    const v3, 0x3e99999a  # 0.3f

    mul-float v3, v3, p1

    const v5, 0x3d3851ec  # 0.045f

    mul-float v5, v5, p1

    .line 1550
    invoke-virtual {v2, p2, v3, v5, v4}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    const v6, 0x3f2e147b  # 0.68f

    mul-float v8, p1, v6

    .line 1551
    invoke-virtual {v2, p2, v8, v5, v4}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    const p2, 0x3e851eb8  # 0.26f

    mul-float p1, p1, p2

    move v6, v3

    move v4, v3

    move v5, v9

    move v3, p1

    .line 1553
    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    move v6, v8

    move v4, v8

    .line 1554
    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 1556
    new-instance p1, Landroid/graphics/drawable/BitmapDrawable;

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-direct {p1, p0, v1}, Landroid/graphics/drawable/BitmapDrawable;-><init>(Landroid/content/res/Resources;Landroid/graphics/Bitmap;)V
    :try_end_bf
    .catchall {:try_start_c .. :try_end_bf} :catchall_c0

    return-object p1

    :catchall_c0
    return-object v0
.end method

.method static synthetic h()Ljava/lang/String;
    .registers 1

    .line 61
    sget-object v0, Ld;->g:Ljava/lang/String;

    return-object v0
.end method

.method public static i(Landroid/content/Context;II)Landroid/graphics/drawable/Drawable;
    .registers 4

    const/4 v0, -0x1

    .line 1563
    invoke-static {p0, p1, p2, v0}, Ld;->b(Landroid/content/Context;III)Landroid/graphics/drawable/Drawable;

    move-result-object p0

    return-object p0
.end method

.method static synthetic i()Ljava/lang/String;
    .registers 1

    .line 62
    sget-object v0, Ld;->h:Ljava/lang/String;

    return-object v0
.end method

.method public static i(Landroid/content/Context;)Z
    .registers 1

    if-eqz p0, :cond_4

    const/4 p0, 0x1

    return p0

    :cond_4
    const/4 p0, 0x0

    return p0
.end method

.method static synthetic j()Ljava/lang/String;
    .registers 1

    .line 63
    sget-object v0, Ld;->i:Ljava/lang/String;

    return-object v0
.end method

.method public static j(Landroid/content/Context;)Ljava/lang/String;
    .registers 1

    invoke-static {}, Le;->aZ()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static synthetic k()Ljava/lang/String;
    .registers 1

    .line 64
    sget-object v0, Ld;->j:Ljava/lang/String;

    return-object v0
.end method

.method public static k(Landroid/content/Context;)Ljava/lang/String;
    .registers 1

    invoke-static {}, Le;->aZ()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static synthetic l()Ljava/lang/String;
    .registers 1

    .line 65
    sget-object v0, Ld;->k:Ljava/lang/String;

    return-object v0
.end method

.method public static l(Landroid/content/Context;)Z
    .registers 1

    if-eqz p0, :cond_4

    const/4 p0, 0x1

    return p0

    :cond_4
    const/4 p0, 0x0

    return p0
.end method

.method static synthetic m()Ljava/lang/String;
    .registers 1

    .line 67
    sget-object v0, Ld;->m:Ljava/lang/String;

    return-object v0
.end method

.method public static m(Landroid/content/Context;)Z
    .registers 1

    if-eqz p0, :cond_4

    const/4 p0, 0x1

    return p0

    :cond_4
    const/4 p0, 0x0

    return p0
.end method

.method static synthetic n()Ljava/lang/String;
    .registers 1

    .line 68
    sget-object v0, Ld;->n:Ljava/lang/String;

    return-object v0
.end method

.method public static n(Landroid/content/Context;)Z
    .registers 1

    if-eqz p0, :cond_4

    const/4 p0, 0x1

    return p0

    :cond_4
    const/4 p0, 0x0

    return p0
.end method

.method static synthetic o()Ljava/lang/String;
    .registers 1

    .line 69
    sget-object v0, Ld;->o:Ljava/lang/String;

    return-object v0
.end method

.method public static o(Landroid/content/Context;)Z
    .registers 1

    if-eqz p0, :cond_4

    const/4 p0, 0x1

    return p0

    :cond_4
    const/4 p0, 0x0

    return p0
.end method

.method static synthetic p()Ljava/lang/String;
    .registers 1

    .line 70
    sget-object v0, Ld;->p:Ljava/lang/String;

    return-object v0
.end method

.method public static p(Landroid/content/Context;)V
    .registers 1

    return-void
.end method

.method public static q(Landroid/content/Context;)I
    .registers 1

    const p0, 0x7fffffff

    return p0
.end method

.method static synthetic q()Ljava/lang/String;
    .registers 1

    .line 66
    sget-object v0, Ld;->l:Ljava/lang/String;

    return-object v0
.end method

.method public static r(Landroid/content/Context;)I
    .registers 1

    const p0, 0x7fffffff

    return p0
.end method

.method static synthetic r()Ljava/lang/String;
    .registers 1

    .line 58
    sget-object v0, Ld;->d:Ljava/lang/String;

    return-object v0
.end method

.method public static removeElevation(Landroid/view/View;)V
    .registers 2

    if-nez p0, :cond_3

    goto :goto_11

    :cond_3
    const/4 v0, 0x0

    .line 987
    invoke-virtual {p0, v0}, Landroid/view/View;->setElevation(F)V

    .line 988
    instance-of v0, p0, Landroid/widget/Button;

    if-eqz v0, :cond_11

    .line 989
    check-cast p0, Landroid/widget/Button;

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/widget/Button;->setStateListAnimator(Landroid/animation/StateListAnimator;)V

    :cond_11
    :goto_11
    return-void
.end method

.method public static s(Landroid/content/Context;)Landroid/graphics/drawable/Drawable;
    .registers 3

    .line 947
    new-instance v0, Landroid/graphics/drawable/GradientDrawable;

    invoke-direct {v0}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const/4 v1, -0x1

    .line 948
    invoke-virtual {v0, v1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const/16 v1, 0x16

    .line 949
    invoke-static {p0, v1}, Ld;->a(Landroid/content/Context;I)I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    const/high16 v1, 0x3fc00000  # 1.5f

    .line 950
    invoke-static {p0, v1}, Ld;->a(Landroid/content/Context;F)I

    move-result p0

    const-string v1, "dhF0aAATZA=="

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v0, p0, v1}, Landroid/graphics/drawable/GradientDrawable;->setStroke(II)V

    return-object v0
.end method
