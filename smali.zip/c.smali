# classes88.dex

.class public Lc;
.super Lcom/ivar/mods/ai/FoxAutomationService$a;
.source "FoxSource"


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 2

    .line 703
    invoke-direct {p0, p1}, Lcom/ivar/mods/ai/FoxAutomationService$a;-><init>(Landroid/content/Context;)V

    return-void
.end method

.method public static a(Landroid/app/Activity;)V
    .registers 1

    .line 711
    invoke-static {p0}, Lcom/ivar/mods/ai/FoxAutomationService;->setupAutoPip(Landroid/app/Activity;)V

    return-void
.end method

.method public static b(Landroid/app/Activity;)V
    .registers 1

    .line 715
    invoke-static {p0}, Lcom/ivar/mods/ai/FoxAutomationService;->disableAutoPip(Landroid/app/Activity;)V

    return-void
.end method
