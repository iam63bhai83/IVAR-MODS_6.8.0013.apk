# classes88.dex

.class Ld$24$1;
.super Ljava/lang/Object;
.source "FoxSource"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ld$24;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ld$24;

.field private final synthetic b:[Z

.field private final synthetic c:Landroid/app/Activity;

.field private final synthetic d:Landroid/content/SharedPreferences;

.field private final synthetic e:Ljava/lang/String;

.field private final synthetic f:Landroid/app/Dialog;

.field private final synthetic g:Ljava/lang/Runnable;


# direct methods
.method constructor <init>(Ld$24;[ZLandroid/app/Activity;Landroid/content/SharedPreferences;Ljava/lang/String;Landroid/app/Dialog;Ljava/lang/Runnable;)V
    .registers 8

    .line 3836
    iput-object p1, p0, Ld$24$1;->a:Ld$24;

    iput-object p2, p0, Ld$24$1;->b:[Z

    iput-object p3, p0, Ld$24$1;->c:Landroid/app/Activity;

    iput-object p4, p0, Ld$24$1;->d:Landroid/content/SharedPreferences;

    iput-object p5, p0, Ld$24$1;->e:Ljava/lang/String;

    iput-object p6, p0, Ld$24$1;->f:Landroid/app/Dialog;

    iput-object p7, p0, Ld$24$1;->g:Ljava/lang/Runnable;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 13

    .line 3839
    iget-object v0, p0, Ld$24$1;->b:[Z

    const/4 v2, 0x0

    aget-boolean v0, v0, v2

    if-nez v0, :cond_5e

    iget-object v0, p0, Ld$24$1;->c:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->isFinishing()Z

    move-result v0

    if-eqz v0, :cond_10

    goto :goto_5e

    .line 3841
    :cond_10
    iget-object v0, p0, Ld$24$1;->d:Landroid/content/SharedPreferences;

    invoke-static {}, Le;->D()Ljava/lang/String;

    move-result-object v2

    iget-object v3, p0, Ld$24$1;->d:Landroid/content/SharedPreferences;

    const-string v4, "ICcjX2cwOSdEVA=="

    invoke-static {v4}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const-string v5, ""

    invoke-interface {v3, v4, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-interface {v0, v2, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    .line 3842
    iget-object v0, p0, Ld$24$1;->d:Landroid/content/SharedPreferences;

    invoke-static {}, Le;->E()Ljava/lang/String;

    move-result-object v2

    iget-object v4, p0, Ld$24$1;->d:Landroid/content/SharedPreferences;

    const-string v6, "ICcjX2cgPSI="

    invoke-static {v6}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-interface {v4, v6, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-interface {v0, v2, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    .line 3843
    iget-object v0, p0, Ld$24$1;->c:Landroid/app/Activity;

    invoke-static {v0}, Le;->c(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v5

    .line 3845
    new-instance v11, Ljava/lang/Thread;

    new-instance v0, Ld$24$1$1;

    iget-object v2, p0, Ld$24$1;->e:Ljava/lang/String;

    iget-object v6, p0, Ld$24$1;->c:Landroid/app/Activity;

    iget-object v7, p0, Ld$24$1;->b:[Z

    iget-object v8, p0, Ld$24$1;->d:Landroid/content/SharedPreferences;

    iget-object v9, p0, Ld$24$1;->f:Landroid/app/Dialog;

    iget-object v10, p0, Ld$24$1;->g:Ljava/lang/Runnable;

    move-object v1, p0

    invoke-direct/range {v0 .. v10}, Ld$24$1$1;-><init>(Ld$24$1;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/app/Activity;[ZLandroid/content/SharedPreferences;Landroid/app/Dialog;Ljava/lang/Runnable;)V

    invoke-direct {v11, v0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 3901
    invoke-virtual {v11}, Ljava/lang/Thread;->start()V

    :cond_5e
    :goto_5e
    return-void
.end method
