# classes88.dex

.class Lb$3$1;
.super Ljava/lang/Object;
.source "FoxSource"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lb$3;->onClick(Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lb$3;

.field private final synthetic b:Landroid/view/View;

.field private final synthetic c:Ljava/lang/String;

.field private final synthetic d:Landroid/app/Activity;


# direct methods
.method constructor <init>(Lb$3;Landroid/view/View;Ljava/lang/String;Landroid/app/Activity;)V
    .registers 5

    .line 125
    iput-object p1, p0, Lb$3$1;->a:Lb$3;

    iput-object p2, p0, Lb$3$1;->b:Landroid/view/View;

    iput-object p3, p0, Lb$3$1;->c:Ljava/lang/String;

    iput-object p4, p0, Lb$3$1;->d:Landroid/app/Activity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 6

    .line 128
    iget-object v0, p0, Lb$3$1;->b:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    const/high16 v1, 0x3f800000  # 1.0f

    invoke-virtual {v0, v1}, Landroid/view/ViewPropertyAnimator;->scaleX(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/view/ViewPropertyAnimator;->scaleY(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    const-wide/16 v1, 0xa0

    invoke-virtual {v0, v1, v2}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    new-instance v1, Landroid/view/animation/OvershootInterpolator;

    const v2, 0x3fcccccd  # 1.6f

    invoke-direct {v1, v2}, Landroid/view/animation/OvershootInterpolator;-><init>(F)V

    invoke-virtual {v0, v1}, Landroid/view/ViewPropertyAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/ViewPropertyAnimator;->start()V

    .line 129
    iget-object v0, p0, Lb$3$1;->c:Ljava/lang/String;

    invoke-static {v0}, Lb;->a(Ljava/lang/String;)V

    .line 130
    iget-object v0, p0, Lb$3$1;->d:Landroid/app/Activity;

    invoke-static {v0}, Lb;->c(Landroid/app/Activity;)V

    .line 132
    iget-object v0, p0, Lb$3$1;->d:Landroid/app/Activity;

    .line 133
    invoke-virtual {v0}, Landroid/app/Activity;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const-string v2, "OT0oSFknCy5ESyE7NFRnPCAjQEsKNylDTDQ9KEhK"

    invoke-static {v2}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string v3, "PDA="

    invoke-static {v3}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    iget-object v4, p0, Lb$3$1;->d:Landroid/app/Activity;

    invoke-virtual {v4}, Landroid/app/Activity;->getPackageName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v2, v3, v4}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v1

    .line 132
    invoke-virtual {v0, v1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    if-eqz v0, :cond_71

    .line 136
    invoke-virtual {v0}, Landroid/widget/LinearLayout;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v1

    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v1

    const-wide/16 v2, 0x5a

    invoke-virtual {v1, v2, v3}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object v1

    new-instance v2, Lb$3$1$1;

    iget-object v3, p0, Lb$3$1;->d:Landroid/app/Activity;

    invoke-direct {v2, p0, v3, v0}, Lb$3$1$1;-><init>(Lb$3$1;Landroid/app/Activity;Landroid/widget/LinearLayout;)V

    invoke-virtual {v1, v2}, Landroid/view/ViewPropertyAnimator;->withEndAction(Ljava/lang/Runnable;)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    .line 142
    invoke-virtual {v0}, Landroid/view/ViewPropertyAnimator;->start()V

    return-void

    .line 144
    :cond_71
    iget-object v0, p0, Lb$3$1;->d:Landroid/app/Activity;

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lb;->a(Landroid/app/Activity;Z)V

    return-void
.end method
