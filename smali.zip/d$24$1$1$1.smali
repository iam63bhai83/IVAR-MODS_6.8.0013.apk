# classes88.dex

.class Ld$24$1$1$1;
.super Ljava/lang/Object;
.source "FoxSource"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ld$24$1$1;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ld$24$1$1;

.field private final synthetic b:[Z

.field private final synthetic c:Landroid/app/Activity;

.field private final synthetic d:Z

.field private final synthetic e:Landroid/content/SharedPreferences;

.field private final synthetic f:Landroid/app/Dialog;

.field private final synthetic g:Ljava/lang/Runnable;


# direct methods
.method constructor <init>(Ld$24$1$1;[ZLandroid/app/Activity;ZLandroid/content/SharedPreferences;Landroid/app/Dialog;Ljava/lang/Runnable;)V
    .registers 8

    .line 3883
    iput-object p1, p0, Ld$24$1$1$1;->a:Ld$24$1$1;

    iput-object p2, p0, Ld$24$1$1$1;->b:[Z

    iput-object p3, p0, Ld$24$1$1$1;->c:Landroid/app/Activity;

    iput-boolean p4, p0, Ld$24$1$1$1;->d:Z

    iput-object p5, p0, Ld$24$1$1$1;->e:Landroid/content/SharedPreferences;

    iput-object p6, p0, Ld$24$1$1$1;->f:Landroid/app/Dialog;

    iput-object p7, p0, Ld$24$1$1$1;->g:Ljava/lang/Runnable;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 4

    .line 3886
    iget-object v0, p0, Ld$24$1$1$1;->b:[Z

    const/4 v1, 0x0

    aget-boolean v0, v0, v1

    if-nez v0, :cond_47

    iget-object v0, p0, Ld$24$1$1$1;->c:Landroid/app/Activity;

    invoke-virtual {v0}, Landroid/app/Activity;->isFinishing()Z

    move-result v0

    if-eqz v0, :cond_10

    goto :goto_47

    .line 3887
    :cond_10
    iget-boolean v0, p0, Ld$24$1$1$1;->d:Z

    if-eqz v0, :cond_47

    .line 3888
    iget-object v0, p0, Ld$24$1$1$1;->b:[Z

    const/4 v2, 0x1

    aput-boolean v2, v0, v1

    .line 3889
    iget-object v0, p0, Ld$24$1$1$1;->e:Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-static {}, Ld;->p()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 3890
    iget-object v0, p0, Ld$24$1$1$1;->c:Landroid/app/Activity;

    const-string v1, "GjIgRFs8NSoNbDA4I0pKNDlmblA0OihIVHUCI19RMz0jSRl1EjRIXXUEKkxWdQEoQVc2PyNJFg=="

    invoke-static {v1}, La;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 3891
    :try_start_39
    iget-object v0, p0, Ld$24$1$1$1;->f:Landroid/app/Dialog;

    invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V
    :try_end_3e
    .catchall {:try_start_39 .. :try_end_3e} :catchall_3f

    goto :goto_40

    :catchall_3f
    nop

    .line 3892
    :goto_40
    iget-object v0, p0, Ld$24$1$1$1;->g:Ljava/lang/Runnable;

    if-eqz v0, :cond_47

    .line 3893
    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    :cond_47
    :goto_47
    return-void
.end method
