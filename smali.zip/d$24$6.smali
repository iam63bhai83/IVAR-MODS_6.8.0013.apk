# classes88.dex

.class Ld$24$6;
.super Ljava/lang/Object;
.source "FoxSource"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Ld$24;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ld$24;

.field private final synthetic b:[Z

.field private final synthetic c:Landroid/os/Handler;

.field private final synthetic d:Ljava/lang/Runnable;

.field private final synthetic e:Landroid/app/Dialog;

.field private final synthetic f:Landroid/app/Activity;


# direct methods
.method constructor <init>(Ld$24;[ZLandroid/os/Handler;Ljava/lang/Runnable;Landroid/app/Dialog;Landroid/app/Activity;)V
    .registers 7

    .line 4023
    iput-object p1, p0, Ld$24$6;->a:Ld$24;

    iput-object p2, p0, Ld$24$6;->b:[Z

    iput-object p3, p0, Ld$24$6;->c:Landroid/os/Handler;

    iput-object p4, p0, Ld$24$6;->d:Ljava/lang/Runnable;

    iput-object p5, p0, Ld$24$6;->e:Landroid/app/Dialog;

    iput-object p6, p0, Ld$24$6;->f:Landroid/app/Activity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .registers 4

    .line 4026
    iget-object p1, p0, Ld$24$6;->b:[Z

    const/4 v0, 0x0

    const/4 v1, 0x1

    aput-boolean v1, p1, v0

    .line 4027
    iget-object p1, p0, Ld$24$6;->c:Landroid/os/Handler;

    iget-object v0, p0, Ld$24$6;->d:Ljava/lang/Runnable;

    invoke-virtual {p1, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 4028
    iget-object p1, p0, Ld$24$6;->e:Landroid/app/Dialog;

    invoke-virtual {p1}, Landroid/app/Dialog;->dismiss()V

    .line 4029
    iget-object p1, p0, Ld$24$6;->f:Landroid/app/Activity;

    invoke-static {p1}, Ld;->d(Landroid/app/Activity;)V

    return-void
.end method
